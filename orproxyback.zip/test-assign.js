/**
 * 测试 DigitalOcean Reserved IP 分配
 */

const { createSDK } = require('./digapi/src/index.js');
const path = require('path');

async function test() {
    console.log('=== 测试 Reserved IP 分配 ===\n');

    // 初始化 SDK
    const sdk = createSDK(path.resolve('./digapi/config/accounts.json'));
    const accountName = sdk.listAccounts()[0];
    const account = sdk.account(accountName);

    console.log(`使用账号: ${accountName}\n`);

    const DROPLET_ID = 518272103;
    const TEST_REGION = 'sfo2';

    try {
        // 1. 创建 Reserved IP
        console.log('1. 创建 Reserved IP...');
        const createResult = await account.reservedIPs.create({ region: TEST_REGION });
        const testIP = createResult.ip;
        console.log(`✓ Reserved IP 创建成功: ${testIP}`);
        console.log(`完整响应:`, JSON.stringify(createResult, null, 2));

        // 2. 立即查询一次
        console.log('\n2. 查询 Reserved IP 列表（创建后）...');
        let reservedIPs = await account.reservedIPs.list();
        let targetIP = reservedIPs.find(ip => ip.ip === testIP);
        console.log(`找到 IP: ${targetIP ? 'Yes' : 'No'}`);
        if (targetIP) {
            console.log(`droplet: ${JSON.stringify(targetIP.droplet)}`);
        }

        // 3. 分配到 Droplet
        console.log(`\n3. 分配 IP ${testIP} 到 Droplet ${DROPLET_ID}...`);
        const assignAction = await account.reservedIPs.assign(testIP, DROPLET_ID);
        console.log(`✓ 分配操作已提交`);
        console.log(`Action 详情:`, JSON.stringify(assignAction, null, 2));

        // 4. 立即查询
        console.log('\n4. 立即查询（分配后0秒）...');
        reservedIPs = await account.reservedIPs.list();
        targetIP = reservedIPs.find(ip => ip.ip === testIP);
        console.log(`droplet: ${JSON.stringify(targetIP?.droplet)}`);

        // 5. 等待10秒后查询
        console.log('\n5. 等待10秒...');
        await new Promise(resolve => setTimeout(resolve, 10000));
        reservedIPs = await account.reservedIPs.list();
        targetIP = reservedIPs.find(ip => ip.ip === testIP);
        console.log(`droplet: ${JSON.stringify(targetIP?.droplet)}`);

        // 6. 等待20秒后查询
        console.log('\n6. 等待20秒...');
        await new Promise(resolve => setTimeout(resolve, 20000));
        reservedIPs = await account.reservedIPs.list();
        targetIP = reservedIPs.find(ip => ip.ip === testIP);
        console.log(`droplet: ${JSON.stringify(targetIP?.droplet)}`);

        // 7. 等待30秒后查询
        console.log('\n7. 等待30秒...');
        await new Promise(resolve => setTimeout(resolve, 30000));
        reservedIPs = await account.reservedIPs.list();
        targetIP = reservedIPs.find(ip => ip.ip === testIP);
        console.log(`droplet: ${JSON.stringify(targetIP?.droplet)}`);

        // 8. 清理：删除测试 IP
        console.log(`\n8. 清理：删除 IP ${testIP}...`);
        try {
            await account.reservedIPs.unassign(testIP);
            console.log('✓ 解绑成功');
        } catch (e) {
            console.log('解绑失败（可能未分配）:', e.message);
        }
        await account.reservedIPs.delete(testIP);
        console.log('✓ 删除成功');

        console.log('\n=== 测试完成 ===');

    } catch (error) {
        console.error('错误:', error);
        throw error;
    }
}

test().catch(console.error);

