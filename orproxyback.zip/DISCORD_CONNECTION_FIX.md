# Discord 连接问题解决指南

## 问题现象

```
[W] adapter failed to connect to wss://discord.com/api/v10/gateway/bot/, code: 1006
Error: Client network socket disconnected before secure TLS connection was established
TypeError: fetch failed
```

## 解决方案

### 方案1：配置代理（推荐）

如果你在中国大陆或网络受限地区，需要配置代理：

#### 步骤1：启动代理软件
确保你的代理软件正在运行（如 Clash、V2Ray 等），并记下代理端口（通常是 7890）

#### 步骤2：修改 `koishi.yml`

取消注释代理配置：

```yaml
plugins:
  proxy-agent:951d8e:
    http: http://127.0.0.1:7890
    https: http://127.0.0.1:7890
  http:f94dzp:
    proxyAgent: http://127.0.0.1:7890
```

**注意**：将 `7890` 替换为你的实际代理端口。

#### 步骤3：重启 Koishi

```bash
npm run dev
```

### 方案2：检查 Token 是否有效

1. 访问 [Discord Developer Portal](https://discord.com/developers/applications)
2. 选择你的应用
3. 进入 "Bot" 页面
4. 点击 "Reset Token" 重新生成 Token
5. 复制新 Token 到 `koishi.yml`：

```yaml
adapter-discord:bimeg4:
  token: YOUR_NEW_TOKEN_HERE
```

### 方案3：DNS 配置

如果代理不可用，可以尝试修改 DNS：

#### Windows:
```powershell
# 使用 Cloudflare DNS
netsh interface ip set dns "以太网" static 1.1.1.1
netsh interface ip add dns "以太网" 8.8.8.8 index=2
```

#### Linux/Mac:
```bash
# 编辑 /etc/resolv.conf
sudo nano /etc/resolv.conf

# 添加以下内容
nameserver 1.1.1.1
nameserver 8.8.8.8
```

### 方案4：使用 Cloudflare Warp（免费代理）

1. 下载安装 [Cloudflare WARP](https://1.1.1.1/)
2. 启动 WARP
3. 重启 Koishi

### 方案5：检查防火墙

确保防火墙没有阻止 Discord 的域名：
- `discord.com`
- `gateway.discord.gg`

## 测试连接

在配置代理后，可以测试连接：

```bash
# Windows PowerShell
curl https://discord.com/api/v10/gateway/bot -H "Authorization: Bot YOUR_TOKEN"

# Linux/Mac
curl -H "Authorization: Bot YOUR_TOKEN" https://discord.com/api/v10/gateway/bot
```

如果返回 JSON 数据，说明连接正常。

## 常见代理端口

| 代理软件 | 默认端口 |
|---------|---------|
| Clash   | 7890    |
| V2Ray   | 10808   |
| Shadowsocks | 1080 |
| Surge   | 6152    |

## 推荐配置（完整示例）

```yaml
plugins:
  # 代理配置
  proxy-agent:951d8e:
    http: http://127.0.0.1:7890
    https: http://127.0.0.1:7890
  
  # HTTP 客户端配置
  http:f94dzp:
    proxyAgent: http://127.0.0.1:7890
    timeout: 30000
  
  # Discord 适配器
  adapter-discord:bimeg4:
    token: YOUR_DISCORD_BOT_TOKEN
    intents:
      - GUILDS
      - GUILD_MESSAGES
      - DIRECT_MESSAGES
      - MESSAGE_CONTENT
```

## 仍然无法连接？

1. **检查代理是否正常工作**：
   ```bash
   curl -x http://127.0.0.1:7890 https://www.google.com
   ```

2. **检查 Bot Token 权限**：
   - 确保 Bot 已被邀请到服务器
   - 确保启用了 "MESSAGE CONTENT INTENT"

3. **查看完整日志**：
   ```bash
   npm run dev 2>&1 | tee koishi.log
   ```

4. **尝试备用网络**：
   - 使用手机热点
   - 使用 VPN

## 联系支持

如果以上方法都无法解决，请提供以下信息：
- 操作系统
- 网络环境（是否在中国大陆）
- 完整错误日志
- 已尝试的解决方案

