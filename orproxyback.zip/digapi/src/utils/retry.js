/**
 * Retry utilities for handling transient errors
 */

const { NetworkError, RateLimitError, ServerError } = require('./errors');

/**
 * Sleep for specified milliseconds
 * @param {number} ms - Milliseconds to sleep
 * @returns {Promise<void>}
 */
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Calculate exponential backoff delay
 * @param {number} attempt - Current attempt number (0-based)
 * @param {number} initialDelay - Initial delay in milliseconds
 * @param {number} maxDelay - Maximum delay in milliseconds
 * @returns {number} Delay in milliseconds
 */
function calculateBackoff(attempt, initialDelay = 1000, maxDelay = 30000) {
    const delay = initialDelay * Math.pow(2, attempt);
    return Math.min(delay, maxDelay);
}

/**
 * Default retry decision function
 * @param {Error} error - Error object
 * @param {number} attempt - Current attempt number (0-based)
 * @returns {boolean} Whether to retry
 */
function defaultShouldRetry(error, attempt) {
    // Don't retry beyond max attempts
    if (attempt >= 3) {
        return false;
    }

    // Retry network errors
    if (error instanceof NetworkError) {
        return true;
    }

    // Retry rate limit errors
    if (error instanceof RateLimitError) {
        return true;
    }

    // Retry server errors
    if (error instanceof ServerError) {
        return true;
    }

    // Don't retry other errors
    return false;
}

/**
 * Execute function with retry logic
 * @param {Function} fn - Async function to execute
 * @param {Object} options - Retry options
 * @param {number} options.maxRetries - Maximum number of retries (default: 3)
 * @param {number} options.initialDelay - Initial delay in milliseconds (default: 1000)
 * @param {number} options.maxDelay - Maximum delay in milliseconds (default: 30000)
 * @param {Function} options.shouldRetry - Custom retry decision function
 * @param {Function} options.onRetry - Callback function called before each retry
 * @returns {Promise<*>} Result of the function
 */
async function withRetry(fn, options = {}) {
    const {
        maxRetries = 3,
        initialDelay = 1000,
        maxDelay = 30000,
        shouldRetry = defaultShouldRetry,
        onRetry = null
    } = options;

    let lastError;
    let attempt = 0;

    while (attempt <= maxRetries) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;

            // Check if we should retry
            if (!shouldRetry(error, attempt)) {
                throw error;
            }

            // Don't retry if this was the last attempt
            if (attempt >= maxRetries) {
                throw error;
            }

            // Calculate delay
            let delay;
            if (error instanceof RateLimitError && error.retryAfter) {
                // Use Retry-After header if available
                delay = parseInt(error.retryAfter) * 1000;
            } else {
                // Use exponential backoff
                delay = calculateBackoff(attempt, initialDelay, maxDelay);
            }

            // Call onRetry callback if provided
            if (onRetry) {
                onRetry(error, attempt, delay);
            }

            // Wait before retry
            await sleep(delay);

            attempt++;
        }
    }

    // This should never be reached, but just in case
    throw lastError;
}

/**
 * Create a retry wrapper for a function
 * @param {Function} fn - Function to wrap
 * @param {Object} options - Retry options
 * @returns {Function} Wrapped function with retry logic
 */
function withRetryWrapper(fn, options = {}) {
    return async function (...args) {
        return withRetry(() => fn.apply(this, args), options);
    };
}

module.exports = {
    sleep,
    calculateBackoff,
    defaultShouldRetry,
    withRetry,
    withRetryWrapper
};

