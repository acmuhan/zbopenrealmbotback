/**
 * DigitalOcean SDK Error Classes
 */

/**
 * Base error class for all DigitalOcean SDK errors
 */
class DOError extends Error {
    constructor(message, options = {}) {
        super(message);
        this.name = 'DOError';
        this.account = options.account || null;
        this.timestamp = new Date();
        Error.captureStackTrace(this, this.constructor);
    }
}

/**
 * Network related errors (connection failures, timeouts)
 */
class NetworkError extends DOError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'NetworkError';
        this.code = options.code || 'NETWORK_ERROR';
    }
}

/**
 * Base class for API errors (HTTP errors)
 */
class APIError extends DOError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'APIError';
        this.statusCode = options.statusCode || null;
        this.response = options.response || null;
        this.requestId = options.requestId || null;
    }
}

/**
 * Rate limit exceeded error (HTTP 429)
 */
class RateLimitError extends APIError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'RateLimitError';
        this.statusCode = 429;
        this.retryAfter = options.retryAfter || null;
        this.rateLimit = options.rateLimit || null;
    }
}

/**
 * Authentication errors (HTTP 401, 403)
 */
class AuthenticationError extends APIError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'AuthenticationError';
        this.statusCode = options.statusCode || 401;
    }
}

/**
 * Resource not found error (HTTP 404)
 */
class ResourceNotFoundError extends APIError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'ResourceNotFoundError';
        this.statusCode = 404;
        this.resourceType = options.resourceType || null;
        this.resourceId = options.resourceId || null;
    }
}

/**
 * Validation error (HTTP 422)
 */
class ValidationError extends APIError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'ValidationError';
        this.statusCode = 422;
        this.errors = options.errors || [];
    }
}

/**
 * Server error (HTTP 5xx)
 */
class ServerError extends APIError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'ServerError';
        this.statusCode = options.statusCode || 500;
    }
}

/**
 * Configuration error
 */
class ConfigError extends DOError {
    constructor(message, options = {}) {
        super(message, options);
        this.name = 'ConfigError';
    }
}

/**
 * Parse HTTP error response and create appropriate error instance
 * @param {Object} error - Axios error object
 * @param {string} account - Account name
 * @returns {DOError} Appropriate error instance
 */
function parseError(error, account = null) {
    const options = { account };

    // Network errors (no response)
    if (!error.response) {
        return new NetworkError(
            error.message || 'Network error occurred',
            { ...options, code: error.code }
        );
    }

    const { response } = error;
    const statusCode = response.status;
    const data = response.data || {};
    const message = data.message || data.error_message || error.message || 'API error occurred';

    options.statusCode = statusCode;
    options.response = data;
    options.requestId = response.headers['x-request-id'];

    // Rate limit error
    if (statusCode === 429) {
        return new RateLimitError(message, {
            ...options,
            retryAfter: response.headers['retry-after'],
            rateLimit: {
                limit: response.headers['ratelimit-limit'],
                remaining: response.headers['ratelimit-remaining'],
                reset: response.headers['ratelimit-reset']
            }
        });
    }

    // Authentication errors
    if (statusCode === 401 || statusCode === 403) {
        return new AuthenticationError(message, options);
    }

    // Not found error
    if (statusCode === 404) {
        return new ResourceNotFoundError(message, options);
    }

    // Validation error
    if (statusCode === 422) {
        return new ValidationError(message, {
            ...options,
            errors: data.errors || []
        });
    }

    // Server errors
    if (statusCode >= 500) {
        return new ServerError(message, options);
    }

    // Generic API error
    return new APIError(message, options);
}

module.exports = {
    DOError,
    NetworkError,
    APIError,
    RateLimitError,
    AuthenticationError,
    ResourceNotFoundError,
    ValidationError,
    ServerError,
    ConfigError,
    parseError
};

