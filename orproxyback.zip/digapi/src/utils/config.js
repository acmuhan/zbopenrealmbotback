/**
 * Configuration loading utilities
 */

const fs = require('fs');
const path = require('path');
const { ConfigError } = require('./errors');

/**
 * Load configuration from a JSON file
 * @param {string} configPath - Path to configuration file
 * @returns {Object} Configuration object
 * @throws {ConfigError} If configuration is invalid
 */
function loadConfig(configPath) {
    // Resolve path
    const resolvedPath = path.resolve(configPath);

    // Check if file exists
    if (!fs.existsSync(resolvedPath)) {
        throw new ConfigError(`Configuration file not found: ${resolvedPath}`);
    }

    // Read and parse configuration file
    let config;
    try {
        const content = fs.readFileSync(resolvedPath, 'utf8');
        config = JSON.parse(content);
    } catch (error) {
        throw new ConfigError(`Failed to parse configuration file: ${error.message}`);
    }

    // Validate configuration
    validateConfig(config);

    return config;
}

/**
 * Validate configuration structure
 * @param {Object} config - Configuration object
 * @throws {ConfigError} If configuration is invalid
 */
function validateConfig(config) {
    if (!config) {
        throw new ConfigError('Configuration is empty');
    }

    if (!config.accounts || typeof config.accounts !== 'object') {
        throw new ConfigError('Configuration must have an "accounts" object');
    }

    const accounts = Object.keys(config.accounts);
    if (accounts.length === 0) {
        throw new ConfigError('No accounts configured');
    }

    // Validate each account
    for (const accountName of accounts) {
        const account = config.accounts[accountName];

        if (!account || typeof account !== 'object') {
            throw new ConfigError(`Invalid account configuration: ${accountName}`);
        }

        if (!account.token || typeof account.token !== 'string') {
            throw new ConfigError(`Account "${accountName}" must have a "token" string`);
        }

        if (account.token.trim().length === 0) {
            throw new ConfigError(`Account "${accountName}" has an empty token`);
        }
    }
}

/**
 * Load configuration with environment variable support
 * @param {string} configPath - Path to configuration file (optional)
 * @returns {Object} Configuration object
 */
function loadConfigWithEnv(configPath) {
    // Use environment variable if configPath not provided
    const finalPath = configPath || process.env.DO_CONFIG_PATH || path.join(__dirname, '../../config/accounts.json');

    return loadConfig(finalPath);
}

/**
 * Create configuration object from accounts map
 * @param {Object} accounts - Map of account name to token
 * @returns {Object} Configuration object
 */
function createConfig(accounts) {
    const config = {
        accounts: {}
    };

    for (const [name, token] of Object.entries(accounts)) {
        config.accounts[name] = { token };
    }

    validateConfig(config);
    return config;
}

/**
 * Add account to configuration
 * @param {Object} config - Configuration object
 * @param {string} name - Account name
 * @param {string} token - Account token
 * @returns {Object} Updated configuration
 */
function addAccount(config, name, token) {
    if (!name || typeof name !== 'string') {
        throw new ConfigError('Account name must be a non-empty string');
    }

    if (!token || typeof token !== 'string') {
        throw new ConfigError('Account token must be a non-empty string');
    }

    if (!config.accounts) {
        config.accounts = {};
    }

    config.accounts[name] = { token };
    return config;
}

/**
 * Remove account from configuration
 * @param {Object} config - Configuration object
 * @param {string} name - Account name
 * @returns {Object} Updated configuration
 */
function removeAccount(config, name) {
    if (!config.accounts || !config.accounts[name]) {
        throw new ConfigError(`Account not found: ${name}`);
    }

    delete config.accounts[name];
    return config;
}

module.exports = {
    loadConfig,
    loadConfigWithEnv,
    validateConfig,
    createConfig,
    addAccount,
    removeAccount
};

