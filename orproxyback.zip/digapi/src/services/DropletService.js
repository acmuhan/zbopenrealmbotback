/**
 * DigitalOcean Droplet Service
 */

/**
 * Service for managing DigitalOcean Droplets
 */
class DropletService {
    /**
     * Create a new DropletService instance
     * @param {DOClient} client - DOClient instance
     */
    constructor(client) {
        this.client = client;
    }

    /**
     * List all Droplets
     * @param {Object} options - List options
     * @param {number} options.page - Page number
     * @param {number} options.perPage - Items per page
     * @param {string} options.tag - Filter by tag
     * @param {boolean} options.allPages - Fetch all pages (default: true)
     * @returns {Promise<Array>} Array of Droplets
     */
    async list(options = {}) {
        const { page, perPage, tag, allPages = true } = options;

        const params = {};
        if (tag) params.tag_name = tag;
        if (page) params.page = page;
        if (perPage) params.per_page = perPage;

        if (allPages && !page) {
            // Fetch all pages
            return this.client.getAllPages('droplets', params, 'droplets');
        } else {
            // Fetch single page
            const data = await this.client.get('droplets', params);
            return data.droplets || [];
        }
    }

    /**
     * Get a single Droplet by ID
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Droplet object
     */
    async get(dropletId) {
        const data = await this.client.get(`droplets/${dropletId}`);
        return data.droplet;
    }

    /**
     * Create a new Droplet
     * @param {Object} dropletData - Droplet creation data
     * @param {string} dropletData.name - Droplet name
     * @param {string} dropletData.region - Region slug (e.g., 'nyc3')
     * @param {string} dropletData.size - Size slug (e.g., 's-1vcpu-1gb')
     * @param {string} dropletData.image - Image slug or ID
     * @param {Array<number>} dropletData.ssh_keys - SSH key IDs (optional)
     * @param {boolean} dropletData.backups - Enable backups (optional)
     * @param {boolean} dropletData.ipv6 - Enable IPv6 (optional)
     * @param {boolean} dropletData.monitoring - Enable monitoring (optional)
     * @param {Array<string>} dropletData.tags - Tags (optional)
     * @param {string} dropletData.user_data - User data script (optional)
     * @param {string} dropletData.vpc_uuid - VPC UUID (optional)
     * @returns {Promise<Object>} Created Droplet object
     */
    async create(dropletData) {
        const data = await this.client.post('droplets', dropletData);
        return data.droplet;
    }

    /**
     * Delete a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<void>}
     */
    async delete(dropletId) {
        await this.client.delete(`droplets/${dropletId}`);
    }

    /**
     * Perform an action on a Droplet
     * @param {number} dropletId - Droplet ID
     * @param {string} actionType - Action type
     * @param {Object} additionalParams - Additional action parameters
     * @returns {Promise<Object>} Action object
     * @private
     */
    async _performAction(dropletId, actionType, additionalParams = {}) {
        const data = await this.client.post(`droplets/${dropletId}/actions`, {
            type: actionType,
            ...additionalParams
        });
        return data.action;
    }

    /**
     * Reboot a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async reboot(dropletId) {
        return this._performAction(dropletId, 'reboot');
    }

    /**
     * Power cycle a Droplet (power off then on)
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async powerCycle(dropletId) {
        return this._performAction(dropletId, 'power_cycle');
    }

    /**
     * Shutdown a Droplet (graceful shutdown)
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async shutdown(dropletId) {
        return this._performAction(dropletId, 'shutdown');
    }

    /**
     * Power off a Droplet (force shutdown)
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async powerOff(dropletId) {
        return this._performAction(dropletId, 'power_off');
    }

    /**
     * Power on a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async powerOn(dropletId) {
        return this._performAction(dropletId, 'power_on');
    }

    /**
     * Restore a Droplet from a backup
     * @param {number} dropletId - Droplet ID
     * @param {number} imageId - Backup image ID
     * @returns {Promise<Object>} Action object
     */
    async restore(dropletId, imageId) {
        return this._performAction(dropletId, 'restore', { image: imageId });
    }

    /**
     * Reset password for a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async passwordReset(dropletId) {
        return this._performAction(dropletId, 'password_reset');
    }

    /**
     * Resize a Droplet
     * @param {number} dropletId - Droplet ID
     * @param {string} size - New size slug
     * @param {boolean} disk - Resize disk (default: true)
     * @returns {Promise<Object>} Action object
     */
    async resize(dropletId, size, disk = true) {
        return this._performAction(dropletId, 'resize', { size, disk });
    }

    /**
     * Rebuild a Droplet
     * @param {number} dropletId - Droplet ID
     * @param {string} image - Image slug or ID
     * @returns {Promise<Object>} Action object
     */
    async rebuild(dropletId, image) {
        return this._performAction(dropletId, 'rebuild', { image });
    }

    /**
     * Rename a Droplet
     * @param {number} dropletId - Droplet ID
     * @param {string} name - New name
     * @returns {Promise<Object>} Action object
     */
    async rename(dropletId, name) {
        return this._performAction(dropletId, 'rename', { name });
    }

    /**
     * Enable backups for a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async enableBackups(dropletId) {
        return this._performAction(dropletId, 'enable_backups');
    }

    /**
     * Disable backups for a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async disableBackups(dropletId) {
        return this._performAction(dropletId, 'disable_backups');
    }

    /**
     * Enable IPv6 for a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async enableIPv6(dropletId) {
        return this._performAction(dropletId, 'enable_ipv6');
    }

    /**
     * Take a snapshot of a Droplet
     * @param {number} dropletId - Droplet ID
     * @param {string} name - Snapshot name
     * @returns {Promise<Object>} Action object
     */
    async snapshot(dropletId, name) {
        return this._performAction(dropletId, 'snapshot', { name });
    }

    /**
     * Get an action for a Droplet
     * @param {number} dropletId - Droplet ID
     * @param {number} actionId - Action ID
     * @returns {Promise<Object>} Action object
     */
    async getAction(dropletId, actionId) {
        const data = await this.client.get(`droplets/${dropletId}/actions/${actionId}`);
        return data.action;
    }

    /**
     * List all actions for a Droplet
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Array>} Array of actions
     */
    async listActions(dropletId) {
        return this.client.getAllPages(`droplets/${dropletId}/actions`, {}, 'actions');
    }
}

module.exports = DropletService;

