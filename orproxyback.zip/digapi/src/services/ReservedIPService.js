/**
 * DigitalOcean Reserved IP Service
 */

/**
 * Service for managing DigitalOcean Reserved IPs (formerly Floating IPs)
 */
class ReservedIPService {
    /**
     * Create a new ReservedIPService instance
     * @param {DOClient} client - DOClient instance
     */
    constructor(client) {
        this.client = client;
    }

    /**
     * List all Reserved IPs
     * @param {Object} options - List options
     * @param {number} options.page - Page number
     * @param {number} options.perPage - Items per page
     * @param {boolean} options.allPages - Fetch all pages (default: true)
     * @returns {Promise<Array>} Array of Reserved IPs
     */
    async list(options = {}) {
        const { page, perPage, allPages = true } = options;

        const params = {};
        if (page) params.page = page;
        if (perPage) params.per_page = perPage;

        if (allPages && !page) {
            // Fetch all pages
            return this.client.getAllPages('reserved_ips', params, 'reserved_ips');
        } else {
            // Fetch single page
            const data = await this.client.get('reserved_ips', params);
            return data.reserved_ips || [];
        }
    }

    /**
     * Get a single Reserved IP
     * @param {string} ip - Reserved IP address
     * @returns {Promise<Object>} Reserved IP object
     */
    async get(ip) {
        const data = await this.client.get(`reserved_ips/${ip}`);
        return data.reserved_ip;
    }

    /**
     * Create a new Reserved IP
     * @param {Object} ipData - Reserved IP creation data
     * @param {string} ipData.region - Region slug (required if droplet_id not provided)
     * @param {number} ipData.droplet_id - Droplet ID to assign to (optional)
     * @returns {Promise<Object>} Created Reserved IP object
     */
    async create(ipData) {
        const data = await this.client.post('reserved_ips', ipData);
        return data.reserved_ip;
    }

    /**
     * Delete a Reserved IP
     * @param {string} ip - Reserved IP address
     * @returns {Promise<void>}
     */
    async delete(ip) {
        await this.client.delete(`reserved_ips/${ip}`);
    }

    /**
     * Perform an action on a Reserved IP
     * @param {string} ip - Reserved IP address
     * @param {string} actionType - Action type
     * @param {Object} additionalParams - Additional action parameters
     * @returns {Promise<Object>} Action object
     * @private
     */
    async _performAction(ip, actionType, additionalParams = {}) {
        const data = await this.client.post(`reserved_ips/${ip}/actions`, {
            type: actionType,
            ...additionalParams
        });
        return data.action;
    }

    /**
     * Assign a Reserved IP to a Droplet
     * @param {string} ip - Reserved IP address
     * @param {number} dropletId - Droplet ID
     * @returns {Promise<Object>} Action object
     */
    async assign(ip, dropletId) {
        return this._performAction(ip, 'assign', { droplet_id: dropletId });
    }

    /**
     * Unassign a Reserved IP from its Droplet
     * @param {string} ip - Reserved IP address
     * @returns {Promise<Object>} Action object
     */
    async unassign(ip) {
        return this._performAction(ip, 'unassign');
    }

    /**
     * Get an action for a Reserved IP
     * @param {string} ip - Reserved IP address
     * @param {number} actionId - Action ID
     * @returns {Promise<Object>} Action object
     */
    async getAction(ip, actionId) {
        const data = await this.client.get(`reserved_ips/${ip}/actions/${actionId}`);
        return data.action;
    }

    /**
     * List all actions for a Reserved IP
     * @param {string} ip - Reserved IP address
     * @returns {Promise<Array>} Array of actions
     */
    async listActions(ip) {
        return this.client.getAllPages(`reserved_ips/${ip}/actions`, {}, 'actions');
    }
}

module.exports = ReservedIPService;

