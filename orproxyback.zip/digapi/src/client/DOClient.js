/**
 * DigitalOcean API HTTP Client
 */

const axios = require('axios');
const { parseError } = require('../utils/errors');
const { withRetry } = require('../utils/retry');

/**
 * DigitalOcean API HTTP Client
 */
class DOClient {
    /**
     * Create a new DOClient instance
     * @param {string} token - DigitalOcean API token
     * @param {Object} options - Client options
     * @param {string} options.baseURL - Base URL for API (default: https://api.digitalocean.com/v2/)
     * @param {number} options.timeout - Request timeout in milliseconds (default: 30000)
     * @param {boolean} options.debug - Enable debug logging (default: false)
     * @param {Object} options.retryOptions - Retry options
     * @param {string} options.account - Account name for error tracking
     */
    constructor(token, options = {}) {
        this.token = token;
        this.account = options.account || null;
        this.debug = options.debug || false;
        this.retryOptions = options.retryOptions || {};

        // Create axios instance
        this.client = axios.create({
            baseURL: options.baseURL || 'https://api.digitalocean.com/v2/',
            timeout: options.timeout || 30000,
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        // Setup interceptors
        this._setupInterceptors();

        // Rate limit tracking
        this.rateLimit = {
            limit: null,
            remaining: null,
            reset: null
        };
    }

    /**
     * Setup request and response interceptors
     * @private
     */
    _setupInterceptors() {
        // Request interceptor
        this.client.interceptors.request.use(
            (config) => {
                if (this.debug) {
                    console.log(`[DOClient] ${config.method.toUpperCase()} ${config.url}`);
                }
                return config;
            },
            (error) => {
                return Promise.reject(error);
            }
        );

        // Response interceptor
        this.client.interceptors.response.use(
            (response) => {
                // Extract rate limit information
                this._extractRateLimit(response.headers);

                if (this.debug) {
                    console.log(`[DOClient] Response: ${response.status}`);
                    console.log(`[DOClient] Rate Limit: ${this.rateLimit.remaining}/${this.rateLimit.limit}`);
                }

                return response;
            },
            (error) => {
                // Convert to custom error
                const customError = parseError(error, this.account);

                if (this.debug) {
                    console.error(`[DOClient] Error: ${customError.name} - ${customError.message}`);
                }

                return Promise.reject(customError);
            }
        );
    }

    /**
     * Extract rate limit information from response headers
     * @param {Object} headers - Response headers
     * @private
     */
    _extractRateLimit(headers) {
        if (headers['ratelimit-limit']) {
            this.rateLimit.limit = parseInt(headers['ratelimit-limit']);
        }
        if (headers['ratelimit-remaining']) {
            this.rateLimit.remaining = parseInt(headers['ratelimit-remaining']);
        }
        if (headers['ratelimit-reset']) {
            this.rateLimit.reset = parseInt(headers['ratelimit-reset']);
        }
    }

    /**
     * Make a request with retry logic
     * @param {string} method - HTTP method
     * @param {string} endpoint - API endpoint
     * @param {Object} data - Request data
     * @param {Object} config - Additional axios config
     * @returns {Promise<*>} Response data
     */
    async request(method, endpoint, data = null, config = {}) {
        const requestFn = async () => {
            const axiosConfig = {
                method,
                url: endpoint,
                ...config
            };

            if (data) {
                if (method.toLowerCase() === 'get') {
                    axiosConfig.params = data;
                } else {
                    axiosConfig.data = data;
                }
            }

            const response = await this.client.request(axiosConfig);
            return response.data;
        };

        return withRetry(requestFn, {
            ...this.retryOptions,
            onRetry: (error, attempt, delay) => {
                if (this.debug) {
                    console.log(`[DOClient] Retrying after ${delay}ms (attempt ${attempt + 1})`);
                }
            }
        });
    }

    /**
     * Make a GET request
     * @param {string} endpoint - API endpoint
     * @param {Object} params - Query parameters
     * @param {Object} config - Additional axios config
     * @returns {Promise<*>} Response data
     */
    async get(endpoint, params = {}, config = {}) {
        return this.request('GET', endpoint, params, config);
    }

    /**
     * Make a POST request
     * @param {string} endpoint - API endpoint
     * @param {Object} data - Request body
     * @param {Object} config - Additional axios config
     * @returns {Promise<*>} Response data
     */
    async post(endpoint, data = {}, config = {}) {
        return this.request('POST', endpoint, data, config);
    }

    /**
     * Make a PUT request
     * @param {string} endpoint - API endpoint
     * @param {Object} data - Request body
     * @param {Object} config - Additional axios config
     * @returns {Promise<*>} Response data
     */
    async put(endpoint, data = {}, config = {}) {
        return this.request('PUT', endpoint, data, config);
    }

    /**
     * Make a DELETE request
     * @param {string} endpoint - API endpoint
     * @param {Object} config - Additional axios config
     * @returns {Promise<*>} Response data
     */
    async delete(endpoint, config = {}) {
        return this.request('DELETE', endpoint, null, config);
    }

    /**
     * Get all pages of a paginated resource
     * @param {string} endpoint - API endpoint
     * @param {Object} params - Query parameters
     * @param {string} resourceKey - Key in response containing the resources (e.g., 'droplets')
     * @returns {Promise<Array>} All resources
     */
    async getAllPages(endpoint, params = {}, resourceKey) {
        const allResources = [];
        let page = 1;
        let hasMore = true;

        while (hasMore) {
            const data = await this.get(endpoint, { ...params, page, per_page: 200 });

            if (data[resourceKey] && data[resourceKey].length > 0) {
                allResources.push(...data[resourceKey]);
            }

            // Check if there are more pages
            hasMore = data.links && data.links.pages && data.links.pages.next;
            page++;
        }

        return allResources;
    }

    /**
     * Get current rate limit status
     * @returns {Object} Rate limit information
     */
    getRateLimit() {
        return { ...this.rateLimit };
    }
}

module.exports = DOClient;

