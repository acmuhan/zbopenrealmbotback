/**
 * Multi-Account Manager for DigitalOcean
 */

const DOClient = require('../client/DOClient');
const DropletService = require('../services/DropletService');
const ReservedIPService = require('../services/ReservedIPService');
const { ConfigError } = require('../utils/errors');

/**
 * Manager for handling multiple DigitalOcean accounts
 */
class AccountManager {
    /**
     * Create a new AccountManager instance
     * @param {Object} config - Configuration object
     * @param {Object} options - Manager options
     * @param {boolean} options.debug - Enable debug logging
     * @param {Object} options.retryOptions - Retry options for all clients
     */
    constructor(config, options = {}) {
        this.config = config;
        this.options = options;
        this.accounts = new Map();

        // Initialize all accounts
        this._initializeAccounts();
    }

    /**
     * Initialize all accounts from configuration
     * @private
     */
    _initializeAccounts() {
        if (!this.config.accounts) {
            throw new ConfigError('No accounts in configuration');
        }

        for (const [name, accountConfig] of Object.entries(this.config.accounts)) {
            this._createAccount(name, accountConfig.token);
        }
    }

    /**
     * Create account services
     * @param {string} name - Account name
     * @param {string} token - Account token
     * @private
     */
    _createAccount(name, token) {
        // Create client
        const client = new DOClient(token, {
            ...this.options,
            account: name
        });

        // Create services
        const services = {
            client,
            droplets: new DropletService(client),
            reservedIPs: new ReservedIPService(client)
        };

        this.accounts.set(name, services);
    }

    /**
     * Get services for a specific account
     * @param {string} accountName - Account name
     * @returns {Object} Account services
     * @throws {ConfigError} If account not found
     */
    getAccount(accountName) {
        const services = this.accounts.get(accountName);
        if (!services) {
            throw new ConfigError(`Account not found: ${accountName}`);
        }
        return services;
    }

    /**
     * List all configured account names
     * @returns {Array<string>} Array of account names
     */
    listAccounts() {
        return Array.from(this.accounts.keys());
    }

    /**
     * Check if an account exists
     * @param {string} accountName - Account name
     * @returns {boolean} True if account exists
     */
    hasAccount(accountName) {
        return this.accounts.has(accountName);
    }

    /**
     * Add a new account at runtime
     * @param {string} name - Account name
     * @param {string} token - Account token
     * @throws {ConfigError} If account already exists
     */
    addAccount(name, token) {
        if (this.accounts.has(name)) {
            throw new ConfigError(`Account already exists: ${name}`);
        }

        this._createAccount(name, token);

        // Update config
        if (!this.config.accounts) {
            this.config.accounts = {};
        }
        this.config.accounts[name] = { token };
    }

    /**
     * Remove an account
     * @param {string} name - Account name
     * @throws {ConfigError} If account not found
     */
    removeAccount(name) {
        if (!this.accounts.has(name)) {
            throw new ConfigError(`Account not found: ${name}`);
        }

        this.accounts.delete(name);

        // Update config
        if (this.config.accounts) {
            delete this.config.accounts[name];
        }
    }

    /**
     * Execute a function for all accounts in parallel
     * @param {Function} fn - Function to execute (receives accountName and services)
     * @returns {Promise<Array>} Array of results with account names
     */
    async executeForAll(fn) {
        const accountNames = this.listAccounts();
        return this.executeForAccounts(accountNames, fn);
    }

    /**
     * Execute a function for specific accounts in parallel
     * @param {Array<string>} accountNames - Account names
     * @param {Function} fn - Function to execute (receives accountName and services)
     * @returns {Promise<Array>} Array of results with account names and errors
     */
    async executeForAccounts(accountNames, fn) {
        const promises = accountNames.map(async (accountName) => {
            try {
                const services = this.getAccount(accountName);
                const result = await fn(accountName, services);
                return {
                    account: accountName,
                    success: true,
                    data: result,
                    error: null
                };
            } catch (error) {
                return {
                    account: accountName,
                    success: false,
                    data: null,
                    error: error
                };
            }
        });

        return Promise.all(promises);
    }

    /**
     * Get all Droplets from all accounts
     * @returns {Promise<Array>} Array of Droplets with account information
     */
    async getAllDroplets() {
        const results = await this.executeForAll(async (accountName, services) => {
            const droplets = await services.droplets.list();
            return droplets.map(droplet => ({
                ...droplet,
                _account: accountName
            }));
        });

        // Flatten and filter successful results
        return results
            .filter(r => r.success)
            .flatMap(r => r.data);
    }

    /**
     * Get all Reserved IPs from all accounts
     * @returns {Promise<Array>} Array of Reserved IPs with account information
     */
    async getAllReservedIPs() {
        const results = await this.executeForAll(async (accountName, services) => {
            const ips = await services.reservedIPs.list();
            return ips.map(ip => ({
                ...ip,
                _account: accountName
            }));
        });

        // Flatten and filter successful results
        return results
            .filter(r => r.success)
            .flatMap(r => r.data);
    }

    /**
     * Get rate limit status for all accounts
     * @returns {Promise<Object>} Rate limit status by account
     */
    async getRateLimits() {
        const rateLimits = {};

        for (const [accountName, services] of this.accounts.entries()) {
            rateLimits[accountName] = services.client.getRateLimit();
        }

        return rateLimits;
    }

    /**
     * Find Droplets across all accounts by name
     * @param {string} name - Droplet name (supports partial match)
     * @returns {Promise<Array>} Matching Droplets with account information
     */
    async findDropletsByName(name) {
        const allDroplets = await this.getAllDroplets();
        const searchTerm = name.toLowerCase();

        return allDroplets.filter(droplet =>
            droplet.name.toLowerCase().includes(searchTerm)
        );
    }

    /**
     * Find Reserved IPs across all accounts by IP address
     * @param {string} ip - IP address (supports partial match)
     * @returns {Promise<Array>} Matching Reserved IPs with account information
     */
    async findReservedIPsByIP(ip) {
        const allIPs = await this.getAllReservedIPs();

        return allIPs.filter(reservedIP =>
            reservedIP.ip.includes(ip)
        );
    }
}

module.exports = AccountManager;

