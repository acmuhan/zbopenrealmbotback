/**
 * DigitalOcean SDK Entry Point
 */

const { loadConfig, loadConfigWithEnv, createConfig } = require('./utils/config');
const AccountManager = require('./managers/AccountManager');

/**
 * DigitalOcean SDK
 */
class DigitalOceanSDK {
    /**
     * Create a new SDK instance
     * @param {Object|string} configOrPath - Configuration object or path to config file
     * @param {Object} options - SDK options
     * @param {boolean} options.debug - Enable debug logging
     * @param {Object} options.retryOptions - Retry options
     */
    constructor(configOrPath, options = {}) {
        // Load configuration
        let config;
        if (typeof configOrPath === 'string') {
            config = loadConfig(configOrPath);
        } else if (typeof configOrPath === 'object') {
            config = configOrPath;
        } else {
            throw new Error('Configuration must be a path string or configuration object');
        }

        // Create account manager
        this.manager = new AccountManager(config, options);
        this.options = options;
    }

    /**
     * Get services for a specific account
     * @param {string} accountName - Account name
     * @returns {Object} Account services (droplets, reservedIPs, client)
     */
    account(accountName) {
        return this.manager.getAccount(accountName);
    }

    /**
     * Get the account manager
     * @returns {AccountManager} Account manager instance
     */
    accounts() {
        return this.manager;
    }

    /**
     * List all configured account names
     * @returns {Array<string>} Array of account names
     */
    listAccounts() {
        return this.manager.listAccounts();
    }

    /**
     * Add a new account at runtime
     * @param {string} name - Account name
     * @param {string} token - Account token
     */
    addAccount(name, token) {
        this.manager.addAccount(name, token);
    }

    /**
     * Remove an account
     * @param {string} name - Account name
     */
    removeAccount(name) {
        this.manager.removeAccount(name);
    }

    /**
     * Get all Droplets from all accounts
     * @returns {Promise<Array>} Array of Droplets with account information
     */
    async listAllDroplets() {
        return this.manager.getAllDroplets();
    }

    /**
     * Get all Reserved IPs from all accounts
     * @returns {Promise<Array>} Array of Reserved IPs with account information
     */
    async listAllReservedIPs() {
        return this.manager.getAllReservedIPs();
    }

    /**
     * Find Droplets across all accounts by name
     * @param {string} name - Droplet name
     * @returns {Promise<Array>} Matching Droplets
     */
    async findDroplets(name) {
        return this.manager.findDropletsByName(name);
    }

    /**
     * Find Reserved IPs across all accounts by IP address
     * @param {string} ip - IP address
     * @returns {Promise<Array>} Matching Reserved IPs
     */
    async findReservedIPs(ip) {
        return this.manager.findReservedIPsByIP(ip);
    }

    /**
     * Get rate limit status for all accounts
     * @returns {Promise<Object>} Rate limit status by account
     */
    async getRateLimits() {
        return this.manager.getRateLimits();
    }

    /**
     * Execute a function for all accounts
     * @param {Function} fn - Function to execute (receives accountName and services)
     * @returns {Promise<Array>} Array of results
     */
    async executeForAll(fn) {
        return this.manager.executeForAll(fn);
    }

    /**
     * Execute a function for specific accounts
     * @param {Array<string>} accountNames - Account names
     * @param {Function} fn - Function to execute
     * @returns {Promise<Array>} Array of results
     */
    async executeForAccounts(accountNames, fn) {
        return this.manager.executeForAccounts(accountNames, fn);
    }
}

/**
 * Create a new SDK instance
 * @param {Object|string} configOrPath - Configuration object or path to config file
 * @param {Object} options - SDK options
 * @returns {DigitalOceanSDK} SDK instance
 */
function createSDK(configOrPath, options = {}) {
    return new DigitalOceanSDK(configOrPath, options);
}

/**
 * Create SDK with configuration from environment variables
 * @param {Object} options - SDK options
 * @returns {DigitalOceanSDK} SDK instance
 */
function createSDKFromEnv(options = {}) {
    const config = loadConfigWithEnv();
    return new DigitalOceanSDK(config, options);
}

/**
 * Create SDK with accounts map
 * @param {Object} accounts - Map of account name to token
 * @param {Object} options - SDK options
 * @returns {DigitalOceanSDK} SDK instance
 */
function createSDKFromAccounts(accounts, options = {}) {
    const config = createConfig(accounts);
    return new DigitalOceanSDK(config, options);
}

// Export SDK class and factory functions
module.exports = {
    DigitalOceanSDK,
    createSDK,
    createSDKFromEnv,
    createSDKFromAccounts,
    // Export classes for advanced usage
    AccountManager: require('./managers/AccountManager'),
    DOClient: require('./client/DOClient'),
    DropletService: require('./services/DropletService'),
    ReservedIPService: require('./services/ReservedIPService'),
    // Export errors
    errors: require('./utils/errors')
};

