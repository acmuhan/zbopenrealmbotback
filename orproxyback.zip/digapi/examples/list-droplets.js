/**
 * Example: List all Droplets from all accounts
 */

const { createSDK } = require('../src/index');
const path = require('path');

async function main() {
    try {
        // Create SDK instance
        const configPath = path.join(__dirname, '../config/accounts.json');
        const sdk = createSDK(configPath, { debug: true });

        console.log('=== Configured Accounts ===');
        const accounts = sdk.listAccounts();
        console.log(`Found ${accounts.length} accounts: ${accounts.join(', ')}\n`);

        // Example 1: List Droplets for a specific account
        console.log('=== Example 1: List Droplets for specific account ===');
        const accountName = accounts[0];
        const account = sdk.account(accountName);
        const droplets = await account.droplets.list();

        console.log(`Account: ${accountName}`);
        console.log(`Total Droplets: ${droplets.length}\n`);

        droplets.forEach(droplet => {
            console.log(`- ${droplet.name} (ID: ${droplet.id})`);
            console.log(`  Status: ${droplet.status}`);
            console.log(`  Region: ${droplet.region.name}`);
            console.log(`  Size: ${droplet.size.slug}`);
            console.log(`  IP: ${droplet.networks.v4[0]?.ip_address || 'N/A'}`);
            console.log('');
        });

        // Example 2: List all Droplets from all accounts
        console.log('=== Example 2: List all Droplets from all accounts ===');
        const allDroplets = await sdk.listAllDroplets();
        console.log(`Total Droplets across all accounts: ${allDroplets.length}\n`);

        // Group by account
        const byAccount = {};
        allDroplets.forEach(droplet => {
            const account = droplet._account;
            if (!byAccount[account]) {
                byAccount[account] = [];
            }
            byAccount[account].push(droplet);
        });

        Object.entries(byAccount).forEach(([account, droplets]) => {
            console.log(`${account}: ${droplets.length} Droplets`);
            droplets.forEach(d => {
                console.log(`  - ${d.name} (${d.networks.v4[0]?.ip_address || 'N/A'})`);
            });
            console.log('');
        });

        // Example 3: Find Droplets by name
        console.log('=== Example 3: Find Droplets by name ===');
        const searchTerm = 'web'; // Change this to search for specific Droplets
        const found = await sdk.findDroplets(searchTerm);
        console.log(`Found ${found.length} Droplets matching "${searchTerm}":\n`);

        found.forEach(droplet => {
            console.log(`- ${droplet.name} (Account: ${droplet._account})`);
            console.log(`  IP: ${droplet.networks.v4[0]?.ip_address || 'N/A'}`);
            console.log('');
        });

        // Example 4: Get rate limit status
        console.log('=== Example 4: Rate Limit Status ===');
        const rateLimits = await sdk.getRateLimits();
        Object.entries(rateLimits).forEach(([account, limits]) => {
            console.log(`${account}:`);
            console.log(`  Remaining: ${limits.remaining}/${limits.limit}`);
            if (limits.reset) {
                const resetDate = new Date(limits.reset * 1000);
                console.log(`  Reset: ${resetDate.toLocaleString()}`);
            }
            console.log('');
        });

    } catch (error) {
        console.error('Error:', error.name);
        console.error('Message:', error.message);
        if (error.account) {
            console.error('Account:', error.account);
        }
        if (error.statusCode) {
            console.error('Status Code:', error.statusCode);
        }
        process.exit(1);
    }
}

// Run the example
main();

