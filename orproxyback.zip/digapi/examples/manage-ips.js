/**
 * Example: Manage Reserved IPs (create, assign, unassign, delete)
 */

const { createSDK } = require('../src/index');
const path = require('path');

async function main() {
    try {
        // Create SDK instance
        const configPath = path.join(__dirname, '../config/accounts.json');
        const sdk = createSDK(configPath, { debug: false });

        const accounts = sdk.listAccounts();
        const accountName = accounts[0]; // Use first account
        const account = sdk.account(accountName);

        console.log(`Using account: ${accountName}\n`);

        // Example 1: List all Reserved IPs
        console.log('=== Example 1: List all Reserved IPs ===');
        const ips = await account.reservedIPs.list();
        console.log(`Total Reserved IPs: ${ips.length}\n`);

        ips.forEach(ip => {
            console.log(`- IP: ${ip.ip}`);
            console.log(`  Region: ${ip.region.name}`);
            if (ip.droplet) {
                console.log(`  Assigned to: Droplet ${ip.droplet.id}`);
            } else {
                console.log(`  Assigned to: None`);
            }
            console.log('');
        });

        // Example 2: List all Reserved IPs from all accounts
        console.log('=== Example 2: List Reserved IPs from all accounts ===');
        const allIPs = await sdk.listAllReservedIPs();
        console.log(`Total Reserved IPs across all accounts: ${allIPs.length}\n`);

        allIPs.forEach(ip => {
            console.log(`- ${ip.ip} (Account: ${ip._account}, Region: ${ip.region.name})`);
        });
        console.log('');

        // Example 3: Create a new Reserved IP
        console.log('=== Example 3: Create a Reserved IP ===');
        console.log('Creating a new Reserved IP in nyc3...');

        const newIP = await account.reservedIPs.create({
            region: 'nyc3'
        });

        console.log(`Created: ${newIP.ip}`);
        console.log(`Region: ${newIP.region.name}\n`);

        const ipAddress = newIP.ip;

        // Example 4: Get Reserved IP details
        console.log('=== Example 4: Get Reserved IP Details ===');
        const ipDetails = await account.reservedIPs.get(ipAddress);
        console.log(`IP: ${ipDetails.ip}`);
        console.log(`Region: ${ipDetails.region.name}`);
        console.log(`Assigned: ${ipDetails.droplet ? 'Yes' : 'No'}\n`);

        // Example 5: Assign Reserved IP to a Droplet (if you have one)
        console.log('=== Example 5: Assign Reserved IP to Droplet ===');

        // First, check if we have any Droplets
        const droplets = await account.droplets.list();

        if (droplets.length > 0) {
            const droplet = droplets[0];
            console.log(`Assigning ${ipAddress} to Droplet ${droplet.name} (ID: ${droplet.id})...`);

            const assignAction = await account.reservedIPs.assign(ipAddress, droplet.id);
            console.log(`Assignment initiated (Action ID: ${assignAction.id})`);
            console.log(`Status: ${assignAction.status}\n`);

            // Wait a bit
            await sleep(3000);

            // Example 6: Unassign Reserved IP
            console.log('=== Example 6: Unassign Reserved IP ===');
            console.log(`Unassigning ${ipAddress} from Droplet...`);

            const unassignAction = await account.reservedIPs.unassign(ipAddress);
            console.log(`Unassignment initiated (Action ID: ${unassignAction.id})`);
            console.log(`Status: ${unassignAction.status}\n`);

            // Wait a bit
            await sleep(3000);
        } else {
            console.log('No Droplets available for assignment demo. Skipping...\n');
        }

        // Example 7: List Reserved IP actions
        console.log('=== Example 7: List Reserved IP Actions ===');
        const actions = await account.reservedIPs.listActions(ipAddress);
        console.log(`Total actions: ${actions.length}`);
        actions.forEach(action => {
            console.log(`- ${action.type}: ${action.status} (${action.started_at})`);
        });
        console.log('');

        // Example 8: Delete Reserved IP
        console.log('=== Example 8: Delete Reserved IP ===');
        console.log(`Deleting Reserved IP ${ipAddress}...`);
        await account.reservedIPs.delete(ipAddress);
        console.log('Reserved IP deleted successfully!\n');

        console.log('All examples completed!');

    } catch (error) {
        console.error('Error:', error.name);
        console.error('Message:', error.message);
        if (error.account) {
            console.error('Account:', error.account);
        }
        if (error.statusCode) {
            console.error('Status Code:', error.statusCode);
        }
        process.exit(1);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Run the example
main();

