/**
 * Example: Manage Droplets (create, reboot, shutdown, delete)
 */

const { createSDK } = require('../src/index');
const path = require('path');

async function main() {
    try {
        // Create SDK instance
        const configPath = path.join(__dirname, '../config/accounts.json');
        const sdk = createSDK(configPath, { debug: false });

        const accounts = sdk.listAccounts();
        const accountName = accounts[0]; // Use first account
        const account = sdk.account(accountName);

        console.log(`Using account: ${accountName}\n`);

        // Example 1: Create a new Droplet
        console.log('=== Example 1: Create a Droplet ===');
        console.log('Creating a new Droplet...');

        const dropletData = {
            name: 'example-droplet-' + Date.now(),
            region: 'nyc3',
            size: 's-1vcpu-1gb',
            image: 'ubuntu-22-04-x64',
            tags: ['example', 'nodejs-sdk']
        };

        const newDroplet = await account.droplets.create(dropletData);
        console.log(`Created: ${newDroplet.name} (ID: ${newDroplet.id})`);
        console.log(`Status: ${newDroplet.status}`);
        console.log(`Region: ${newDroplet.region.name}\n`);

        const dropletId = newDroplet.id;

        // Wait for Droplet to be active
        console.log('Waiting for Droplet to become active...');
        let droplet = await account.droplets.get(dropletId);
        while (droplet.status !== 'active') {
            await sleep(5000);
            droplet = await account.droplets.get(dropletId);
            console.log(`Status: ${droplet.status}`);
        }
        console.log('Droplet is now active!\n');

        // Example 2: Get Droplet details
        console.log('=== Example 2: Get Droplet Details ===');
        droplet = await account.droplets.get(dropletId);
        console.log(`Name: ${droplet.name}`);
        console.log(`Status: ${droplet.status}`);
        console.log(`IPv4: ${droplet.networks.v4[0]?.ip_address || 'N/A'}`);
        console.log(`IPv6: ${droplet.networks.v6[0]?.ip_address || 'N/A'}\n`);

        // Example 3: Reboot Droplet
        console.log('=== Example 3: Reboot Droplet ===');
        const rebootAction = await account.droplets.reboot(dropletId);
        console.log(`Reboot initiated (Action ID: ${rebootAction.id})`);
        console.log(`Status: ${rebootAction.status}\n`);

        // Wait a bit
        await sleep(3000);

        // Example 4: Power off Droplet
        console.log('=== Example 4: Power Off Droplet ===');
        const powerOffAction = await account.droplets.powerOff(dropletId);
        console.log(`Power off initiated (Action ID: ${powerOffAction.id})`);

        // Wait for power off
        console.log('Waiting for Droplet to power off...');
        await sleep(10000);

        // Example 5: Power on Droplet
        console.log('\n=== Example 5: Power On Droplet ===');
        const powerOnAction = await account.droplets.powerOn(dropletId);
        console.log(`Power on initiated (Action ID: ${powerOnAction.id})\n`);

        // Wait for power on
        await sleep(10000);

        // Example 6: List Droplet actions
        console.log('=== Example 6: List Droplet Actions ===');
        const actions = await account.droplets.listActions(dropletId);
        console.log(`Total actions: ${actions.length}`);
        actions.slice(0, 5).forEach(action => {
            console.log(`- ${action.type}: ${action.status} (${action.started_at})`);
        });
        console.log('');

        // Example 7: Delete Droplet
        console.log('=== Example 7: Delete Droplet ===');
        console.log(`Deleting Droplet ${dropletId}...`);
        await account.droplets.delete(dropletId);
        console.log('Droplet deleted successfully!\n');

        console.log('All examples completed!');

    } catch (error) {
        console.error('Error:', error.name);
        console.error('Message:', error.message);
        if (error.account) {
            console.error('Account:', error.account);
        }
        if (error.statusCode) {
            console.error('Status Code:', error.statusCode);
        }
        process.exit(1);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Run the example
main();

