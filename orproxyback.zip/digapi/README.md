# DigitalOcean API SDK

A Node.js SDK for managing DigitalOcean resources with multi-account support, built for automated operations and batch management.

## Features

- ✅ **Multi-Account Management** - Manage multiple DigitalOcean accounts simultaneously
- ✅ **Droplet Operations** - Create, delete, reboot, shutdown, and manage Droplets
- ✅ **Reserved IP Management** - Create, assign, unassign, and delete Reserved IPs
- ✅ **Automatic Retry** - Built-in retry logic with exponential backoff
- ✅ **Rate Limit Handling** - Automatic rate limit detection and handling
- ✅ **Concurrent Operations** - Execute operations across multiple accounts in parallel
- ✅ **Error Handling** - Comprehensive error classes for different failure scenarios

## Installation

This SDK is part of the `orproxyback` project. No separate installation is required.

## Quick Start

### 1. Configuration

Create a configuration file `config/accounts.json`:

```json
{
    "accounts": {
        "production": {
            "token": "your_production_token"
        },
        "staging": {
            "token": "your_staging_token"
        }
    }
}
```

**Important**: Never commit your `accounts.json` file with real tokens. Use `accounts.example.json` as a template.

### 2. Basic Usage

```javascript
const { createSDK } = require('./digapi/src/index');

// Create SDK instance
const sdk = createSDK('./digapi/config/accounts.json');

// List all accounts
console.log(sdk.listAccounts());

// Use a specific account
const account = sdk.account('production');

// List Droplets
const droplets = await account.droplets.list();
console.log(droplets);

// Get Droplet details
const droplet = await account.droplets.get(dropletId);

// Reboot a Droplet
await account.droplets.reboot(dropletId);
```

## API Reference

### SDK Creation

#### `createSDK(configPath, options)`

Create a new SDK instance from a configuration file.

```javascript
const sdk = createSDK('./config/accounts.json', {
    debug: true,  // Enable debug logging
    retryOptions: {
        maxRetries: 3,
        initialDelay: 1000
    }
});
```

#### `createSDKFromAccounts(accounts, options)`

Create SDK directly from an accounts object.

```javascript
const sdk = createSDKFromAccounts({
    production: 'token1',
    staging: 'token2'
});
```

### Account Management

#### `sdk.account(accountName)`

Get services for a specific account.

```javascript
const account = sdk.account('production');
const droplets = await account.droplets.list();
```

#### `sdk.listAccounts()`

List all configured account names.

```javascript
const accounts = sdk.listAccounts();
// ['production', 'staging']
```

#### `sdk.addAccount(name, token)`

Add a new account at runtime.

```javascript
sdk.addAccount('new-account', 'token');
```

### Droplet Operations

#### List Droplets

```javascript
// List all Droplets for an account
const droplets = await account.droplets.list();

// List with pagination
const droplets = await account.droplets.list({ 
    page: 1, 
    perPage: 50,
    allPages: false 
});

// Filter by tag
const droplets = await account.droplets.list({ tag: 'web' });
```

#### Get Droplet

```javascript
const droplet = await account.droplets.get(dropletId);
console.log(droplet.name, droplet.status);
```

#### Create Droplet

```javascript
const droplet = await account.droplets.create({
    name: 'my-droplet',
    region: 'nyc3',
    size: 's-1vcpu-1gb',
    image: 'ubuntu-22-04-x64',
    ssh_keys: [12345],
    tags: ['web', 'production']
});
```

#### Delete Droplet

```javascript
await account.droplets.delete(dropletId);
```

#### Droplet Actions

```javascript
// Reboot (graceful restart)
await account.droplets.reboot(dropletId);

// Shutdown (graceful)
await account.droplets.shutdown(dropletId);

// Power off (force)
await account.droplets.powerOff(dropletId);

// Power on
await account.droplets.powerOn(dropletId);

// Power cycle
await account.droplets.powerCycle(dropletId);

// Resize
await account.droplets.resize(dropletId, 's-2vcpu-2gb');

// Rebuild
await account.droplets.rebuild(dropletId, 'ubuntu-22-04-x64');

// Rename
await account.droplets.rename(dropletId, 'new-name');

// Take snapshot
await account.droplets.snapshot(dropletId, 'snapshot-name');
```

### Reserved IP Operations

#### List Reserved IPs

```javascript
const ips = await account.reservedIPs.list();
```

#### Get Reserved IP

```javascript
const ip = await account.reservedIPs.get('192.168.1.1');
```

#### Create Reserved IP

```javascript
// Create in a region
const ip = await account.reservedIPs.create({ region: 'nyc3' });

// Create and assign to Droplet
const ip = await account.reservedIPs.create({ 
    region: 'nyc3',
    droplet_id: dropletId 
});
```

#### Assign Reserved IP

```javascript
await account.reservedIPs.assign('192.168.1.1', dropletId);
```

#### Unassign Reserved IP

```javascript
await account.reservedIPs.unassign('192.168.1.1');
```

#### Delete Reserved IP

```javascript
await account.reservedIPs.delete('192.168.1.1');
```

### Multi-Account Operations

#### List All Droplets

```javascript
// Get Droplets from all accounts
const allDroplets = await sdk.listAllDroplets();

// Each Droplet has an _account property
allDroplets.forEach(droplet => {
    console.log(`${droplet.name} (${droplet._account})`);
});
```

#### List All Reserved IPs

```javascript
const allIPs = await sdk.listAllReservedIPs();
```

#### Find Resources

```javascript
// Find Droplets by name across all accounts
const found = await sdk.findDroplets('web');

// Find Reserved IPs by IP address
const ips = await sdk.findReservedIPs('192.168');
```

#### Execute Custom Operations

```javascript
// Execute for all accounts
const results = await sdk.executeForAll(async (accountName, services) => {
    const droplets = await services.droplets.list();
    return { account: accountName, count: droplets.length };
});

// Execute for specific accounts
const results = await sdk.executeForAccounts(
    ['production', 'staging'],
    async (accountName, services) => {
        // Your operation
    }
);
```

### Rate Limit Monitoring

```javascript
// Get rate limit status for all accounts
const rateLimits = await sdk.getRateLimits();
console.log(rateLimits);
// {
//   production: { limit: 5000, remaining: 4950, reset: 1234567890 },
//   staging: { limit: 5000, remaining: 4980, reset: 1234567890 }
// }
```

## Error Handling

The SDK provides specific error classes for different scenarios:

```javascript
const { errors } = require('./digapi/src/index');

try {
    await account.droplets.get(dropletId);
} catch (error) {
    if (error instanceof errors.ResourceNotFoundError) {
        console.log('Droplet not found');
    } else if (error instanceof errors.RateLimitError) {
        console.log('Rate limit exceeded, retry after:', error.retryAfter);
    } else if (error instanceof errors.AuthenticationError) {
        console.log('Invalid token');
    } else if (error instanceof errors.NetworkError) {
        console.log('Network error:', error.message);
    }
}
```

### Error Types

- `DOError` - Base error class
- `NetworkError` - Network/connection errors
- `APIError` - Generic API errors
- `RateLimitError` - Rate limit exceeded (HTTP 429)
- `AuthenticationError` - Authentication failed (HTTP 401/403)
- `ResourceNotFoundError` - Resource not found (HTTP 404)
- `ValidationError` - Validation error (HTTP 422)
- `ServerError` - Server error (HTTP 5xx)
- `ConfigError` - Configuration error

## Examples

Check the `examples/` directory for complete working examples:

- `list-droplets.js` - List and search Droplets across accounts
- `manage-droplets.js` - Create, manage, and delete Droplets
- `manage-ips.js` - Manage Reserved IPs

Run examples:

```bash
cd digapi
node examples/list-droplets.js
node examples/manage-droplets.js
node examples/manage-ips.js
```

## Configuration Options

### SDK Options

```javascript
const sdk = createSDK(configPath, {
    debug: false,           // Enable debug logging
    retryOptions: {
        maxRetries: 3,      // Maximum retry attempts
        initialDelay: 1000, // Initial delay in ms
        maxDelay: 30000     // Maximum delay in ms
    }
});
```

### Retry Behavior

The SDK automatically retries:
- Network errors
- Rate limit errors (HTTP 429)
- Server errors (HTTP 5xx)

It does NOT retry:
- Authentication errors (HTTP 401/403)
- Validation errors (HTTP 422)
- Resource not found (HTTP 404)
- Other client errors (HTTP 4xx)

## Best Practices

1. **Token Security**: Never commit tokens to version control. Use environment variables or secure configuration management.

2. **Rate Limits**: Monitor rate limits when performing bulk operations:
   ```javascript
   const limits = await sdk.getRateLimits();
   console.log(limits);
   ```

3. **Error Handling**: Always wrap API calls in try-catch blocks and handle specific error types.

4. **Parallel Operations**: Use multi-account operations carefully to avoid hitting rate limits.

5. **Pagination**: For large resource lists, the SDK automatically fetches all pages by default. Set `allPages: false` if you only need a single page.

## Troubleshooting

### "Account not found" error

Make sure your `accounts.json` file is properly formatted and the account name matches.

### Rate limit errors

The SDK automatically retries with appropriate delays. If you still hit limits, reduce concurrent operations.

### Network errors

Check your internet connection and DigitalOcean API status.

## License

Part of the orproxyback project.

## Support

For issues and questions, refer to the main project documentation.

