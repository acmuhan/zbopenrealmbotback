/**
 * 获取 DigitalOcean Droplet 信息
 * 运行: node get-droplet-info.js
 */

const { createSDK } = require('./digapi/src/index.js')
const path = require('path')

async function main() {
    try {
        // 初始化 SDK
        const sdk = createSDK(path.resolve(__dirname, './digapi/config/accounts.json'))

        // 获取第一个账号
        const accounts = sdk.listAccounts()
        console.log('\n📋 可用账号:', accounts)

        if (accounts.length === 0) {
            console.error('❌ 没有找到配置的账号')
            return
        }

        const accountName = accounts[0]
        console.log(`\n🔍 使用账号: ${accountName}`)

        const account = sdk.account(accountName)

        // 获取所有 Droplets
        console.log('\n⏳ 正在获取 Droplets...')
        const droplets = await account.droplets.list()

        if (!droplets || droplets.length === 0) {
            console.log('❌ 没有找到任何 Droplet')
            return
        }

        console.log(`\n✅ 找到 ${droplets.length} 个 Droplet:\n`)
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')

        droplets.forEach((droplet, index) => {
            console.log(`\n${index + 1}. ${droplet.name}`)
            console.log(`   ID: ${droplet.id}`)
            console.log(`   状态: ${droplet.status}`)
            console.log(`   区域: ${droplet.region.slug}`)
            console.log(`   IP地址: ${droplet.networks?.v4?.[0]?.ip_address || '无'}`)
            console.log(`   创建时间: ${droplet.created_at}`)
        })

        console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        console.log('\n📝 请将上面的 Droplet ID 更新到 config/machines.json')
        console.log('\n示例配置:')
        console.log(JSON.stringify({
            machines: droplets.map(d => ({
                machine_name: d.name,
                droplet_id: d.id,
                account_name: accountName,
                region: d.region.slug,
                zbproxy_port: 8000
            }))
        }, null, 2))

    } catch (error) {
        console.error('\n❌ 错误:', error.message)
        if (error.response) {
            console.error('响应:', error.response)
        }
    }
}

main()

