# 🚀 Koishi 机器人启动指南

## 方案 1: 本地开发模式（推荐用于测试）

### 步骤 1: 准备环境

确保已安装：
- ✅ Node.js 18+ (推荐 LTS 版本)
- ✅ MySQL 数据库

### 步骤 2: 在父目录创建 Koishi 实例

```powershell
# 回到父目录
cd ..

# 创建 Koishi 实例（如果还没有）
npm init koishi

# 或者直接安装 Koishi
npm install koishi
```

### 步骤 3: 链接本地插件

```powershell
# 在插件目录中创建链接
cd koishi-plugin-orproxy
npm link

# 回到 Koishi 实例目录
cd ..

# 链接插件
npm link koishi-plugin-orproxy
```

### 步骤 4: 配置 koishi.yml

编辑 `koishi.yml` 文件：

```yaml
host: 127.0.0.1
port: 5140

# 数据库配置
plugins:
  database-mysql:
    host: localhost
    port: 3306
    user: root
    password: your_password
    database: koishi

  # Discord 适配器
  adapter-discord:
    token: YOUR_DISCORD_BOT_TOKEN
    intents:
      - GUILDS
      - GUILD_MESSAGES
      - DIRECT_MESSAGES

  # 或者使用 Kook 适配器
  # adapter-kook:
  #   token: YOUR_KOOK_BOT_TOKEN

  # orproxy 插件配置
  orproxy:
    machineConfigPath: ./config/machines.json
    blacklistPath: ./config/blackip.json
    digapiConfigPath: ./digapi/config/accounts.json
    defaultTimeout: 60000
    autoCleanBlacklist: true
    cleanInterval: 3600000
```

### 步骤 5: 配置必要文件

#### 1. 配置 DigitalOcean API Token

创建或编辑 `digapi/config/accounts.json`：

```json
{
  "accounts": {
    "production": {
      "token": "dop_v1_your_digitalocean_api_token_here"
    }
  }
}
```

**获取 DigitalOcean API Token**：
1. 登录 https://cloud.digitalocean.com/
2. 进入 API → Tokens
3. 点击 "Generate New Token"
4. 设置读写权限，生成并复制 Token

#### 2. 配置机器信息

创建或编辑 `config/machines.json`：

```json
{
  "machines": [
    {
      "machine_name": "my-server",
      "droplet_id": 123456789,
      "account_name": "production",
      "region": "nyc3",
      "zbproxy_port": 8000
    }
  ]
}
```

**获取 Droplet ID**：
```bash
curl -X GET \
  -H "Authorization: Bearer YOUR_TOKEN" \
  "https://api.digitalocean.com/v2/droplets"
```

#### 3. 初始化黑名单文件

创建 `config/blackip.json`：

```json
[]
```

### 步骤 6: 启动 Koishi

```powershell
# 启动开发模式（支持热重载）
npm run dev

# 或者正式启动
npm start
```

启动成功后，浏览器会自动打开 Koishi 控制台：
- 地址：http://localhost:5140
- 默认用户名：admin（首次启动会要求设置）

---

## 方案 2: 生产环境部署

### 使用 PM2 管理进程

```bash
# 安装 PM2
npm install -g pm2

# 启动 Koishi
pm2 start npm --name koishi -- start

# 查看状态
pm2 status

# 查看日志
pm2 logs koishi

# 停止
pm2 stop koishi

# 重启
pm2 restart koishi

# 设置开机自启
pm2 startup
pm2 save
```

---

## 方案 3: Docker 部署

创建 `Dockerfile`：

```dockerfile
FROM node:18-alpine

WORKDIR /app

# 复制项目文件
COPY package*.json ./
COPY koishi-plugin-orproxy ./koishi-plugin-orproxy
COPY config ./config
COPY digapi ./digapi
COPY koishi.yml ./

# 安装依赖
RUN npm install

# 构建插件
WORKDIR /app/koishi-plugin-orproxy
RUN npm run build

WORKDIR /app

# 暴露端口
EXPOSE 5140

# 启动
CMD ["npm", "start"]
```

创建 `docker-compose.yml`：

```yaml
version: '3.8'

services:
  koishi:
    build: .
    ports:
      - "5140:5140"
    environment:
      - NODE_ENV=production
    volumes:
      - ./config:/app/config
      - ./data:/app/data
    depends_on:
      - mysql
    restart: unless-stopped

  mysql:
    image: mysql:8
    environment:
      MYSQL_ROOT_PASSWORD: your_password
      MYSQL_DATABASE: koishi
    volumes:
      - mysql_data:/var/lib/mysql
    restart: unless-stopped

volumes:
  mysql_data:
```

启动：

```bash
docker-compose up -d
```

---

## 验证启动成功

### 1. 检查控制台

访问 http://localhost:5140，应该能看到 Koishi 控制台。

### 2. 检查插件加载

在控制台的"插件配置"页面，应该能看到 `orproxy` 插件。

### 3. 测试指令

在 Discord/Kook 中发送：

```
orproxy.list
```

应该返回机器列表。

---

## 常见启动问题

### 1. 端口被占用

**错误**: `Error: listen EADDRINUSE: address already in use :::5140`

**解决**:
```powershell
# Windows
netstat -ano | findstr :5140
taskkill /F /PID <PID>

# 或修改 koishi.yml 中的端口号
```

### 2. 数据库连接失败

**错误**: `ER_ACCESS_DENIED_ERROR: Access denied for user`

**解决**:
1. 检查 MySQL 是否运行
2. 验证 koishi.yml 中的数据库配置
3. 确保数据库用户有足够权限

### 3. 插件加载失败

**错误**: `Cannot find module 'koishi-plugin-orproxy'`

**解决**:
```bash
# 确保插件已构建
cd koishi-plugin-orproxy
npm run build

# 重新链接
npm link
cd ..
npm link koishi-plugin-orproxy
```

### 4. DigitalOcean API 错误

**错误**: `Unauthorized` 或 `401`

**解决**:
1. 检查 API Token 是否有效
2. 确认 Token 有读写权限
3. 验证 `digapi/config/accounts.json` 路径正确

### 5. Discord/Kook 连接失败

**错误**: `Invalid token`

**解决**:
1. 确认 Bot Token 正确
2. Discord: 检查 Intents 配置
3. Kook: 确认 Token 格式正确

---

## 开发模式特性

使用 `npm run dev` 启动时，Koishi 会启用以下特性：

1. **热重载**: 修改插件代码后自动重载，无需重启
2. **详细日志**: 显示更多调试信息
3. **沙盒模式**: 可以在控制台直接测试指令

---

## 生产环境建议

1. **使用环境变量**

创建 `.env` 文件：

```env
# 数据库配置
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=your_password
MYSQL_DATABASE=koishi

# API Token
DIGITALOCEAN_TOKEN=dop_v1_xxxxx
DISCORD_TOKEN=xxxxx
```

修改 koishi.yml 使用环境变量：

```yaml
plugins:
  database-mysql:
    host: ${MYSQL_HOST}
    user: ${MYSQL_USER}
    password: ${MYSQL_PASSWORD}
    database: ${MYSQL_DATABASE}
```

2. **启用日志**

```yaml
plugins:
  logger:
    levels:
      base: 2
      adapter: 3
```

3. **配置反向代理**

使用 Nginx 作为反向代理：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5140;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## 监控和维护

### 查看日志

```bash
# 实时查看日志
tail -f logs/koishi.log

# PM2 日志
pm2 logs koishi

# Docker 日志
docker-compose logs -f koishi
```

### 数据库维护

```sql
-- 查看 IP 历史
SELECT * FROM orproxy_ip_history ORDER BY created_at DESC LIMIT 10;

-- 查看机器锁
SELECT * FROM orproxy_machine_locks;

-- 清理旧数据（保留 30 天）
DELETE FROM orproxy_ip_history 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
```

---

## 快速启动检查清单

- [ ] Node.js 18+ 已安装
- [ ] MySQL 数据库已运行
- [ ] `koishi.yml` 已配置
- [ ] `digapi/config/accounts.json` 已配置
- [ ] `config/machines.json` 已配置
- [ ] `config/blackip.json` 已创建
- [ ] Discord/Kook Bot Token 已配置
- [ ] 插件已构建（`npm run build`）
- [ ] 依赖已安装（`npm install`）
- [ ] 准备启动！

---

**祝您使用愉快！** 🎉

如有问题，请参考 DEPLOYMENT.md 或查看 Koishi 官方文档：https://koishi.chat/

