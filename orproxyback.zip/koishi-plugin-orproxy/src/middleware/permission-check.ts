import { Context, Next, Session } from 'koishi'
import { Logger } from '../utils/logger'
import { PermissionService } from '../services/permission'

/**
 * 权限检查中间件
 * 在每个命令执行前自动检查用户权限是否过期
 */
export function registerPermissionCheckMiddleware(
    ctx: Context,
    permissionService: PermissionService
) {
    const logger = new Logger(ctx, 'orproxy:permission-check')

    ctx.middleware(async (session: Session, next: Next) => {
        // 只处理有用户信息的会话
        if (session.user) {
            const userId = session.userId
            const platform = session.platform

            if (userId && platform) {
                try {
                    // 检查权限是否过期
                    const isExpired = await permissionService.checkExpired(userId, platform)

                    if (isExpired) {
                        // 权限已过期，会在 checkExpired 中自动更新数据库
                        logger.info(`权限已过期并已降级: ${userId} (${platform})`)
                    }
                } catch (error) {
                    // 权限检查失败不应阻断命令执行，只记录错误
                    logger.error(`权限检查失败: ${userId} (${platform})`, error)
                }
            }
        }

        // 继续执行后续中间件和命令
        return next()
    })

    logger.info('权限检查中间件已注册')
}

