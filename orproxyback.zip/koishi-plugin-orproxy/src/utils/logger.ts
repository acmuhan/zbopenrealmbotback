/**
 * 日志工具封装
 */

import { Context } from 'koishi'

export class Logger {
    constructor(private ctx: Context, private namespace: string = 'orproxy') { }

    info(message: string, ...args: any[]) {
        this.ctx.logger(this.namespace).info(message, ...args)
    }

    warn(message: string, ...args: any[]) {
        this.ctx.logger(this.namespace).warn(message, ...args)
    }

    error(message: string, ...args: any[]) {
        this.ctx.logger(this.namespace).error(message, ...args)
    }

    debug(message: string, ...args: any[]) {
        this.ctx.logger(this.namespace).debug(message, ...args)
    }

    /**
     * 记录操作历史到数据库
     */
    async logHistory(data: {
        machine_name: string
        old_ip?: string
        new_ip: string
        action: 'start' | 'stop' | 'switch'
        user_id: string
        adapter_type: string
        status: 'success' | 'failed' | 'rolled_back'
        error_message?: string
    }) {
        try {
            await this.ctx.database.create('orproxy_ip_history', {
                ...data,
                created_at: new Date()
            })
        } catch (error) {
            this.error('记录历史失败:', error)
        }
    }
}

