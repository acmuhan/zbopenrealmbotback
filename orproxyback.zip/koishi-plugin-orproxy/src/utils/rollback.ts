/**
 * 事务回滚框架
 * 支持操作失败时自动回滚所有已执行的操作
 */

import { Context } from 'koishi'
import { Logger } from './logger'

/**
 * 操作接口
 */
export interface Operation<T = any> {
    /**
     * 操作名称
     */
    name: string

    /**
     * 执行操作
     */
    execute(): Promise<T>

    /**
     * 回滚操作
     */
    rollback(): Promise<void>
}

/**
 * 事务类
 */
export class Transaction {
    private operations: Operation[] = []
    private results: Map<string, any> = new Map()

    constructor(private logger: Logger) { }

    /**
     * 执行操作并记录
     */
    async execute<T>(operation: Operation<T>): Promise<T> {
        this.logger.debug(`执行操作: ${operation.name}`)

        try {
            const result = await operation.execute()
            this.operations.push(operation)
            this.results.set(operation.name, result)

            this.logger.debug(`操作成功: ${operation.name}`)
            return result
        } catch (error) {
            this.logger.error(`操作失败: ${operation.name}`, error)
            throw error
        }
    }

    /**
     * 获取操作结果
     */
    getResult<T>(operationName: string): T | undefined {
        return this.results.get(operationName)
    }

    /**
     * 回滚所有已执行的操作
     */
    async rollback(): Promise<void> {
        this.logger.warn(`开始回滚 ${this.operations.length} 个操作`)

        // 按相反顺序回滚
        const reversedOps = [...this.operations].reverse()

        for (const op of reversedOps) {
            try {
                this.logger.debug(`回滚操作: ${op.name}`)
                await op.rollback()
                this.logger.debug(`回滚成功: ${op.name}`)
            } catch (error) {
                this.logger.error(`回滚失败: ${op.name}`, error)
                // 继续回滚其他操作
            }
        }

        this.operations = []
        this.results.clear()
        this.logger.info('回滚完成')
    }

    /**
     * 清空事务（不回滚）
     */
    clear(): void {
        this.operations = []
        this.results.clear()
    }
}

/**
 * 创建 Reserved IP 操作
 */
export class CreateIPOperation implements Operation<string> {
    name = 'CreateIP'
    private createdIP?: string

    constructor(
        private doService: any,
        private region: string
    ) { }

    async execute(): Promise<string> {
        const result = await this.doService.createIP(this.region)
        this.createdIP = result.ip
        return this.createdIP || ''
    }

    async rollback(): Promise<void> {
        if (this.createdIP) {
            await this.doService.deleteIP(this.createdIP)
        }
    }
}

/**
 * 分配 IP 操作
 */
export class AssignIPOperation implements Operation<void> {
    name = 'AssignIP'

    constructor(
        private doService: any,
        private ip: string,
        private dropletId: number,
        private oldIP?: string
    ) { }

    async execute(): Promise<void> {
        await this.doService.assignIP(this.ip, this.dropletId)
    }

    async rollback(): Promise<void> {
        // 解绑当前 IP
        await this.doService.unassignIP(this.ip)

        // 如果有旧 IP，重新分配回去
        if (this.oldIP) {
            try {
                await this.doService.assignIP(this.oldIP, this.dropletId)
            } catch (error) {
                // 旧 IP 可能已被删除，忽略错误
            }
        }
    }
}

/**
 * 删除 IP 操作
 */
export class DeleteIPOperation implements Operation<void> {
    name = 'DeleteIP'

    constructor(
        private doService: any,
        private ip: string
    ) { }

    async execute(): Promise<void> {
        await this.doService.deleteIP(this.ip)
    }

    async rollback(): Promise<void> {
        // IP 删除后无法恢复，记录日志
        // 实际回滚会在更高层级处理（重新创建）
    }
}

/**
 * 重启 ZBProxy 操作
 */
export class RestartZBProxyOperation implements Operation<void> {
    name = 'RestartZBProxy'

    constructor(
        private zbproxyService: any,
        private ip: string,
        private port: number
    ) { }

    async execute(): Promise<void> {
        await this.zbproxyService.restart(this.ip, this.port)
    }

    async rollback(): Promise<void> {
        // ZBProxy 重启操作无需回滚
        // 如果需要，可以再次重启
    }
}

/**
 * 停止 ZBProxy 操作
 */
export class StopZBProxyOperation implements Operation<void> {
    name = 'StopZBProxy'

    constructor(
        private zbproxyService: any,
        private ip: string,
        private port: number
    ) { }

    async execute(): Promise<void> {
        await this.zbproxyService.stop(this.ip, this.port)
    }

    async rollback(): Promise<void> {
        // 尝试重新启动
        try {
            await this.zbproxyService.start(this.ip, this.port)
        } catch (error) {
            // 启动失败，忽略
        }
    }
}

/**
 * 添加黑名单操作
 */
export class AddBlacklistOperation implements Operation<void> {
    name = 'AddBlacklist'

    constructor(
        private blacklistService: any,
        private ip: string,
        private machineName: string,
        private userId: string,
        private adapterType: string,
        private reason: string
    ) { }

    async execute(): Promise<void> {
        await this.blacklistService.add(
            this.ip,
            this.machineName,
            this.userId,
            this.adapterType,
            this.reason
        )
    }

    async rollback(): Promise<void> {
        await this.blacklistService.remove(this.ip)
    }
}

