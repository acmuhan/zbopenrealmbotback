/**
 * Koishi Plugin: orproxy
 * 管理 DigitalOcean Reserved IP 和 ZBProxy
 */

import { Context, Schema } from 'koishi'
import { } from './models/database'
import * as path from 'path'
import * as fs from 'fs'
import * as yaml from 'js-yaml'

export const name = 'orproxy'

export const inject = ['database']

// 加载国际化文件
function loadLocale(lang: string) {
    try {
        // 编译后路径是 lib/../locales/
        const localePath = path.resolve(__dirname, `../locales/${lang}.yml`)
        const content = fs.readFileSync(localePath, 'utf8')
        return yaml.load(content) as any
    } catch (error) {
        console.error(`[orproxy] Failed to load locale ${lang}:`, error)
        return {}
    }
}

export const locales = {
    'zh-CN': loadLocale('zh-CN'),
    'en-US': loadLocale('en-US')
}

/**
 * 插件配置接口
 */
export interface Config {
    machineConfigPath: string
    blacklistPath: string
    digapiConfigPath: string
    defaultTimeout: number
    autoCleanBlacklist: boolean
    cleanInterval: number
    // Minecraft 监控配置
    enableMonitoring: boolean
    monitorCheckInterval: number
    monitorAutoStopMinutes: number
    monitorMaxFailures: number
}

/**
 * 插件配置 Schema
 */
export const Config: Schema<Config> = Schema.object({
    machineConfigPath: Schema.string()
        .default('./config/machines.json')
        .description('机器配置文件路径'),
    blacklistPath: Schema.string()
        .default('./config/blackip.json')
        .description('黑名单文件路径'),
    digapiConfigPath: Schema.string()
        .default('./digapi/config/accounts.json')
        .description('DigitalOcean API 配置文件路径'),
    defaultTimeout: Schema.number()
        .default(60000)
        .description('默认超时时间（毫秒）'),
    autoCleanBlacklist: Schema.boolean()
        .default(true)
        .description('自动清理过期黑名单'),
    cleanInterval: Schema.number()
        .default(3600000)
        .description('清理间隔时间（毫秒）'),
    enableMonitoring: Schema.boolean()
        .default(false)
        .description('启用 Minecraft 服务器监控'),
    monitorCheckInterval: Schema.number()
        .default(20)
        .description('监控检查间隔（秒）'),
    monitorAutoStopMinutes: Schema.number()
        .default(15)
        .description('无人多久后自动停机（分钟）'),
    monitorMaxFailures: Schema.number()
        .default(5)
        .description('最大连续失败次数')
}).description('orproxy 插件配置')

/**
 * 插件主函数
 */
export function apply(ctx: Context, config: Config) {
    // 注册 i18n 翻译到 Koishi
    for (const [lang, data] of Object.entries(locales)) {
        ctx.i18n.define(lang, data)
    }

    // 扩展数据库表 - IP 切换历史
    ctx.database.extend('orproxy_ip_history', {
        id: 'unsigned',
        machine_name: 'string',
        old_ip: 'string',
        new_ip: 'string',
        action: 'string',
        user_id: 'string',
        adapter_type: 'string',
        status: 'string',
        error_message: 'text',
        created_at: 'timestamp'
    }, {
        autoInc: true,
        primary: 'id'
    })

    // 扩展数据库表 - 机器锁
    ctx.database.extend('orproxy_machine_locks', {
        machine_name: 'string',
        user_id: 'string',
        adapter_type: 'string',
        locked_at: 'timestamp'
    }, {
        primary: 'machine_name'
    })

    // 扩展数据库表 - 用户封禁
    ctx.database.extend('orproxy_user_bans', {
        id: 'unsigned',
        user_id: 'string',
        platform: 'string',
        reason: 'text',
        banned_at: 'timestamp',
        banned_until: 'timestamp',
        banned_by: 'string'
    }, {
        autoInc: true,
        primary: 'id'
    })

    ctx.database.extend('orproxy_custom_servers', {
        id: 'unsigned',
        user_id: 'string',
        platform: 'string',
        machine_name: 'string',
        server_address: 'string',
        server_port: 'unsigned',
        description: 'text',
        created_at: 'timestamp',
        updated_at: 'timestamp'
    }, {
        autoInc: true,
        primary: 'id'
    })

    // 扩展数据库表 - 激活卡密
    ctx.database.extend('orproxy_activation_keys', {
        id: 'unsigned',
        key_code: 'string',
        permission_level: 'integer',
        duration_days: 'integer',
        status: 'string',
        note: 'text',
        created_at: 'timestamp',
        created_by: 'string',
        used_at: 'timestamp',
        used_by: 'string',
        used_platform: 'string'
    }, {
        autoInc: true,
        primary: 'id',
        unique: ['key_code']
    })

    // 扩展数据库表 - 用户权限
    ctx.database.extend('orproxy_user_permissions', {
        id: 'unsigned',
        user_id: 'string',
        platform: 'string',
        permission_level: 'integer',
        granted_at: 'timestamp',
        expires_at: 'timestamp',
        last_key_used: 'string'
    }, {
        autoInc: true,
        primary: 'id',
        unique: [['user_id', 'platform']]
    })

    // 插件日志
    const logger = ctx.logger('orproxy')

    // 插件启动
    ctx.on('ready', async () => {
        logger.info('orproxy 插件已加载')
        logger.info(`机器配置: ${config.machineConfigPath}`)
        logger.info(`黑名单配置: ${config.blacklistPath}`)
        logger.info(`DigitalOcean 配置: ${config.digapiConfigPath}`)

        // 初始化数据库表
        await ctx.database.get('orproxy_ip_history', {}, { limit: 1 })
            .catch(() => logger.info('IP 历史表已就绪'))
        await ctx.database.get('orproxy_machine_locks', {}, { limit: 1 })
            .catch(() => logger.info('机器锁表已就绪'))
        await ctx.database.get('orproxy_user_bans', {}, { limit: 1 })
            .catch(() => logger.info('用户封禁表已就绪'))
    })

    // 初始化所有服务
    logger.info('正在初始化服务...')

    const doService = new (require('./services/digitalocean').DigitalOceanService)(
        ctx,
        config.digapiConfigPath
    )

    const zbproxyService = new (require('./services/zbproxy').ZBProxyService)(
        ctx,
        config.defaultTimeout
    )

    const blacklistService = new (require('./services/blacklist').BlacklistService)(
        ctx,
        config.blacklistPath,
        config.autoCleanBlacklist,
        config.cleanInterval
    )

    const lockService = new (require('./services/lock').MachineLockService)(ctx)

    const machineService = new (require('./services/machine').MachineService)(
        ctx,
        config.machineConfigPath,
        doService,
        zbproxyService
    )

    // Minecraft 服务
    const minecraftService = new (require('./services/minecraft').MinecraftService)(ctx)

    // 封禁服务
    const banService = new (require('./services/ban').BanService)(ctx)

    // 维护模式服务
    const maintenanceService = new (require('./services/maintenance').MaintenanceService)(
        ctx,
        machineService
    )

    // 监控服务
    const monitorService = new (require('./services/monitor').MonitorService)(
        ctx,
        {
            enabled: config.enableMonitoring,
            checkInterval: config.monitorCheckInterval,
            autoStopMinutes: config.monitorAutoStopMinutes,
            maxFailures: config.monitorMaxFailures
        },
        minecraftService,
        machineService,
        lockService
    )

    // 启动监控
    if (config.enableMonitoring) {
        monitorService.start()
    }

    // 定期清理过期封禁记录
    ctx.setInterval(() => {
        banService.cleanExpiredBans()
    }, 3600000)  // 每小时清理一次

    logger.info('所有服务初始化完成')

    // 注册指令
    logger.info('正在注册指令...')

    const { registerStartCommand } = require('./commands/start-new')
    const { registerStopCommand } = require('./commands/stop')
    const { registerListCommand } = require('./commands/list')
    const { registerAdminCommands } = require('./commands/admin')
    const { registerCustomServerCommands } = require('./commands/customserver')
    const { registerActivationKeyCommands } = require('./commands/activation-key')
    const { registerRedeemCommands } = require('./commands/redeem')

    // 初始化 CustomServerService
    const customServerService = new (require('./services/custom-server').CustomServerService)(ctx)

    // 初始化卡密服务
    const activationKeyService = new (require('./services/activation-key').ActivationKeyService)(ctx)

    // 初始化权限服务
    const permissionService = new (require('./services/permission').PermissionService)(ctx)

    // 注册权限检查中间件
    const { registerPermissionCheckMiddleware } = require('./middleware/permission-check')
    registerPermissionCheckMiddleware(ctx, permissionService)

    // 定期清理过期权限
    ctx.setInterval(() => {
        permissionService.cleanExpiredPermissions()
    }, 3600000)  // 每小时清理一次

    // 创建命令组
    ctx.command('orproxy', '服务器管理工具')

    // 注册所有指令
    registerStartCommand(
        ctx,
        doService,
        zbproxyService,
        blacklistService,
        machineService,
        lockService,
        banService,
        maintenanceService,
        monitorService
    )
    registerStopCommand(ctx, doService, zbproxyService, blacklistService, machineService, lockService)
    registerListCommand(ctx, machineService)
    registerAdminCommands(
        ctx,
        maintenanceService,
        banService,
        lockService,
        machineService,
        doService,
        zbproxyService,
        blacklistService
    )
    registerCustomServerCommands(ctx, customServerService)
    registerActivationKeyCommands(ctx, activationKeyService)
    registerRedeemCommands(ctx, activationKeyService, permissionService)

    logger.info('所有指令注册完成')

    // 插件停止时清理资源
    ctx.on('dispose', () => {
        logger.info('正在清理资源...')
        blacklistService.dispose()
        monitorService.stop()
        logger.info('orproxy 插件已卸载')
    })
}

