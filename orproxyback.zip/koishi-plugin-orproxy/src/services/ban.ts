/**
 * 用户封禁服务
 * 管理用户的封禁状态（滥用自动停机等）
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { UserBan } from '../models/database'

export class BanService {
    private logger: Logger

    constructor(private ctx: Context) {
        this.logger = new Logger(ctx, 'orproxy:ban')
    }

    /**
     * 检查用户是否被封禁
     */
    async isUserBanned(userId: string, platform: string): Promise<UserBan | null> {
        try {
            const now = new Date()

            const bans = await this.ctx.database.get('orproxy_user_bans', {
                user_id: userId,
                platform: platform
            })

            // 查找有效的封禁记录
            for (const ban of bans) {
                if (ban.banned_until > now) {
                    return ban
                }
            }

            return null
        } catch (error) {
            this.logger.error('检查封禁状态失败:', error)
            return null
        }
    }

    /**
     * 封禁用户
     */
    async banUser(
        userId: string,
        platform: string,
        reason: string,
        durationHours: number,
        bannedBy: string
    ): Promise<void> {
        try {
            const now = new Date()
            const bannedUntil = new Date(now.getTime() + durationHours * 60 * 60 * 1000)

            await this.ctx.database.create('orproxy_user_bans', {
                user_id: userId,
                platform: platform,
                reason: reason,
                banned_at: now,
                banned_until: bannedUntil,
                banned_by: bannedBy
            })

            this.logger.info(`用户已封禁: ${userId} (${platform}), 时长: ${durationHours}小时, 原因: ${reason}`)
        } catch (error) {
            this.logger.error('封禁用户失败:', error)
            throw error
        }
    }

    /**
     * 解封用户
     */
    async unbanUser(userId: string, platform: string): Promise<void> {
        try {
            await this.ctx.database.remove('orproxy_user_bans', {
                user_id: userId,
                platform: platform
            })

            this.logger.info(`用户已解封: ${userId} (${platform})`)
        } catch (error) {
            this.logger.error('解封用户失败:', error)
            throw error
        }
    }

    /**
     * 清理过期的封禁记录
     */
    async cleanExpiredBans(): Promise<void> {
        try {
            const now = new Date()

            const allBans = await this.ctx.database.get('orproxy_user_bans', {})
            let removed = 0

            for (const ban of allBans) {
                if (ban.banned_until <= now) {
                    await this.ctx.database.remove('orproxy_user_bans', { id: ban.id })
                    removed++
                }
            }

            if (removed > 0) {
                this.logger.info(`清理过期封禁记录: ${removed} 条`)
            }
        } catch (error) {
            this.logger.error('清理过期封禁记录失败:', error)
        }
    }

    /**
     * 获取所有封禁列表
     */
    async getBanList() {
        try {
            return await this.ctx.database.get('orproxy_user_bans', {})
        } catch (error) {
            this.logger.error('获取封禁列表失败:', error)
            return []
        }
    }
}

