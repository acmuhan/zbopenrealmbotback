/**
 * Minecraft 服务器监控服务
 * 自动监控玩家数量，无人时自动停机
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { MinecraftService } from './minecraft'
import { MachineService } from './machine'
import { MachineLockService } from './lock'

export interface MonitorConfig {
    enabled: boolean
    checkInterval: number      // 检查间隔（秒）
    autoStopMinutes: number    // 无人多久后自动停机（分钟）
    maxFailures: number        // 最大失败次数
}

interface MonitorState {
    emptyStartTime: number | null  // 服务器变空的时间
    failureCount: number           // 连续失败次数
    lastCheckTime: number          // 上次检查时间
}

export class MonitorService {
    private logger: Logger
    private monitorStates: Map<string, MonitorState> = new Map()
    private monitorInterval: NodeJS.Timeout | null = null

    constructor(
        private ctx: Context,
        private config: MonitorConfig,
        private minecraftService: MinecraftService,
        private machineService: MachineService,
        private lockService: MachineLockService
    ) {
        this.logger = new Logger(ctx, 'orproxy:monitor')
    }

    /**
     * 启动监控
     */
    start(): void {
        if (!this.config.enabled) {
            this.logger.info('监控功能已禁用')
            return
        }

        if (this.monitorInterval) {
            this.logger.warn('监控已在运行')
            return
        }

        this.logger.info(`启动监控，检查间隔: ${this.config.checkInterval}秒`)

        this.monitorInterval = setInterval(
            () => this.checkAllMachines(),
            this.config.checkInterval * 1000
        )

        // 立即执行一次检查
        this.checkAllMachines()
    }

    /**
     * 停止监控
     */
    stop(): void {
        if (this.monitorInterval) {
            clearInterval(this.monitorInterval)
            this.monitorInterval = null
            this.logger.info('监控已停止')
        }
    }

    /**
     * 检查所有机器
     */
    private async checkAllMachines(): Promise<void> {
        const machines = this.machineService.listMachines()

        for (const machine of machines) {
            try {
                await this.checkMachine(machine.machine_name, machine.mc_server_ip, machine.mc_server_port)
            } catch (error) {
                this.logger.error(`检查机器失败: ${machine.machine_name}`, error)
            }
        }
    }

    /**
     * 检查单个机器
     */
    private async checkMachine(
        machineName: string,
        serverIp?: string,
        serverPort?: number
    ): Promise<void> {
        // 如果没有配置MC服务器，跳过
        if (!serverIp || !serverPort) {
            return
        }

        // 检查机器是否被锁定
        const isLocked = await this.lockService.isLocked(machineName)
        if (!isLocked) {
            // 机器未运行，清除状态
            this.monitorStates.delete(machineName)
            return
        }

        // 获取或创建监控状态
        let state = this.monitorStates.get(machineName)
        if (!state) {
            state = {
                emptyStartTime: null,
                failureCount: 0,
                lastCheckTime: Date.now()
            }
            this.monitorStates.set(machineName, state)
        }

        // 查询服务器状态
        const status = await this.minecraftService.queryServerSafe(serverIp, serverPort, 2)

        if (!status.online) {
            // 查询失败
            state.failureCount++
            state.lastCheckTime = Date.now()

            if (state.failureCount >= this.config.maxFailures) {
                this.logger.warn(`机器 ${machineName} 连续失败 ${state.failureCount} 次`)
                // 可以选择触发告警或自动停机
            }
            return
        }

        // 查询成功，重置失败计数
        state.failureCount = 0
        state.lastCheckTime = Date.now()

        const playerCount = status.players?.online || 0

        if (playerCount === 0) {
            // 服务器无人
            if (!state.emptyStartTime) {
                // 刚刚变空
                state.emptyStartTime = Date.now()
                this.logger.info(`机器 ${machineName} 当前无玩家`)
            } else {
                // 已经空了一段时间
                const emptyDuration = (Date.now() - state.emptyStartTime) / 1000 / 60 // 分钟

                if (emptyDuration >= this.config.autoStopMinutes) {
                    this.logger.info(`机器 ${machineName} 已空闲 ${emptyDuration.toFixed(1)} 分钟，触发自动停机`)
                    await this.autoStopMachine(machineName)
                } else {
                    this.logger.debug(
                        `机器 ${machineName} 空闲 ${emptyDuration.toFixed(1)}/${this.config.autoStopMinutes} 分钟`
                    )
                }
            }
        } else {
            // 有玩家，重置空闲时间
            if (state.emptyStartTime) {
                this.logger.info(`机器 ${machineName} 有 ${playerCount} 名玩家，重置空闲计时`)
                state.emptyStartTime = null
            }
        }
    }

    /**
     * 自动停机
     */
    private async autoStopMachine(machineName: string): Promise<void> {
        try {
            this.logger.info(`执行自动停机: ${machineName}`)

            // 清除监控状态
            this.monitorStates.delete(machineName)

            // 这里可以调用stop命令的逻辑
            // 由于需要权限和session，这里只记录日志
            // 实际停机需要通过其他方式触发（如API调用或通知管理员）

            this.logger.warn(`机器 ${machineName} 需要停机，请管理员处理`)

            // TODO: 可以通过webhook或其他方式通知管理员

        } catch (error) {
            this.logger.error(`自动停机失败: ${machineName}`, error)
        }
    }

    /**
     * 获取监控状态
     */
    getMonitorState(machineName: string): MonitorState | null {
        return this.monitorStates.get(machineName) || null
    }

    /**
     * 获取所有监控状态
     */
    getAllMonitorStates(): Map<string, MonitorState> {
        return new Map(this.monitorStates)
    }
}

