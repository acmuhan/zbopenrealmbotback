/**
 * DigitalOcean 服务
 * 封装 digapi SDK，提供 Reserved IP 操作
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import * as path from 'path'

export class DigitalOceanService {
    private sdk: any
    private logger: Logger

    constructor(private ctx: Context, configPath: string) {
        this.logger = new Logger(ctx, 'orproxy:do')

        try {
            // 动态加载 digapi SDK
            const { createSDK } = require(path.resolve(process.cwd(), './digapi/src/index.js'))
            this.sdk = createSDK(path.resolve(process.cwd(), configPath))
            this.logger.info('DigitalOcean SDK 初始化成功')
        } catch (error) {
            this.logger.error('DigitalOcean SDK 初始化失败:', error)
            throw error
        }
    }

    /**
     * 创建 Reserved IP
     */
    async createIP(region: string, accountName?: string): Promise<{ ip: string, data: any }> {
        this.logger.info(`创建 Reserved IP, 区域: ${region}, 账号: ${accountName || '默认'}`)

        try {
            // 使用指定账号或第一个账号
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            const result = await account.reservedIPs.create({ region })
            const ip = result.reserved_ip?.ip || result.ip

            this.logger.info(`Reserved IP 创建成功: ${ip} (账号: ${targetAccount})`)
            return { ip, data: result }
        } catch (error: any) {
            this.logger.error('创建 Reserved IP 失败:', error)
            throw new Error(`创建 IP 失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 删除 Reserved IP（容错：如果不存在则跳过）
     */
    async deleteIP(ip: string, accountName?: string): Promise<void> {
        this.logger.info(`删除 Reserved IP: ${ip}, 账号: ${accountName || '默认'}`)

        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            await account.reservedIPs.delete(ip)
            this.logger.info(`Reserved IP 删除成功: ${ip}`)
        } catch (error: any) {
            const errorMsg = error?.message || ''

            // 容错：如果IP不存在，视为成功
            if (errorMsg.includes('not found') || errorMsg.includes('could not be found')) {
                this.logger.warn(`IP 不存在，跳过删除: ${ip}`)
                return
            }

            this.logger.error(`删除 Reserved IP 失败: ${ip}`, error)
            throw new Error(`删除 IP 失败: ${errorMsg}`)
        }
    }

    /**
     * 分配 Reserved IP 到 Droplet（异步操作，需后续验证）
     */
    async assignIP(ip: string, dropletId: number, accountName?: string): Promise<void> {
        this.logger.info(`[DEBUG] ========== 开始分配 IP ==========`)
        this.logger.info(`[DEBUG] 请求参数:`)
        this.logger.info(`[DEBUG]   - IP: ${ip}`)
        this.logger.info(`[DEBUG]   - Droplet ID: ${dropletId}`)
        this.logger.info(`[DEBUG]   - 账号: ${accountName || '默认'}`)

        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            this.logger.info(`[DEBUG] 使用账号: ${targetAccount}`)

            // 🔍 列出分配前的所有 Reserved IP
            this.logger.info(`[DEBUG] ========== 分配前的 Reserved IP 列表 ==========`)
            const beforeIPs = await account.reservedIPs.list()
            this.logger.info(`[DEBUG] 共 ${beforeIPs.length} 个 Reserved IP:`)
            for (const reservedIP of beforeIPs) {
                this.logger.info(`[DEBUG]   - IP: ${reservedIP.ip} | Droplet: ${reservedIP.droplet?.id || '未分配'} | Region: ${reservedIP.region?.slug}`)
            }

            this.logger.info(`[DEBUG] 调用 reservedIPs.assign(${ip}, ${dropletId})`)

            // 发起分配操作（异步）
            const action = await account.reservedIPs.assign(ip, dropletId)

            // 🔍 DEBUG: 输出完整的 action 对象
            this.logger.info(`[DEBUG] ========== API 响应 ==========`)
            this.logger.info(`[DEBUG] 完整响应内容:`)
            this.logger.info(JSON.stringify(action, null, 2))

            this.logger.info(`[DEBUG] ========== Action 解析 ==========`)
            this.logger.info(`[DEBUG]   - ID: ${action.id}`)
            this.logger.info(`[DEBUG]   - Status: ${action.status}`)
            this.logger.info(`[DEBUG]   - Type: ${action.type}`)
            this.logger.info(`[DEBUG]   - Started: ${action.started_at}`)
            this.logger.info(`[DEBUG]   - Completed: ${action.completed_at || '未完成'}`)
            this.logger.info(`[DEBUG]   - Resource ID: ${action.resource_id}`)
            this.logger.info(`[DEBUG]   - Resource Type: ${action.resource_type}`)
            this.logger.info(`[DEBUG]   - Region: ${action.region?.slug || 'N/A'}`)

            this.logger.info(`IP 分配操作已提交，Action ID: ${action.id}（异步执行中）`)

            // 等待15秒让 DigitalOcean 开始执行 action
            this.logger.info('[DEBUG] 等待 15 秒让 DigitalOcean 处理分配操作...')
            await new Promise(resolve => setTimeout(resolve, 15000))

            // 🔍 列出分配后的所有 Reserved IP
            this.logger.info(`[DEBUG] ========== 分配后的 Reserved IP 列表 ==========`)
            const afterIPs = await account.reservedIPs.list()
            this.logger.info(`[DEBUG] 共 ${afterIPs.length} 个 Reserved IP:`)
            for (const reservedIP of afterIPs) {
                this.logger.info(`[DEBUG]   - IP: ${reservedIP.ip} | Droplet: ${reservedIP.droplet?.id || '未分配'} | Region: ${reservedIP.region?.slug}`)
            }

            // 🔍 特别检查目标 IP
            const targetIP = afterIPs.find((rip: any) => rip.ip === ip)
            if (targetIP) {
                this.logger.info(`[DEBUG] ========== 目标 IP 状态 ==========`)
                this.logger.info(`[DEBUG] IP: ${targetIP.ip}`)
                this.logger.info(`[DEBUG] 分配状态: ${targetIP.droplet ? `已分配到 Droplet ${targetIP.droplet.id}` : '未分配'}`)
                this.logger.info(`[DEBUG] 区域: ${targetIP.region?.slug}`)
            } else {
                this.logger.warn(`[DEBUG] ⚠️ 未找到目标 IP ${ip} 在 Reserved IP 列表中！`)
            }

            this.logger.info('[DEBUG] 等待完成，开始验证...')
        } catch (error: any) {
            this.logger.error(`[DEBUG] ========== 分配 IP 失败 ==========`)
            this.logger.error(`[DEBUG] 错误详情:`, error)
            this.logger.error(`[DEBUG] 错误消息: ${error?.message}`)
            this.logger.error(`[DEBUG] 错误堆栈:`, error?.stack)
            throw new Error(`分配 IP 失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 解绑 Reserved IP（容错：如果未分配则跳过）
     */
    async unassignIP(ip: string, accountName?: string): Promise<void> {
        this.logger.info(`解绑 IP: ${ip}, 账号: ${accountName || '默认'}`)

        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            await account.reservedIPs.unassign(ip)
            this.logger.info(`IP 解绑成功: ${ip}`)
        } catch (error: any) {
            const errorMsg = error?.message || ''

            // 容错：如果IP未分配，视为成功
            if (errorMsg.includes('not assigned') || errorMsg.includes('not found')) {
                this.logger.warn(`IP 未分配或不存在，跳过解绑: ${ip}`)
                return
            }

            this.logger.error(`解绑 IP 失败: ${ip}`, error)
            throw new Error(`解绑 IP 失败: ${errorMsg}`)
        }
    }

    /**
     * 获取 Droplet 的 Reserved IP（只返回浮动IP，不返回主IP）
     * 返回 null 表示机器没有 Reserved IP（未启动状态）
     */
    async getReservedIP(dropletId: number, accountName?: string): Promise<string | null> {
        this.logger.info(`[DEBUG] ========== 查询 Reserved IP ==========`)
        this.logger.info(`[DEBUG] 目标 Droplet ID: ${dropletId}`)
        this.logger.info(`[DEBUG] 账号: ${accountName || '默认'}`)

        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            this.logger.info(`[DEBUG] 使用账号: ${targetAccount}`)
            this.logger.info(`[DEBUG] 调用 reservedIPs.list()`)

            // 查找 Reserved IP
            const reservedIPs = await account.reservedIPs.list()

            // 🔍 DEBUG: 输出完整的 API 响应
            this.logger.info(`[DEBUG] ========== API 响应 ==========`)
            this.logger.info(`[DEBUG] 查询到 ${reservedIPs.length} 个 Reserved IP`)
            this.logger.info(`[DEBUG] 完整列表:`)
            this.logger.info(JSON.stringify(reservedIPs, null, 2))

            this.logger.info(`[DEBUG] ========== 逐个检查 ==========`)
            for (const ip of reservedIPs) {
                this.logger.info(`[DEBUG] Reserved IP: ${ip.ip}`)
                this.logger.info(`[DEBUG]   - droplet: ${JSON.stringify(ip.droplet)}`)
                this.logger.info(`[DEBUG]   - droplet_id: ${ip.droplet?.id || '未分配'}`)
                this.logger.info(`[DEBUG]   - region: ${ip.region?.slug}`)
                this.logger.info(`[DEBUG]   - 匹配? ${ip.droplet?.id === dropletId ? '是' : '否'}`)
            }

            const assignedIP = reservedIPs.find((ip: any) =>
                ip.droplet?.id === dropletId
            )

            if (assignedIP) {
                this.logger.info(`[DEBUG] ✓ 找到匹配的 Reserved IP: ${assignedIP.ip}`)
                return assignedIP.ip
            } else {
                this.logger.warn(`[DEBUG] ✗ 未找到 Droplet ${dropletId} 的 Reserved IP`)
                return null
            }
        } catch (error) {
            this.logger.error(`[DEBUG] ========== 查询失败 ==========`)
            this.logger.error(`查询 Droplet Reserved IP 失败: ${dropletId}`, error)
            return null
        }
    }

    /**
     * 获取 Droplet 当前的 IP（优先 Reserved IP，其次主 IP）
     */
    async getDropletIP(dropletId: number, accountName?: string): Promise<string | null> {
        this.logger.debug(`查询 Droplet IP: ${dropletId}, 账号: ${accountName || '默认'}`)

        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            // 获取 Droplet 信息
            const droplet = await account.droplets.get(dropletId)

            // 查找 Reserved IP
            const reservedIPs = await account.reservedIPs.list()
            const assignedIP = reservedIPs.find((ip: any) =>
                ip.droplet?.id === dropletId
            )

            if (assignedIP) {
                return assignedIP.ip
            }

            // 如果没有 Reserved IP，返回公网 IP
            const publicIP = droplet.networks?.v4?.find((net: any) => net.type === 'public')
            return publicIP?.ip_address || null
        } catch (error) {
            this.logger.error(`查询 Droplet IP 失败: ${dropletId}`, error)
            return null
        }
    }

    /**
     * 获取 Droplet 的主 IP（公网 IP，不包括 Reserved IP）
     */
    async getDropletMainIP(dropletId: number, accountName?: string): Promise<string | null> {
        this.logger.debug(`查询 Droplet 主 IP: ${dropletId}, 账号: ${accountName || '默认'}`)

        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            const droplet = await account.droplets.get(dropletId)

            // 获取公网 IP（v4）
            const publicIP = droplet.networks?.v4?.find((net: any) => net.type === 'public')
            return publicIP?.ip_address || null
        } catch (error) {
            this.logger.error(`查询 Droplet 主 IP 失败: ${dropletId}`, error)
            return null
        }
    }

    /**
     * 获取 Droplet 信息
     */
    async getDroplet(dropletId: number, accountName?: string): Promise<any> {
        try {
            const targetAccount = accountName || this.sdk.listAccounts()[0]
            const account = this.sdk.account(targetAccount)

            return await account.droplets.get(dropletId)
        } catch (error) {
            this.logger.error(`获取 Droplet 信息失败: ${dropletId}`, error)
            throw error
        }
    }

    /**
     * 列出所有 Reserved IPs
     */
    async listReservedIPs(): Promise<any[]> {
        try {
            const accountName = this.sdk.listAccounts()[0]
            const account = this.sdk.account(accountName)

            return await account.reservedIPs.list()
        } catch (error) {
            this.logger.error('列出 Reserved IPs 失败:', error)
            return []
        }
    }

    /**
     * 使用指定账号
     */
    useAccount(accountName: string): any {
        return this.sdk.account(accountName)
    }
}

