/**
 * 维护模式服务
 * 管理机器的维护状态
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { MachineService } from './machine'

export class MaintenanceService {
    private logger: Logger

    constructor(
        private ctx: Context,
        private machineService: MachineService
    ) {
        this.logger = new Logger(ctx, 'orproxy:maintenance')
    }

    /**
     * 检查机器是否处于维护模式
     */
    isInMaintenance(machineName: string): { inMaintenance: boolean; reason?: string } {
        try {
            const machine = this.machineService.getMachine(machineName)

            if (!machine) {
                return { inMaintenance: false }
            }

            return {
                inMaintenance: machine.maintenance_mode || false,
                reason: machine.maintenance_reason
            }
        } catch (error) {
            this.logger.error(`检查维护模式失败: ${machineName}`, error)
            return { inMaintenance: false }
        }
    }

    /**
     * 设置维护模式
     */
    setMaintenance(machineName: string, enabled: boolean, reason?: string): void {
        try {
            const machine = this.machineService.getMachine(machineName)

            if (!machine) {
                throw new Error(`机器不存在: ${machineName}`)
            }

            machine.maintenance_mode = enabled
            machine.maintenance_reason = reason

            // 保存配置（这里假设 MachineService 有保存方法）
            // this.machineService.saveMachines()

            this.logger.info(`维护模式已${enabled ? '开启' : '关闭'}: ${machineName}${reason ? `, 原因: ${reason}` : ''}`)
        } catch (error) {
            this.logger.error(`设置维护模式失败: ${machineName}`, error)
            throw error
        }
    }

    /**
     * 检查用户是否可以绕过维护模式
     */
    canBypassMaintenance(userAuthority: number): boolean {
        return userAuthority >= 3  // 管理员权限（等级3+）
    }
}

