/**
 * 机器管理服务
 * 管理 Droplet 机器配置和状态
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { MachineConfig, MachineStatus } from '../models/database'
import { DigitalOceanService } from './digitalocean'
import { ZBProxyService } from './zbproxy'
import * as fs from 'fs'
import * as path from 'path'

export class MachineService {
    private machines: Map<string, MachineConfig> = new Map()
    private logger: Logger
    private filePath: string

    constructor(
        private ctx: Context,
        configPath: string,
        private doService: DigitalOceanService,
        private zbproxyService: ZBProxyService
    ) {
        this.logger = new Logger(ctx, 'orproxy:machine')
        this.filePath = path.resolve(process.cwd(), configPath)

        this.load()
    }

    /**
     * 从文件加载机器配置
     */
    load(): void {
        try {
            if (fs.existsSync(this.filePath)) {
                const data = fs.readFileSync(this.filePath, 'utf-8')
                const config = JSON.parse(data)

                if (config.machines && Array.isArray(config.machines)) {
                    for (const machine of config.machines) {
                        this.machines.set(machine.machine_name, machine)
                    }
                    this.logger.info(`机器配置加载成功，共 ${this.machines.size} 台机器`)
                } else {
                    this.logger.warn('机器配置文件格式错误')
                }
            } else {
                this.logger.warn('机器配置文件不存在')
            }
        } catch (error) {
            this.logger.error('加载机器配置失败:', error)
        }
    }

    /**
     * 保存机器配置到文件
     */
    save(): void {
        try {
            const config = {
                machines: Array.from(this.machines.values())
            }

            const dir = path.dirname(this.filePath)
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true })
            }

            fs.writeFileSync(
                this.filePath,
                JSON.stringify(config, null, 2),
                'utf-8'
            )
            this.logger.debug('机器配置已保存')
        } catch (error) {
            this.logger.error('保存机器配置失败:', error)
        }
    }

    /**
     * 获取机器配置
     */
    getMachine(machineName: string): MachineConfig | undefined {
        return this.machines.get(machineName)
    }

    /**
     * 列出所有机器
     */
    listMachines(): MachineConfig[] {
        return Array.from(this.machines.values())
    }

    /**
     * 验证机器名称是否存在
     */
    validateMachine(machineName: string): boolean {
        return this.machines.has(machineName)
    }

    /**
     * 添加机器配置
     */
    addMachine(machine: MachineConfig): void {
        this.machines.set(machine.machine_name, machine)
        this.save()
        this.logger.info(`机器已添加: ${machine.machine_name}`)
    }

    /**
     * 删除机器配置
     */
    removeMachine(machineName: string): boolean {
        const deleted = this.machines.delete(machineName)
        if (deleted) {
            this.save()
            this.logger.info(`机器已删除: ${machineName}`)
        }
        return deleted
    }

    /**
     * 更新机器配置
     */
    updateMachine(machineName: string, updates: Partial<MachineConfig>): boolean {
        const machine = this.machines.get(machineName)
        if (!machine) {
            return false
        }

        Object.assign(machine, updates)
        this.save()
        this.logger.info(`机器已更新: ${machineName}`)
        return true
    }

    /**
     * 获取机器状态（快速版本，仅查询 IP 和锁状态）
     */
    async getMachineStatus(machineName: string, includeDetails: boolean = false): Promise<MachineStatus | null> {
        const machine = this.getMachine(machineName)
        if (!machine) {
            this.logger.warn(`机器不存在: ${machineName}`)
            return null
        }

        try {
            // 查询当前 Reserved IP（使用account_name）
            const currentIP = await this.doService.getReservedIP(machine.droplet_id, machine.account_name)

            // 查询机器锁状态
            const locks = await this.ctx.database.get('orproxy_machine_locks', {
                machine_name: machineName
            })
            const isLocked = locks.length > 0
            const lockedBy = isLocked ? `${locks[0].user_id} (${locks[0].adapter_type})` : undefined

            const status: MachineStatus = {
                machine_name: machineName,
                current_ip: currentIP || undefined,
                is_locked: isLocked,
                locked_by: lockedBy,
                last_update: new Date()
            }

            // 仅在需要详细信息时查询 ZBProxy 状态（用于详细查询，list不需要）
            if (includeDetails && currentIP) {
                try {
                    const zbStatus = await this.zbproxyService.getStatus(currentIP, machine.zbproxy_port)
                    status.zbproxy_status = zbStatus.status
                } catch (error) {
                    this.logger.warn(`查询 ZBProxy 状态失败: ${machineName}`, error)
                    status.zbproxy_status = 'unknown'
                }
            }

            return status
        } catch (error) {
            this.logger.error(`获取机器状态失败: ${machineName}`, error)
            return {
                machine_name: machineName,
                is_locked: false,
                last_update: new Date()
            }
        }
    }

    /**
     * 批量获取所有机器状态
     */
    async getAllMachineStatus(): Promise<MachineStatus[]> {
        const machines = this.listMachines()
        const statusPromises = machines.map(machine =>
            this.getMachineStatus(machine.machine_name)
        )

        const statuses = await Promise.all(statusPromises)
        return statuses.filter(status => status !== null) as MachineStatus[]
    }

    /**
     * 根据 Droplet ID 查找机器
     */
    findByDropletId(dropletId: number): MachineConfig | undefined {
        return Array.from(this.machines.values()).find(
            machine => machine.droplet_id === dropletId
        )
    }

    /**
     * 获取机器数量
     */
    getCount(): number {
        return this.machines.size
    }
}

