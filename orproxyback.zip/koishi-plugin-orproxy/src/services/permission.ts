import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { UserPermission } from '../models/database'

/**
 * 权限管理服务
 */
export class PermissionService {
    private ctx: Context
    private logger: Logger

    constructor(ctx: Context) {
        this.ctx = ctx
        this.logger = new Logger(ctx, 'orproxy:permission')
    }

    /**
     * 授予用户权限
     * @param userId 用户ID
     * @param platform 平台
     * @param level 权限等级
     * @param days 有效天数
     * @param keyCode 使用的卡密（可选）
     */
    async grantPermission(
        userId: string,
        platform: string,
        level: number,
        days: number,
        keyCode?: string
    ): Promise<UserPermission> {
        const now = new Date()
        const expiresAt = new Date(now.getTime() + days * 86400000)

        // 检查是否已有权限记录
        const existing = await this.ctx.database.get('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        })

        let permission: UserPermission

        if (existing.length === 0) {
            // 创建新权限记录
            const newPermission = await this.ctx.database.create('orproxy_user_permissions', {
                user_id: userId,
                platform: platform,
                permission_level: level,
                granted_at: now,
                expires_at: expiresAt,
                last_key_used: keyCode
            })
            permission = newPermission
        } else {
            // 更新现有权限记录
            await this.ctx.database.set('orproxy_user_permissions', {
                user_id: userId,
                platform: platform
            }, {
                permission_level: level,
                granted_at: now,
                expires_at: expiresAt,
                last_key_used: keyCode
            })

            const [updated] = await this.ctx.database.get('orproxy_user_permissions', {
                user_id: userId,
                platform: platform
            })
            permission = updated
        }

        // 同步更新 Koishi 用户权限
        await this.syncUserAuthority(userId, platform, level)

        this.logger.info(`权限已授予: ${userId} (${platform}) -> Level ${level}, 到期: ${expiresAt.toLocaleString()}`)

        return permission
    }

    /**
     * 获取用户权限信息
     * @param userId 用户ID
     * @param platform 平台
     */
    async getUserPermission(userId: string, platform: string): Promise<UserPermission | null> {
        const permissions = await this.ctx.database.get('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        })

        return permissions.length > 0 ? permissions[0] : null
    }

    /**
     * 检查用户权限是否过期
     * @param userId 用户ID
     * @param platform 平台
     * @returns true 如果已过期并已降级
     */
    async checkExpired(userId: string, platform: string): Promise<boolean> {
        const permission = await this.getUserPermission(userId, platform)

        if (!permission) {
            return false
        }

        const now = new Date()

        if (permission.expires_at < now) {
            this.logger.info(`权限已过期: ${userId} (${platform})`)

            // 降级为 Level 0
            await this.syncUserAuthority(userId, platform, 0)

            // 可选：删除过期记录或标记为过期
            // 这里选择保留记录以便查看历史

            return true
        }

        return false
    }

    /**
     * 清理所有过期权限（定时任务）
     */
    async cleanExpiredPermissions(): Promise<number> {
        const allPermissions = await this.ctx.database.get('orproxy_user_permissions', {})
        const now = new Date()
        let cleanedCount = 0

        for (const permission of allPermissions) {
            if (permission.expires_at < now) {
                await this.syncUserAuthority(
                    permission.user_id,
                    permission.platform,
                    0
                )
                cleanedCount++
            }
        }

        if (cleanedCount > 0) {
            this.logger.info(`已清理 ${cleanedCount} 个过期权限`)
        }

        return cleanedCount
    }

    /**
     * 延长权限时长
     * @param userId 用户ID
     * @param platform 平台
     * @param days 延长天数
     */
    async extendPermission(userId: string, platform: string, days: number): Promise<UserPermission> {
        const permission = await this.getUserPermission(userId, platform)

        if (!permission) {
            throw new Error('用户没有权限记录')
        }

        const now = new Date()
        let newExpiresAt: Date

        // 如果已过期，从当前时间开始计算
        if (permission.expires_at < now) {
            newExpiresAt = new Date(now.getTime() + days * 86400000)
        } else {
            // 未过期，在现有基础上叠加
            newExpiresAt = new Date(permission.expires_at.getTime() + days * 86400000)
        }

        await this.ctx.database.set('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        }, {
            expires_at: newExpiresAt
        })

        // 同步 Koishi 权限
        await this.syncUserAuthority(userId, platform, permission.permission_level)

        this.logger.info(`权限已延长: ${userId} (${platform}) +${days}天, 新到期时间: ${newExpiresAt.toLocaleString()}`)

        const [updated] = await this.ctx.database.get('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        })

        return updated
    }

    /**
     * 升级权限等级
     * @param userId 用户ID
     * @param platform 平台
     * @param newLevel 新权限等级
     * @param days 有效天数
     */
    async upgradePermission(
        userId: string,
        platform: string,
        newLevel: number,
        days: number
    ): Promise<UserPermission> {
        const permission = await this.getUserPermission(userId, platform)

        if (permission && permission.permission_level >= newLevel) {
            throw new Error('无法降级或平级，请使用延长功能')
        }

        const now = new Date()
        const expiresAt = new Date(now.getTime() + days * 86400000)

        if (!permission) {
            // 如果没有权限记录，直接授予
            return await this.grantPermission(userId, platform, newLevel, days)
        }

        // 升级权限
        await this.ctx.database.set('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        }, {
            permission_level: newLevel,
            granted_at: now,
            expires_at: expiresAt
        })

        // 同步 Koishi 权限
        await this.syncUserAuthority(userId, platform, newLevel)

        this.logger.info(`权限已升级: ${userId} (${platform}) -> Level ${newLevel}, 到期: ${expiresAt.toLocaleString()}`)

        const [updated] = await this.ctx.database.get('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        })

        return updated
    }

    /**
     * 同步 Koishi 用户权限等级
     * @param userId 用户ID
     * @param platform 平台
     * @param level 权限等级
     */
    private async syncUserAuthority(userId: string, platform: string, level: number): Promise<void> {
        // 注意：这里只记录日志，不实际修改 Koishi 用户表
        // 权限检查将通过 orproxy_user_permissions 表进行
        // 在命令执行时通过中间件检查权限是否过期
        this.logger.info(`权限已更新: ${userId} (${platform}) -> Level ${level}`)
    }
}

