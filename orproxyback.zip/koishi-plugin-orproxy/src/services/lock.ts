/**
 * 机器锁管理服务
 * 防止多个用户同时操作同一台机器
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'

export interface LockInfo {
    userId: string
    platform: string
    timestamp: number
}

export class MachineLockService {
    private locks: Map<string, LockInfo> = new Map()
    private logger: Logger
    private lockTimeout: number = 300000  // 5分钟超时

    constructor(private ctx: Context) {
        this.logger = new Logger(ctx, 'orproxy:lock')

        // 定期检查超时锁
        setInterval(() => this.cleanTimeoutLocks(), 60000)  // 每分钟检查一次
    }

    /**
     * 尝试获取机器锁
     */
    async acquire(
        machineName: string,
        userId: string,
        platform: string
    ): Promise<boolean> {
        // 检查内存锁
        const memoryLock = this.locks.get(machineName)
        if (memoryLock) {
            // 检查是否超时
            if (Date.now() - memoryLock.timestamp < this.lockTimeout) {
                this.logger.warn(`机器已被锁定: ${machineName} by ${memoryLock.userId}`)
                return false
            } else {
                this.logger.info(`清理超时锁: ${machineName}`)
                this.locks.delete(machineName)
                await this.ctx.database.remove('orproxy_machine_locks', { machine_name: machineName })
            }
        }

        // 检查数据库锁
        try {
            const dbLocks = await this.ctx.database.get('orproxy_machine_locks', {
                machine_name: machineName
            })

            if (dbLocks.length > 0) {
                const dbLock = dbLocks[0]
                // 检查是否超时
                const lockAge = Date.now() - new Date(dbLock.locked_at).getTime()
                if (lockAge < this.lockTimeout) {
                    this.logger.warn(`机器已被锁定(DB): ${machineName} by ${dbLock.user_id}`)
                    return false
                } else {
                    // 清理超时锁
                    this.logger.info(`清理超时锁(DB): ${machineName}`)
                    await this.ctx.database.remove('orproxy_machine_locks', { machine_name: machineName })
                }
            }

            // 创建锁
            const lockInfo: LockInfo = {
                userId,
                platform,
                timestamp: Date.now()
            }

            this.locks.set(machineName, lockInfo)

            await this.ctx.database.create('orproxy_machine_locks', {
                machine_name: machineName,
                user_id: userId,
                adapter_type: platform,
                locked_at: new Date()
            })

            this.logger.info(`机器锁已获取: ${machineName} by ${userId} (${platform})`)
            return true
        } catch (error) {
            this.logger.error(`获取机器锁失败: ${machineName}`, error)
            return false
        }
    }

    /**
     * 释放机器锁
     */
    async release(machineName: string): Promise<void> {
        try {
            // 删除内存锁
            this.locks.delete(machineName)

            // 删除数据库锁
            await this.ctx.database.remove('orproxy_machine_locks', {
                machine_name: machineName
            })

            this.logger.info(`机器锁已释放: ${machineName}`)
        } catch (error) {
            this.logger.error(`释放机器锁失败: ${machineName}`, error)
        }
    }

    /**
     * 检查机器是否被锁定
     */
    async isLocked(machineName: string): Promise<boolean> {
        // 检查内存锁
        const memoryLock = this.locks.get(machineName)
        if (memoryLock && Date.now() - memoryLock.timestamp < this.lockTimeout) {
            return true
        }

        // 检查数据库锁
        try {
            const dbLocks = await this.ctx.database.get('orproxy_machine_locks', {
                machine_name: machineName
            })

            if (dbLocks.length > 0) {
                const lockAge = Date.now() - new Date(dbLocks[0].locked_at).getTime()
                return lockAge < this.lockTimeout
            }

            return false
        } catch (error) {
            this.logger.error(`检查机器锁失败: ${machineName}`, error)
            return false
        }
    }

    /**
     * 获取锁信息
     */
    async getLockInfo(machineName: string): Promise<LockInfo | null> {
        // 优先从内存获取
        const memoryLock = this.locks.get(machineName)
        if (memoryLock && Date.now() - memoryLock.timestamp < this.lockTimeout) {
            return memoryLock
        }

        // 从数据库获取
        try {
            const dbLocks = await this.ctx.database.get('orproxy_machine_locks', {
                machine_name: machineName
            })

            if (dbLocks.length > 0) {
                const dbLock = dbLocks[0]
                const lockAge = Date.now() - new Date(dbLock.locked_at).getTime()

                if (lockAge < this.lockTimeout) {
                    return {
                        userId: dbLock.user_id,
                        platform: dbLock.adapter_type,
                        timestamp: new Date(dbLock.locked_at).getTime()
                    }
                }
            }

            return null
        } catch (error) {
            this.logger.error(`获取锁信息失败: ${machineName}`, error)
            return null
        }
    }

    /**
     * 清理超时锁
     */
    private async cleanTimeoutLocks(): Promise<void> {
        const now = Date.now()

        // 清理内存锁
        for (const [machineName, lockInfo] of this.locks.entries()) {
            if (now - lockInfo.timestamp >= this.lockTimeout) {
                this.logger.info(`清理超时内存锁: ${machineName}`)
                this.locks.delete(machineName)
            }
        }

        // 清理数据库锁
        try {
            const allLocks = await this.ctx.database.get('orproxy_machine_locks', {})

            for (const lock of allLocks) {
                const lockAge = now - new Date(lock.locked_at).getTime()
                if (lockAge >= this.lockTimeout) {
                    this.logger.info(`清理超时数据库锁: ${lock.machine_name}`)
                    await this.ctx.database.remove('orproxy_machine_locks', {
                        machine_name: lock.machine_name
                    })
                }
            }
        } catch (error) {
            this.logger.error('清理超时锁失败:', error)
        }
    }

    /**
     * 强制释放所有锁（谨慎使用）
     */
    async releaseAll(): Promise<void> {
        this.logger.warn('强制释放所有机器锁')

        this.locks.clear()

        try {
            const allLocks = await this.ctx.database.get('orproxy_machine_locks', {})
            for (const lock of allLocks) {
                await this.ctx.database.remove('orproxy_machine_locks', {
                    machine_name: lock.machine_name
                })
            }
        } catch (error) {
            this.logger.error('强制释放锁失败:', error)
        }
    }

    /**
     * 获取所有锁信息
     */
    async getAllLocks(): Promise<Map<string, LockInfo>> {
        const result = new Map<string, LockInfo>()

        // 从数据库获取
        try {
            const dbLocks = await this.ctx.database.get('orproxy_machine_locks', {})

            for (const lock of dbLocks) {
                result.set(lock.machine_name, {
                    userId: lock.user_id,
                    platform: lock.adapter_type,
                    timestamp: new Date(lock.locked_at).getTime()
                })
            }
        } catch (error) {
            this.logger.error('获取所有锁失败:', error)
        }

        return result
    }
}

