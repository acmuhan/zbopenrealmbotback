/**
 * 黑名单管理服务
 * 管理被拉黑的 IP 地址，支持自动过期清理
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { BlacklistEntry } from '../models/database'
import * as fs from 'fs'
import * as path from 'path'

export class BlacklistService {
    private blacklist: BlacklistEntry[] = []
    private logger: Logger
    private filePath: string
    private cleanTimer?: NodeJS.Timeout

    constructor(
        private ctx: Context,
        configPath: string,
        private autoClean: boolean = true,
        private cleanInterval: number = 3600000  // 1小时
    ) {
        this.logger = new Logger(ctx, 'orproxy:blacklist')
        this.filePath = path.resolve(process.cwd(), configPath)

        this.load()

        if (this.autoClean) {
            this.startAutoClean()
        }
    }

    /**
     * 从文件加载黑名单
     */
    load(): void {
        try {
            if (fs.existsSync(this.filePath)) {
                const data = fs.readFileSync(this.filePath, 'utf-8')
                this.blacklist = JSON.parse(data)
                this.logger.info(`黑名单加载成功，共 ${this.blacklist.length} 条记录`)
            } else {
                this.blacklist = []
                this.save()  // 创建空文件
                this.logger.info('黑名单文件不存在，已创建空文件')
            }
        } catch (error) {
            this.logger.error('加载黑名单失败:', error)
            this.blacklist = []
        }
    }

    /**
     * 保存黑名单到文件
     */
    save(): void {
        try {
            // 确保目录存在
            const dir = path.dirname(this.filePath)
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true })
            }

            fs.writeFileSync(
                this.filePath,
                JSON.stringify(this.blacklist, null, 2),
                'utf-8'
            )
            this.logger.debug('黑名单已保存')
        } catch (error) {
            this.logger.error('保存黑名单失败:', error)
        }
    }

    /**
     * 添加 IP 到黑名单
     */
    async add(
        ip: string,
        machineName: string,
        userId: string,
        adapterType: string,
        reason: string = 'stop',
        expireDays: number = 30
    ): Promise<void> {
        this.logger.info(`添加 IP 到黑名单: ${ip} (${machineName})`)

        // 检查是否已存在
        const existing = this.blacklist.findIndex(entry => entry.ip_address === ip)

        const now = new Date()
        const expireTime = new Date(now.getTime() + expireDays * 24 * 60 * 60 * 1000)

        const entry: BlacklistEntry = {
            ip_address: ip,
            machine_name: machineName,
            user_id: userId,
            adapter_type: adapterType,
            reason,
            blacklist_time: now.toISOString(),
            expire_time: expireTime.toISOString()
        }

        if (existing >= 0) {
            // 更新已存在的记录
            this.blacklist[existing] = entry
            this.logger.info(`更新已存在的黑名单记录: ${ip}`)
        } else {
            // 添加新记录
            this.blacklist.push(entry)
            this.logger.info(`新增黑名单记录: ${ip}`)
        }

        this.save()
    }

    /**
     * 从黑名单移除 IP
     */
    async remove(ip: string): Promise<boolean> {
        this.logger.info(`从黑名单移除 IP: ${ip}`)

        const before = this.blacklist.length
        this.blacklist = this.blacklist.filter(entry => entry.ip_address !== ip)

        if (this.blacklist.length < before) {
            this.save()
            this.logger.info(`IP 已从黑名单移除: ${ip}`)
            return true
        }

        this.logger.warn(`IP 不在黑名单中: ${ip}`)
        return false
    }

    /**
     * 检查 IP 是否在黑名单中（且未过期）
     */
    isBlacklisted(ip: string): boolean {
        const now = new Date()
        const entry = this.blacklist.find(
            entry => entry.ip_address === ip &&
                new Date(entry.expire_time) > now
        )
        return !!entry
    }

    /**
     * 获取黑名单条目详情
     */
    getEntry(ip: string): BlacklistEntry | undefined {
        return this.blacklist.find(entry => entry.ip_address === ip)
    }

    /**
     * 获取所有黑名单（包括过期的）
     */
    getAll(): BlacklistEntry[] {
        return [...this.blacklist]
    }

    /**
     * 获取有效的黑名单（未过期）
     */
    getActive(): BlacklistEntry[] {
        const now = new Date()
        return this.blacklist.filter(entry => new Date(entry.expire_time) > now)
    }

    /**
     * 获取过期的黑名单
     */
    getExpired(): BlacklistEntry[] {
        const now = new Date()
        return this.blacklist.filter(entry => new Date(entry.expire_time) <= now)
    }

    /**
     * 清理过期的黑名单记录
     */
    cleanExpired(): number {
        const now = new Date()
        const before = this.blacklist.length

        this.blacklist = this.blacklist.filter(entry => {
            return new Date(entry.expire_time) > now
        })

        const removed = before - this.blacklist.length

        if (removed > 0) {
            this.save()
            this.logger.info(`清理了 ${removed} 条过期黑名单记录`)
        }

        return removed
    }

    /**
     * 启动自动清理定时器
     */
    private startAutoClean(): void {
        this.logger.info(`启动自动清理，间隔: ${this.cleanInterval / 1000}秒`)

        // 立即执行一次清理
        this.cleanExpired()

        // 设置定时器
        this.cleanTimer = setInterval(() => {
            this.cleanExpired()
        }, this.cleanInterval)
    }

    /**
     * 停止自动清理
     */
    stopAutoClean(): void {
        if (this.cleanTimer) {
            clearInterval(this.cleanTimer)
            this.cleanTimer = undefined
            this.logger.info('自动清理已停止')
        }
    }

    /**
     * 获取统计信息
     */
    getStats(): {
        total: number
        active: number
        expired: number
    } {
        const active = this.getActive()
        const expired = this.getExpired()

        return {
            total: this.blacklist.length,
            active: active.length,
            expired: expired.length
        }
    }

    /**
     * 销毁服务
     */
    dispose(): void {
        this.stopAutoClean()
        this.save()
    }
}

