/**
 * 自定义服务器配置服务
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { CustomServerConfig } from '../models/database'

export class CustomServerService {
    private logger: Logger

    constructor(private ctx: Context) {
        this.logger = new Logger(ctx, 'orproxy:customserver')
    }

    /**
     * 设置自定义服务器配置
     */
    async setConfig(
        userId: string,
        platform: string,
        machineName: string,
        serverAddress: string,
        serverPort: number = 25565,
        description: string = ''
    ): Promise<void> {
        try {
            const now = new Date()

            // 检查是否已存在配置
            const existing = await this.ctx.database.get('orproxy_custom_servers', {
                user_id: userId,
                platform: platform,
                machine_name: machineName
            })

            if (existing.length > 0) {
                // 更新现有配置
                await this.ctx.database.set('orproxy_custom_servers',
                    { id: existing[0].id },
                    {
                        server_address: serverAddress,
                        server_port: serverPort,
                        description: description,
                        updated_at: now
                    }
                )
                this.logger.info(`更新自定义服务器配置: ${userId}/${machineName}`)
            } else {
                // 创建新配置
                await this.ctx.database.create('orproxy_custom_servers', {
                    user_id: userId,
                    platform: platform,
                    machine_name: machineName,
                    server_address: serverAddress,
                    server_port: serverPort,
                    description: description,
                    created_at: now,
                    updated_at: now
                })
                this.logger.info(`创建自定义服务器配置: ${userId}/${machineName}`)
            }
        } catch (error) {
            this.logger.error('设置自定义服务器配置失败:', error)
            throw error
        }
    }

    /**
     * 获取自定义服务器配置
     */
    async getConfig(
        userId: string,
        platform: string,
        machineName: string
    ): Promise<CustomServerConfig | null> {
        try {
            const configs = await this.ctx.database.get('orproxy_custom_servers', {
                user_id: userId,
                platform: platform,
                machine_name: machineName
            })

            return configs.length > 0 ? configs[0] : null
        } catch (error) {
            this.logger.error('获取自定义服务器配置失败:', error)
            return null
        }
    }

    /**
     * 列出用户所有自定义服务器配置
     */
    async listConfigs(userId: string, platform: string): Promise<CustomServerConfig[]> {
        try {
            return await this.ctx.database.get('orproxy_custom_servers', {
                user_id: userId,
                platform: platform
            })
        } catch (error) {
            this.logger.error('列出自定义服务器配置失败:', error)
            return []
        }
    }

    /**
     * 删除自定义服务器配置
     */
    async deleteConfig(
        userId: string,
        platform: string,
        machineName: string
    ): Promise<boolean> {
        try {
            await this.ctx.database.remove('orproxy_custom_servers', {
                user_id: userId,
                platform: platform,
                machine_name: machineName
            })
            this.logger.info(`删除自定义服务器配置: ${userId}/${machineName}`)
            return true
        } catch (error) {
            this.logger.error('删除自定义服务器配置失败:', error)
            return false
        }
    }
}

