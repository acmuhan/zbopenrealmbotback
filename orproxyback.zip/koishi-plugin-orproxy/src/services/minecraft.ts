/**
 * Minecraft 服务器查询服务
 * 通过 Server List Ping 协议查询服务器状态
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import * as net from 'net'

export interface MinecraftServerStatus {
    online: boolean
    players?: {
        online: number
        max: number
    }
    version?: {
        name: string
        protocol: number
    }
    description?: string
    favicon?: string
}

export class MinecraftService {
    private logger: Logger

    constructor(private ctx: Context) {
        this.logger = new Logger(ctx, 'orproxy:minecraft')
    }

    /**
     * 查询 Minecraft 服务器状态
     * @param host 服务器地址
     * @param port 服务器端口（默认25565）
     * @param timeout 超时时间（毫秒）
     */
    async queryServer(
        host: string,
        port: number = 25565,
        timeout: number = 10000
    ): Promise<MinecraftServerStatus> {
        return new Promise((resolve) => {
            const socket = new net.Socket()
            let timeoutId: NodeJS.Timeout

            const cleanup = () => {
                if (timeoutId) clearTimeout(timeoutId)
                socket.destroy()
            }

            // 设置超时
            timeoutId = setTimeout(() => {
                cleanup()
                this.logger.warn(`查询超时: ${host}:${port}`)
                resolve({ online: false })
            }, timeout)

            socket.on('error', (error) => {
                cleanup()
                this.logger.error(`连接失败: ${host}:${port}`, error)
                resolve({ online: false })
            })

            socket.on('connect', () => {
                try {
                    // 发送握手包
                    const handshake = this.createHandshakePacket(host, port)
                    socket.write(handshake)

                    // 发送状态请求包
                    const request = this.createRequestPacket()
                    socket.write(request)
                } catch (error) {
                    cleanup()
                    this.logger.error(`发送数据包失败: ${host}:${port}`, error)
                    resolve({ online: false })
                }
            })

            let buffer = Buffer.alloc(0)

            socket.on('data', (data) => {
                try {
                    buffer = Buffer.concat([buffer, data])

                    // 尝试解析数据包
                    if (buffer.length >= 5) {
                        const length = this.readVarInt(buffer)
                        
                        if (buffer.length >= length.value + length.size) {
                            const jsonStart = length.size + 1 // 跳过 packet ID
                            const jsonLength = this.readVarInt(buffer.slice(jsonStart))
                            const jsonData = buffer.slice(jsonStart + jsonLength.size, jsonStart + jsonLength.size + jsonLength.value)
                            
                            const response = JSON.parse(jsonData.toString('utf8'))
                            
                            cleanup()
                            resolve({
                                online: true,
                                players: response.players,
                                version: response.version,
                                description: typeof response.description === 'string' 
                                    ? response.description 
                                    : response.description?.text || ''
                            })
                        }
                    }
                } catch (error) {
                    cleanup()
                    this.logger.error(`解析响应失败: ${host}:${port}`, error)
                    resolve({ online: false })
                }
            })

            socket.connect(port, host)
        })
    }

    /**
     * 安全查询（带重试）
     */
    async queryServerSafe(
        host: string,
        port: number = 25565,
        maxRetries: number = 3
    ): Promise<MinecraftServerStatus> {
        for (let i = 0; i < maxRetries; i++) {
            try {
                const result = await this.queryServer(host, port)
                if (result.online) {
                    return result
                }

                if (i < maxRetries - 1) {
                    // 等待 1-2 秒后重试
                    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000))
                }
            } catch (error) {
                this.logger.error(`查询失败 (尝试 ${i + 1}/${maxRetries}):`, error)
                if (i < maxRetries - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000))
                }
            }
        }

        return { online: false }
    }

    /**
     * 创建握手数据包
     */
    private createHandshakePacket(host: string, port: number): Buffer {
        const data: number[] = []

        // Packet ID (0x00 for handshake)
        data.push(0x00)

        // Protocol version (-1 for status request)
        this.writeVarInt(data, -1)

        // Server address
        const hostBuffer = Buffer.from(host, 'utf8')
        this.writeVarInt(data, hostBuffer.length)
        data.push(...hostBuffer)

        // Server port
        data.push((port >> 8) & 0xFF)
        data.push(port & 0xFF)

        // Next state (1 for status)
        this.writeVarInt(data, 1)

        // Prepend packet length
        const length: number[] = []
        this.writeVarInt(length, data.length)

        return Buffer.from([...length, ...data])
    }

    /**
     * 创建请求数据包
     */
    private createRequestPacket(): Buffer {
        return Buffer.from([0x01, 0x00])
    }

    /**
     * 写入 VarInt
     */
    private writeVarInt(buffer: number[], value: number): void {
        while (true) {
            if ((value & ~0x7F) === 0) {
                buffer.push(value)
                return
            }
            buffer.push((value & 0x7F) | 0x80)
            value >>>= 7
        }
    }

    /**
     * 读取 VarInt
     */
    private readVarInt(buffer: Buffer): { value: number; size: number } {
        let value = 0
        let size = 0
        let byte: number

        do {
            if (size >= buffer.length) {
                throw new Error('VarInt is too big')
            }

            byte = buffer[size]
            value |= (byte & 0x7F) << (7 * size)
            size++

            if (size > 5) {
                throw new Error('VarInt is too big')
            }
        } while ((byte & 0x80) !== 0)

        return { value, size }
    }
}

