/**
 * ZBProxy 服务
 * 通过 HTTP API 控制 ZBProxy 进程
 */

import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import axios, { AxiosInstance } from 'axios'

export class ZBProxyService {
    private logger: Logger
    private defaultTimeout: number

    constructor(private ctx: Context, timeout: number = 30000) {
        this.logger = new Logger(ctx, 'orproxy:zbproxy')
        this.defaultTimeout = timeout
    }

    /**
     * 创建 axios 客户端
     */
    private createClient(ip: string, port: number): AxiosInstance {
        return axios.create({
            baseURL: `http://${ip}:${port}`,
            timeout: this.defaultTimeout,
            headers: {
                'Content-Type': 'application/json'
            }
        })
    }

    /**
     * 启动 ZBProxy
     */
    async start(ip: string, port: number): Promise<void> {
        this.logger.info(`启动 ZBProxy: ${ip}:${port}`)

        try {
            const client = this.createClient(ip, port)
            const response = await client.post('/start')

            if (response.data.success) {
                this.logger.info(`ZBProxy 启动成功: ${ip}`)
            } else {
                throw new Error(response.data.message || '启动失败')
            }
        } catch (error: any) {
            this.logger.error(`启动 ZBProxy 失败: ${ip}`, error)
            throw new Error(`启动 ZBProxy 失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 停止 ZBProxy
     */
    async stop(ip: string, port: number): Promise<void> {
        this.logger.info(`停止 ZBProxy: ${ip}:${port}`)

        try {
            const client = this.createClient(ip, port)
            const response = await client.post('/stop')

            if (response.data.success) {
                this.logger.info(`ZBProxy 停止成功: ${ip}`)
            } else {
                throw new Error(response.data.message || '停止失败')
            }
        } catch (error: any) {
            this.logger.error(`停止 ZBProxy 失败: ${ip}`, error)
            throw new Error(`停止 ZBProxy 失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 重启 ZBProxy
     */
    async restart(ip: string, port: number): Promise<void> {
        this.logger.info(`重启 ZBProxy: ${ip}:${port}`)

        try {
            const client = this.createClient(ip, port)
            const response = await client.post('/restart')

            if (response.data.success) {
                this.logger.info(`ZBProxy 重启成功: ${ip}`)
            } else {
                throw new Error(response.data.message || '重启失败')
            }
        } catch (error: any) {
            this.logger.error(`重启 ZBProxy 失败: ${ip}`, error)
            throw new Error(`重启 ZBProxy 失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 获取 ZBProxy 状态
     */
    async getStatus(ip: string, port: number): Promise<{ status: 'running' | 'stopped' | 'unknown' }> {
        try {
            const client = this.createClient(ip, port)
            const response = await client.get('/status')

            if (response.data.running) {
                return { status: 'running' }
            } else {
                return { status: 'stopped' }
            }
        } catch (error) {
            return { status: 'unknown' }
        }
    }

    /**
     * 获取 ZBProxy 配置
     */
    async getConfig(ip: string, port: number): Promise<any> {
        try {
            const client = this.createClient(ip, port)
            const response = await client.get('/config')
            return response.data
        } catch (error: any) {
            this.logger.error(`获取配置失败: ${ip}`, error)
            throw new Error(`获取配置失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 更新 ZBProxy 配置
     */
    async updateConfig(ip: string, port: number, config: any): Promise<void> {
        this.logger.info(`更新配置: ${ip}:${port}`)

        try {
            const client = this.createClient(ip, port)
            const response = await client.post('/config', config)

            if (response.data.success) {
                this.logger.info(`配置更新成功: ${ip}`)
            } else {
                throw new Error(response.data.message || '更新失败')
            }
        } catch (error: any) {
            this.logger.error(`更新配置失败: ${ip}`, error)
            throw new Error(`更新配置失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 更新自定义 Minecraft 服务器配置
     * 通过添加新的出站配置来更新目标服务器
     */
    async updateMinecraftServer(ip: string, port: number, serverAddress: string, serverPort: number, outboundName: string = 'CustomServer'): Promise<void> {
        this.logger.info(`更新 Minecraft 服务器配置: ${ip}:${port} -> ${serverAddress}:${serverPort}`)

        try {
            const client = this.createClient(ip, port)

            // 先尝试删除旧的出站配置（如果存在）
            try {
                await client.delete(`/config/outbound/${outboundName}`)
                this.logger.debug(`已删除旧的出站配置: ${outboundName}`)
            } catch (e) {
                // 如果出站不存在，忽略错误
                this.logger.debug(`旧出站配置不存在: ${outboundName}`)
            }

            // 添加新的出站配置
            const response = await client.post('/config/outbound', {
                Name: outboundName,
                TargetAddress: serverAddress,
                TargetPort: serverPort,
                Minecraft: {
                    EnableHostnameRewrite: true,
                    OnlineCount: {
                        Max: 20,
                        Online: -1,
                        EnableMaxLimit: false
                    },
                    HostnameAccess: { Mode: '' },
                    NameAccess: { Mode: '' },
                    PingMode: '',
                    MotdFavicon: '{DEFAULT_MOTD}',
                    MotdDescription: '§d{NAME}§e, provided by §a§o{INFO}§r\n§c§lProxy for §6§n{HOST}:{PORT}§r'
                },
                ProxyOptions: {
                    Type: ''
                }
            })

            if (response.data.success) {
                this.logger.info(`✓ 出站配置已更新: ${serverAddress}:${serverPort}`)
            } else {
                throw new Error(response.data.message || '更新失败')
            }
        } catch (error: any) {
            this.logger.error(`更新 Minecraft 服务器配置失败: ${ip}`, error)
            throw new Error(`更新配置失败: ${error?.message || 'Unknown error'}`)
        }
    }

    /**
     * 检查 ZBProxy API 是否可达（快速检查）
     */
    async isReachable(ip: string, port: number): Promise<boolean> {
        try {
            const client = this.createClient(ip, port)
            // 快速超时（3秒）
            const response = await client.get('/', { timeout: 3000 })
            this.logger.debug(`✓ ZBProxy 可达: ${ip}:${port}`)
            return true
        } catch (error: any) {
            this.logger.debug(`✗ ZBProxy 不可达: ${ip}:${port}`)
            return false
        }
    }

    /**
     * 配置 Linux IP 路由（dolinuxip）
     * @param ip 服务器IP
     * @param port API端口
     * @param reservedIP Reserved IP地址
     * @param maxRetries 最大重试次数
     */
    async configureLinuxIP(
        ip: string,
        port: number,
        reservedIP: string,
        maxRetries: number = 3
    ): Promise<void> {
        this.logger.info(`配置 Linux IP 路由: ${ip}:${port} -> ${reservedIP}`)

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                // 快速检查 ZBProxy 是否可达
                this.logger.info(`[${attempt}/${maxRetries}] 检查 ZBProxy 可达性...`)
                const reachable = await this.isReachable(ip, port)

                if (!reachable) {
                    throw new Error(`ZBProxy 服务不可达`)
                }

                this.logger.info(`[${attempt}/${maxRetries}] 发送 dolinuxip 请求...`)
                const client = this.createClient(ip, port)

                // 使用较短的超时时间（20秒）
                const response = await client.post('/dolinuxip', {
                    ip: reservedIP
                }, {
                    timeout: 20000
                })

                if (response.data.success) {
                    this.logger.info(`✓ Linux IP 配置成功: ${reservedIP}`)
                    return
                } else {
                    throw new Error(response.data.message || '配置失败')
                }
            } catch (error: any) {
                const errorMsg = error?.message || 'Unknown error'
                this.logger.warn(`✗ 配置失败 (${attempt}/${maxRetries}): ${errorMsg}`)

                if (attempt < maxRetries) {
                    // 缩短等待时间到5秒
                    const waitTime = 5000
                    this.logger.info(`等待 ${waitTime / 1000}s 后重试...`)
                    await new Promise(resolve => setTimeout(resolve, waitTime))
                } else {
                    throw new Error(`配置失败（重试 ${maxRetries} 次）: ${errorMsg}`)
                }
            }
        }
    }

    /**
     * 智能停止 ZBProxy（带重试）
     * @param ip 服务器IP
     * @param port API端口
     * @param maxRetries 最大重试次数
     */
    async stopWithRetry(
        ip: string,
        port: number,
        maxRetries: number = 5
    ): Promise<void> {
        this.logger.info(`智能停止 ZBProxy: ${ip}:${port}`)

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                await this.stop(ip, port)
                this.logger.info(`✓ ZBProxy 停止成功: ${ip}`)
                return
            } catch (error: any) {
                const errorMsg = error?.message || ''
                const isConnectionRefused = errorMsg.includes('ECONNREFUSED') || errorMsg.includes('connect ECONNREFUSED')

                if (isConnectionRefused && attempt === 1) {
                    // 第一次就连接拒绝，可能已经停止了
                    this.logger.info(`ZBProxy 可能已停止（连接拒绝）`)
                    return
                }

                this.logger.warn(`✗ 停止失败 (${attempt}/${maxRetries}): ${errorMsg}`)

                if (attempt < maxRetries) {
                    // 短暂等待后重试
                    const waitTime = 3000
                    this.logger.debug(`等待 ${waitTime}ms 后重试...`)
                    await new Promise(resolve => setTimeout(resolve, waitTime))
                } else {
                    throw new Error(`ZBProxy 停止失败（已重试 ${maxRetries} 次）: ${errorMsg}`)
                }
            }
        }
    }

    /**
     * 智能重启 ZBProxy（带自适应重试）
     * @param ip 服务器IP
     * @param port API端口
     * @param maxRetries 最大重试次数
     */
    async restartWithRetry(
        ip: string,
        port: number,
        maxRetries: number = 8
    ): Promise<void> {
        this.logger.info(`智能重启 ZBProxy: ${ip}:${port}`)

        let consecutiveRefusals = 0

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                await this.restart(ip, port)
                this.logger.info(`✓ ZBProxy 重启成功: ${ip}`)
                return
            } catch (error: any) {
                const errorMsg = error?.message || ''
                const isConnectionRefused = errorMsg.includes('ECONNREFUSED') || errorMsg.includes('connect ECONNREFUSED')

                if (isConnectionRefused) {
                    consecutiveRefusals++
                    this.logger.warn(`连接拒绝 (${consecutiveRefusals} 次连续, ${attempt}/${maxRetries}):`, errorMsg)
                } else {
                    consecutiveRefusals = 0
                    this.logger.warn(`✗ 重启失败 (${attempt}/${maxRetries}):`, errorMsg)
                }

                if (attempt < maxRetries) {
                    let waitTime: number

                    if (isConnectionRefused) {
                        // 连接拒绝：延长等待时间
                        waitTime = consecutiveRefusals >= 2 ? 20000 : 10000
                    } else {
                        // 其他错误：短暂等待
                        waitTime = 3000
                    }

                    this.logger.debug(`等待 ${waitTime}ms 后重试...`)
                    await new Promise(resolve => setTimeout(resolve, waitTime))
                } else {
                    throw new Error(`ZBProxy 重启失败（已重试 ${maxRetries} 次）: ${errorMsg}`)
                }
            }
        }
    }
}
