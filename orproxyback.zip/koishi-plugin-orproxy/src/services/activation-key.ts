import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { ActivationKey } from '../models/database'
import crypto from 'crypto'

/**
 * 卡密管理服务
 */
export class ActivationKeyService {
    private ctx: Context
    private logger: Logger

    constructor(ctx: Context) {
        this.ctx = ctx
        this.logger = new Logger(ctx, 'orproxy:activation-key')
    }

    /**
     * 生成唯一的卡密代码
     * 格式: XXXX-XXXX-XXXX (12位字符 + 2个连字符)
     * 排除易混淆字符: 0O, 1Il, Z2, 5S, 8B
     */
    private generateKeyCode(): string {
        // 可用字符集（排除易混淆字符）
        const chars = 'ACDEFGHJKLMNPQRTUVWXY3469'
        let keyCode = ''

        // 生成3组，每组4个字符
        for (let group = 0; group < 3; group++) {
            if (group > 0) keyCode += '-'
            for (let i = 0; i < 4; i++) {
                // 使用 crypto 生成安全的随机数
                const randomIndex = crypto.randomInt(0, chars.length)
                keyCode += chars[randomIndex]
            }
        }

        return keyCode
    }

    /**
     * 生成唯一卡密（检查重复）
     * @param maxRetries 最大重试次数
     */
    async generateKey(maxRetries: number = 10): Promise<string> {
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            const keyCode = this.generateKeyCode()

            // 检查是否已存在
            const existing = await this.ctx.database.get('orproxy_activation_keys', {
                key_code: keyCode
            })

            if (existing.length === 0) {
                return keyCode
            }

            this.logger.warn(`卡密重复（尝试 ${attempt}/${maxRetries}）: ${keyCode}`)
        }

        throw new Error('生成唯一卡密失败：已达到最大重试次数')
    }

    /**
     * 批量创建卡密
     * @param level 权限等级（2或10）
     * @param days 有效天数
     * @param count 生成数量
     * @param note 备注
     * @param createdBy 生成者用户ID
     */
    async createKeys(
        level: number,
        days: number,
        count: number,
        note: string | undefined,
        createdBy: string
    ): Promise<ActivationKey[]> {
        // 参数验证
        if (level !== 2 && level !== 10) {
            throw new Error('权限等级只能是 2 或 10')
        }
        if (days <= 0) {
            throw new Error('天数必须大于 0')
        }
        if (count <= 0 || count > 100) {
            throw new Error('数量必须在 1-100 之间')
        }

        const createdKeys: ActivationKey[] = []

        try {
            for (let i = 0; i < count; i++) {
                const keyCode = await this.generateKey()

                const keyData: Partial<ActivationKey> = {
                    key_code: keyCode,
                    permission_level: level,
                    duration_days: days,
                    status: 'unused',
                    note: note,
                    created_at: new Date(),
                    created_by: createdBy
                }

                const createdKey = await this.ctx.database.create('orproxy_activation_keys', keyData)
                createdKeys.push(createdKey)

                this.logger.info(`卡密已生成 (${i + 1}/${count}): ${keyCode}`)
            }

            return createdKeys
        } catch (error) {
            // 如果失败，尝试回滚已创建的卡密
            if (createdKeys.length > 0) {
                this.logger.error(`生成失败，回滚 ${createdKeys.length} 个卡密`)
                for (const key of createdKeys) {
                    try {
                        await this.ctx.database.remove('orproxy_activation_keys', { id: key.id })
                    } catch (rollbackError) {
                        this.logger.error(`回滚失败: ${key.key_code}`, rollbackError)
                    }
                }
            }

            throw error
        }
    }

    /**
     * 兑换卡密
     * @param keyCode 卡密代码
     * @param userId 用户ID
     * @param platform 平台
     */
    async redeemKey(keyCode: string, userId: string, platform: string): Promise<{
        key: ActivationKey
        permissionLevel: number
        expiresAt: Date
        isNewGrant: boolean
    }> {
        // 格式化卡密（去除空格、转大写）
        const formattedKey = keyCode.trim().toUpperCase()

        // 验证格式
        if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(formattedKey)) {
            throw new Error('卡密格式错误')
        }

        // 查询卡密
        const keys = await this.ctx.database.get('orproxy_activation_keys', {
            key_code: formattedKey
        })

        if (keys.length === 0) {
            throw new Error('卡密不存在')
        }

        const key = keys[0]

        // 检查是否已使用
        if (key.status === 'used') {
            throw new Error('卡密已被使用')
        }

        // 获取用户当前权限
        const currentPermissions = await this.ctx.database.get('orproxy_user_permissions', {
            user_id: userId,
            platform: platform
        })

        let expiresAt: Date
        let permissionLevel: number
        let isNewGrant = false

        if (currentPermissions.length === 0) {
            // 新用户，直接授予权限
            expiresAt = new Date(Date.now() + key.duration_days * 86400000)
            permissionLevel = key.permission_level
            isNewGrant = true
        } else {
            const current = currentPermissions[0]
            const now = new Date()

            // 检查当前权限是否已过期
            const isExpired = current.expires_at < now

            if (isExpired) {
                // 已过期，按新授予处理
                expiresAt = new Date(Date.now() + key.duration_days * 86400000)
                permissionLevel = key.permission_level
                isNewGrant = true
            } else if (current.permission_level === key.permission_level) {
                // 同等级，叠加时长
                expiresAt = new Date(current.expires_at.getTime() + key.duration_days * 86400000)
                permissionLevel = key.permission_level
            } else if (key.permission_level > current.permission_level) {
                // 更高等级，覆盖并重新计算
                expiresAt = new Date(Date.now() + key.duration_days * 86400000)
                permissionLevel = key.permission_level
                isNewGrant = true
            } else {
                // 更低等级，不允许降级
                throw new Error('无法使用低于当前等级的卡密')
            }
        }

        // 标记卡密为已使用
        await this.ctx.database.set('orproxy_activation_keys', { id: key.id }, {
            status: 'used',
            used_at: new Date(),
            used_by: userId,
            used_platform: platform
        })

        this.logger.info(`卡密已兑换: ${formattedKey} by ${userId} (${platform})`)

        return {
            key,
            permissionLevel,
            expiresAt,
            isNewGrant
        }
    }

    /**
     * 查询卡密列表
     * @param status 状态筛选（'all' | 'unused' | 'used'）
     */
    async listKeys(status?: 'all' | 'unused' | 'used'): Promise<ActivationKey[]> {
        if (!status || status === 'all') {
            return await this.ctx.database.get('orproxy_activation_keys', {})
        } else {
            return await this.ctx.database.get('orproxy_activation_keys', { status })
        }
    }

    /**
     * 删除卡密（仅限未使用的）
     * @param keyCode 卡密代码
     */
    async deleteKey(keyCode: string): Promise<void> {
        const formattedKey = keyCode.trim().toUpperCase()

        const keys = await this.ctx.database.get('orproxy_activation_keys', {
            key_code: formattedKey
        })

        if (keys.length === 0) {
            throw new Error('卡密不存在')
        }

        const key = keys[0]

        if (key.status === 'used') {
            throw new Error('已使用的卡密无法删除')
        }

        await this.ctx.database.remove('orproxy_activation_keys', { id: key.id })

        this.logger.info(`卡密已删除: ${formattedKey}`)
    }

    /**
     * 验证卡密是否有效
     * @param keyCode 卡密代码
     */
    async validateKey(keyCode: string): Promise<boolean> {
        const formattedKey = keyCode.trim().toUpperCase()

        if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(formattedKey)) {
            return false
        }

        const keys = await this.ctx.database.get('orproxy_activation_keys', {
            key_code: formattedKey,
            status: 'unused'
        })

        return keys.length > 0
    }
}

