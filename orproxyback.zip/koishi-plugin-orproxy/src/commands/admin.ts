/**
 * 管理员指令集
 * 权限要求：
 * - 99级：超级管理员（所有权限）
 * - 100级：系统管理员（所有权限 + 紧急操作）
 */

import { Context } from 'koishi'
import { MaintenanceService } from '../services/maintenance'
import { BanService } from '../services/ban'
import { MachineLockService } from '../services/lock'
import { MachineService } from '../services/machine'
import { DigitalOceanService } from '../services/digitalocean'
import { ZBProxyService } from '../services/zbproxy'
import { BlacklistService } from '../services/blacklist'
import { Logger } from '../utils/logger'

export function registerAdminCommands(
    ctx: Context,
    maintenanceService: MaintenanceService,
    banService: BanService,
    lockService: MachineLockService,
    machineService: MachineService,
    doService: DigitalOceanService,
    zbproxyService: ZBProxyService,
    blacklistService: BlacklistService
) {
    const logger = new Logger(ctx, 'orproxy:admin')

    // ==================== 维护模式管理 ====================
    ctx.command('orproxy.maint <action:string> [machine:string]', '维护模式管理')
        .userFields(['authority'])
        .action(async ({ session }, action, machine) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const userId = session.userId || 'unknown'

            if (action === 'status') {
                // 查看所有机器的维护状态
                const machines = machineService.listMachines()
                const lines: string[] = ['维护模式状态：', '─'.repeat(50)]

                for (const m of machines) {
                    const info = maintenanceService.isInMaintenance(m.machine_name)
                    if (info.inMaintenance) {
                        lines.push(`[${m.machine_name}] 维护中`)
                        lines.push(`  原因: ${info.reason || '未说明'}`)
                    } else {
                        lines.push(`[${m.machine_name}] 正常运行`)
                    }
                }

                return lines.join('\n')
            }

            if (!machine) {
                return '请指定服务器名称'
            }

            if (!machineService.validateMachine(machine)) {
                return `服务器 "${machine}" 不存在`
            }

            if (action === 'on') {
                const reason = '管理员启用维护模式'
                maintenanceService.setMaintenance(machine, true, reason)
                logger.info(`管理员 ${userId} 启用维护模式: ${machine}`)
                return `服务器 "${machine}" 已进入维护模式`
            }

            if (action === 'off') {
                maintenanceService.setMaintenance(machine, false)
                logger.info(`管理员 ${userId} 关闭维护模式: ${machine}`)
                return `服务器 "${machine}" 已退出维护模式`
            }

            return '无效的操作，请使用 on/off/status'
        })

    ctx.command('orproxy.emergency', '紧急关闭全局维护模式')
        .userFields(['authority'])
        .action(async ({ session }) => {
            if (!session || !session.user || session.user.authority < 100) {
                return '权限不足（需要100级权限）'
            }

            const userId = session.userId || 'unknown'
            const machines = machineService.listMachines()
            let count = 0

            for (const m of machines) {
                const info = maintenanceService.isInMaintenance(m.machine_name)
                if (info.inMaintenance) {
                    maintenanceService.setMaintenance(m.machine_name, false)
                    count++
                }
            }

            logger.info(`管理员 ${userId} 执行紧急关闭全局维护模式，影响 ${count} 台机器`)
            return `已关闭 ${count} 台机器的维护模式`
        })

    // ==================== 用户封禁管理 ====================
    ctx.command('orproxy.ban <targetUserId:string> [duration:number]', '封禁用户')
        .userFields(['authority'])
        .option('reason', '-r <reason:string> 封禁原因')
        .action(async ({ session, options }, targetUserId, duration = 7) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'
            const reason = options?.reason || '违反使用规则'

            await banService.banUser(targetUserId, platform, reason, duration, userId)
            logger.info(`管理员 ${userId} 封禁用户 ${targetUserId}，时长 ${duration} 天，原因: ${reason}`)

            return `已封禁用户 ${targetUserId}\n时长: ${duration} 天\n原因: ${reason}`
        })

    ctx.command('orproxy.unban <targetUserId:string>', '解封用户')
        .userFields(['authority'])
        .action(async ({ session }, targetUserId) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            await banService.unbanUser(targetUserId, platform)
            logger.info(`管理员 ${userId} 解封用户 ${targetUserId}`)

            return `已解封用户 ${targetUserId}`
        })

    ctx.command('orproxy.banlist', '查看封禁列表')
        .userFields(['authority'])
        .action(async ({ session }) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const bans = await banService.getBanList()

            if (bans.length === 0) {
                return '当前没有被封禁的用户'
            }

            const lines: string[] = ['封禁用户列表：', '─'.repeat(50)]

            for (const ban of bans) {
                lines.push(`用户ID: ${ban.user_id}`)
                lines.push(`  平台: ${ban.platform}`)
                lines.push(`  原因: ${ban.reason}`)
                lines.push(`  封禁时间: ${ban.banned_at.toLocaleString('zh-CN')}`)
                lines.push(`  解封时间: ${ban.banned_until.toLocaleString('zh-CN')}`)
                lines.push(`  操作人: ${ban.banned_by}`)
                lines.push('')
            }

            return lines.join('\n')
        })

    // ==================== 强制操作 ====================
    ctx.command('orproxy.forcestart <machine:string>', '强制启动机器（忽略锁）')
        .userFields(['authority'])
        .action(async ({ session }, machine) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const userId = session.userId || 'unknown'

            // 强制释放锁
            await lockService.release(machine)
            logger.info(`管理员 ${userId} 强制释放锁: ${machine}`)

            // 调用 start 命令（使用 -f 选项跳过维护模式）
            return `已释放机器锁，请使用 "start ${machine}" 命令启动`
        })

    ctx.command('orproxy.forcestop <machine:string>', '强制停止机器（忽略锁）')
        .userFields(['authority'])
        .action(async ({ session }, machine) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            if (!machineService.validateMachine(machine)) {
                return `服务器 "${machine}" 不存在`
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'
            const machineConfig = machineService.getMachine(machine)!

            try {
                await session.send(`正在强制停止服务器 "${machine}"...`)

                // 获取当前 IP
                const currentIP = await doService.getDropletIP(machineConfig.droplet_id, machineConfig.account_name)

                if (!currentIP) {
                    await lockService.release(machine)
                    return `服务器 "${machine}" 当前未运行`
                }

                // 停止 ZBProxy
                try {
                    await zbproxyService.stop(currentIP, machineConfig.zbproxy_port)
                } catch (e) {
                    logger.warn(`停止 ZBProxy 失败:`, e)
                }

                // 添加到黑名单
                blacklistService.add(currentIP, machine, userId, platform, 'stop')

                // 解绑 IP
                await doService.unassignIP(currentIP, machineConfig.account_name)

                // 记录历史
                await logger.logHistory({
                    machine_name: machine,
                    old_ip: currentIP,
                    new_ip: '',
                    action: 'stop',
                    user_id: userId,
                    adapter_type: platform,
                    status: 'success'
                })

                // 强制释放锁
                await lockService.release(machine)

                logger.info(`管理员 ${userId} 强制停止机器: ${machine}, IP: ${currentIP}`)

                return `服务器 "${machine}" 已强制停止\nIP ${currentIP} 已拉黑`
            } catch (error: any) {
                logger.error(`强制停止失败: ${machine}`, error)
                await lockService.release(machine)
                return `强制停止失败: ${error?.message || 'Unknown error'}`
            }
        })

    // ==================== 统计和日志 ====================
    ctx.command('orproxy.usage [days:number]', '查看使用统计')
        .userFields(['authority'])
        .action(async ({ session }, days = 7) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const startDate = new Date()
            startDate.setDate(startDate.getDate() - days)

            const history = await ctx.database.get('orproxy_ip_history', {})

            if (history.length === 0) {
                return `最近 ${days} 天没有使用记录`
            }

            // 统计每个用户的使用次数
            const userStats = new Map<string, number>()
            for (const record of history) {
                const key = `${record.user_id}@${record.adapter_type}`
                userStats.set(key, (userStats.get(key) || 0) + 1)
            }

            // 统计每台机器的使用次数
            const machineStats = new Map<string, number>()
            for (const record of history) {
                machineStats.set(record.machine_name, (machineStats.get(record.machine_name) || 0) + 1)
            }

            const lines: string[] = [
                `最近 ${days} 天使用统计：`,
                '─'.repeat(50),
                `总操作次数: ${history.length}`,
                '',
                '用户使用排行：'
            ]

            const sortedUsers = Array.from(userStats.entries())
                .sort((a, b) => b[1] - a[1])
                .slice(0, 10)

            for (const [user, count] of sortedUsers) {
                lines.push(`  ${user}: ${count} 次`)
            }

            lines.push('', '机器使用排行：')

            const sortedMachines = Array.from(machineStats.entries())
                .sort((a, b) => b[1] - a[1])

            for (const [machine, count] of sortedMachines) {
                lines.push(`  ${machine}: ${count} 次`)
            }

            return lines.join('\n')
        })

    ctx.command('orproxy.logs [targetUserId:string] [page:number]', '查看使用记录')
        .userFields(['authority'])
        .action(async ({ session }, targetUserId, page = 1) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const pageSize = 10
            const offset = (page - 1) * pageSize

            const query = targetUserId ? { user_id: targetUserId } : {}
            const total = await ctx.database.get('orproxy_ip_history', query)
            const history = await ctx.database
                .select('orproxy_ip_history')
                .where(query)
                .orderBy('id', 'desc')
                .limit(pageSize)
                .offset(offset)
                .execute()

            if (history.length === 0) {
                return '没有找到记录'
            }

            const lines: string[] = [
                `使用记录（第 ${page} 页，共 ${Math.ceil(total.length / pageSize)} 页）：`,
                '─'.repeat(50)
            ]

            for (const record of history) {
                lines.push(`[ID: ${record.id}]`)
                lines.push(`  用户: ${record.user_id}@${record.adapter_type}`)
                lines.push(`  机器: ${record.machine_name}`)
                lines.push(`  操作: ${record.action}`)
                lines.push(`  IP: ${record.old_ip || '无'} -> ${record.new_ip || '无'}`)
                lines.push(`  状态: ${record.status}`)
                lines.push('')
            }

            return lines.join('\n')
        })

    // ==================== 权限管理 ====================
    ctx.command('orproxy.checkperm', '查看自己的权限')
        .userFields(['authority'])
        .action(async ({ session }) => {
            if (!session || !session.user) {
                return '无法获取用户信息'
            }

            const authority = session.user.authority || 0
            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            let level = '普通用户'
            if (authority >= 100) level = '系统管理员'
            else if (authority >= 99) level = '超级管理员'
            else if (authority >= 3) level = '管理员'

            return `用户信息：\n用户ID: ${userId}\n平台: ${platform}\n权限等级: ${authority} (${level})`
        })

    logger.info('管理员指令已注册')
}

