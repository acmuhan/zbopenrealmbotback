import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { ActivationKeyService } from '../services/activation-key'
import { PermissionService } from '../services/permission'

/**
 * 注册卡密兑换相关的用户命令
 */
export function registerRedeemCommands(
    ctx: Context,
    activationKeyService: ActivationKeyService,
    permissionService: PermissionService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:redeem')

    // 卡密兑换命令
    ctx.command('orproxy.redeem <keyCode:string>', '兑换权限卡密')
        .alias('redeem')
        .userFields(['authority', 'id'])
        .action(async ({ session }, keyCode) => {
            if (!session || !session.user) {
                return '请先登录'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            if (!keyCode) {
                return '请输入卡密'
            }

            try {
                // 兑换卡密
                const result = await activationKeyService.redeemKey(keyCode, userId, platform)

                // 更新权限记录
                await permissionService.grantPermission(
                    userId,
                    platform,
                    result.permissionLevel,
                    result.key.duration_days,
                    result.key.key_code
                )

                // 格式化输出
                const levelName = result.permissionLevel === 2
                    ? session.text('commands.orproxy.redeem.level-2')
                    : session.text('commands.orproxy.redeem.level-10')

                let message = session.text('commands.orproxy.redeem.success') + '\n'
                message += '━'.repeat(50) + '\n'
                message += `\n权限等级: ${result.permissionLevel}级（${levelName}）\n`
                message += `有效时长: ${result.key.duration_days}天\n`

                const expiresAtStr = result.expiresAt.toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                })
                message += `到期时间: ${expiresAtStr}\n`
                message += '━'.repeat(50) + '\n'

                if (result.isNewGrant) {
                    message += '\n感谢您的支持！'
                } else {
                    message += '\n权限时长已叠加！'
                }

                logger.info(`卡密兑换成功: ${userId} (${platform}) -> Level ${result.permissionLevel}`)

                return message
            } catch (error: any) {
                logger.error('卡密兑换失败', error)

                if (error.message.includes('格式错误')) {
                    return session.text('commands.orproxy.redeem.invalid-format')
                } else if (error.message.includes('不存在') || error.message.includes('已被使用')) {
                    return session.text('commands.orproxy.redeem.not-found')
                } else if (error.message.includes('低于当前等级')) {
                    return '无法使用低于当前等级的卡密'
                }

                return `兑换失败: ${error?.message || '未知错误'}`
            }
        })

    // 查看权限状态命令（已在 admin.ts 中有 checkperm，这里增强一下）
    ctx.command('orproxy.mystatus', '查看我的权限状态')
        .alias('mystatus')
        .userFields(['authority', 'id'])
        .action(async ({ session }) => {
            if (!session || !session.user) {
                return '请先登录'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'
            const currentAuthority = session.user.authority || 0

            try {
                const permission = await permissionService.getUserPermission(userId, platform)

                if (!permission) {
                    return `当前权限: ${currentAuthority}级（默认权限）\n无激活记录`
                }

                const now = new Date()
                const isExpired = permission.expires_at < now

                let message = '我的权限状态\n'
                message += '━'.repeat(50) + '\n'
                message += `\n当前权限: ${currentAuthority}级\n`
                message += `激活等级: ${permission.permission_level}级\n`

                const expiresAtStr = permission.expires_at.toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit'
                })
                message += `到期时间: ${expiresAtStr}\n`

                if (isExpired) {
                    message += `状态: 已过期 ⚠️\n`
                } else {
                    const daysLeft = Math.ceil((permission.expires_at.getTime() - now.getTime()) / 86400000)
                    message += `状态: 有效（剩余 ${daysLeft} 天）\n`
                }

                if (permission.last_key_used) {
                    message += `最后使用: ${permission.last_key_used}\n`
                }

                message += '━'.repeat(50)

                return message
            } catch (error: any) {
                logger.error('查询权限状态失败', error)
                return `查询失败: ${error?.message || '未知错误'}`
            }
        })
}

