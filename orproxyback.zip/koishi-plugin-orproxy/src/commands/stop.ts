/**
 * /stop 指令实现
 * 停止机器，解绑 IP 并加入黑名单
 */

import { Context } from 'koishi'
import { DigitalOceanService } from '../services/digitalocean'
import { ZBProxyService } from '../services/zbproxy'
import { BlacklistService } from '../services/blacklist'
import { MachineService } from '../services/machine'
import { MachineLockService } from '../services/lock'
import { Logger } from '../utils/logger'
import {
    Transaction,
    StopZBProxyOperation,
    AddBlacklistOperation
} from '../utils/rollback'

export function registerStopCommand(
    ctx: Context,
    doService: DigitalOceanService,
    zbproxyService: ZBProxyService,
    blacklistService: BlacklistService,
    machineService: MachineService,
    lockService: MachineLockService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:stop')

    ctx.command('orproxy.stop [machine:string]', '停止机器并拉黑当前 IP')
        .alias('stop')
        .userFields(['authority'])
        .option('force', '-f 强制执行（跳过锁检查）')
        .action(async ({ session, options }, machine) => {
            if (!session) return

            // 权限检查 - 需要 level 2+
            if (!session.user || session.user.authority < 2) {
                return '权限不足（需要2级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            // 如果未指定机器，自动查找当前用户运行的机器
            if (!machine) {
                const locks = await ctx.database.get('orproxy_machine_locks', {
                    user_id: userId,
                    adapter_type: platform
                })

                if (locks.length === 0) {
                    return '您当前没有运行中的机器'
                }

                if (locks.length > 1) {
                    // 如果有多台（理论上不应该发生），列出所有
                    const machineList = locks.map(l => l.machine_name).join(', ')
                    return `您有多台机器在运行: ${machineList}\n请指定要停止的机器`
                }

                machine = locks[0].machine_name
                await session.send(`自动选择机器: ${machine}`)
            }

            logger.info(`用户 ${userId} (${platform}) 请求停止机器: ${machine}`)

            // 验证机器是否存在
            if (!machineService.validateMachine(machine)) {
                return session.text('commands.orproxy.stop.machine-not-found', [machine])
            }

            const machineConfig = machineService.getMachine(machine)!

            // 检查机器锁
            if (!options?.force) {
                const lockInfo = await lockService.getLockInfo(machine)

                if (lockInfo) {
                    // 检查是否是当前用户的锁
                    if (lockInfo.userId !== userId || lockInfo.platform !== platform) {
                        // 被其他用户锁定，拒绝操作
                        logger.warn(`机器被其他用户锁定: ${machine} by ${lockInfo.userId}`)
                        return session.text('commands.orproxy.stop.machine-locked', [
                            machine,
                            lockInfo.userId
                        ])
                    }
                    // 是当前用户的锁，允许操作（不需要重新获取）
                    logger.info(`当前用户拥有锁: ${machine}`)
                } else {
                    // 没有锁，尝试获取
                    const acquired = await lockService.acquire(machine, userId, platform)
                    if (!acquired) {
                        logger.error(`获取锁失败: ${machine}`)
                        return '无法获取机器锁，请稍后重试'
                    }
                }
            }

            // 开始执行，使用事务支持回滚
            const tx = new Transaction(logger)

            try {
                await session.send(session.text('commands.orproxy.stop.stopping', [machine]))

                // 步骤 1: 获取当前 IP
                const currentIP = await doService.getDropletIP(machineConfig.droplet_id, machineConfig.account_name)

                if (!currentIP) {
                    logger.warn(`机器没有分配 IP: ${machine}`)
                    await lockService.release(machine)
                    return session.text('commands.orproxy.stop.no-ip', [machine])
                }

                logger.info(`当前 IP: ${currentIP}`)

                // 步骤 2: 智能停止 ZBProxy（带重试）
                await session.send(session.text('commands.orproxy.stop.processing'))

                try {
                    await zbproxyService.stopWithRetry(
                        currentIP,
                        machineConfig.zbproxy_port,
                        5  // 最多重试5次
                    )
                    logger.info(`✓ ZBProxy 已停止: ${currentIP}`)
                } catch (error: any) {
                    // 如果停止失败，记录警告但继续执行（因为可能已经停止了）
                    logger.warn(`停止 ZBProxy 失败（继续执行）: ${error?.message}`)
                }

                // 步骤 3: 添加 IP 到黑名单
                await session.send(session.text('commands.orproxy.stop.cleaning'))

                const blacklistOp = new AddBlacklistOperation(
                    blacklistService,
                    currentIP,
                    machine,
                    userId,
                    platform,
                    'stop'
                )
                await tx.execute(blacklistOp)

                logger.info(`IP 已加入黑名单: ${currentIP}`)

                // 步骤 4: 解绑 IP
                await doService.unassignIP(currentIP, machineConfig.account_name)

                logger.info(`IP 已解绑: ${currentIP}`)

                // 步骤 5: 清理自定义服务器配置（如果存在）
                if (session.user && session.user.authority === 10) {
                    try {
                        const { CustomServerService } = require('../services/custom-server')
                        const customServerService = new CustomServerService(ctx)

                        const customConfig = await customServerService.getConfig(userId, platform, machine)
                        if (customConfig) {
                            // TODO: 这里可以选择是否删除自定义配置，或者只是重置 ZBProxy
                            // 目前暂不删除，只在日志中记录
                            logger.info(`权限10用户停止机器，保留自定义配置: ${machine}`)
                        }
                    } catch (error) {
                        logger.warn('检查自定义配置失败:', error)
                    }
                }

                // 步骤 6: 记录历史到数据库
                await logger.logHistory({
                    machine_name: machine,
                    old_ip: currentIP,
                    new_ip: '',
                    action: 'stop',
                    user_id: userId,
                    adapter_type: platform,
                    status: 'success'
                })

                // 步骤 7: 释放锁
                await lockService.release(machine)

                // 步骤 8: 返回成功结果
                logger.info(`机器停止成功: ${machine}, IP 已拉黑: ${currentIP}`)
                tx.clear()  // 清空事务（不回滚）

                // 构建成功消息（包含被拉黑的 IP）
                const successMsg = `服务器 "${machine}" 已停止\nIP ${currentIP} 已拉黑`

                // Discord: 使用 ephemeral（仅命令执行者可见）
                // Kook: 私信发送
                if (platform === 'discord') {
                    return session.send(successMsg)
                } else if (platform === 'kook') {
                    await session.bot.sendPrivateMessage(userId, successMsg)
                    return '操作成功，详情已私信发送'
                } else {
                    return successMsg
                }

            } catch (error: any) {
                logger.error(`停止机器失败: ${machine}`, error)

                // 回滚所有操作
                await tx.rollback()

                // 记录失败历史
                await logger.logHistory({
                    machine_name: machine,
                    old_ip: '',
                    new_ip: '',
                    action: 'stop',
                    user_id: userId,
                    adapter_type: platform,
                    status: 'rolled_back',
                    error_message: error?.message || 'Unknown error'
                })

                // 释放锁
                await lockService.release(machine)

                return session.text('commands.orproxy.stop.failed')
            }
        })
}

