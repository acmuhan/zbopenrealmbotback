/**
 * /start 指令实现（完整版）
 * 包含：封禁检查、维护模式、并发执行、智能重试、IP切换、MOTD监控、私信发送
 */

import { Context } from 'koishi'
import { DigitalOceanService } from '../services/digitalocean'
import { ZBProxyService } from '../services/zbproxy'
import { BlacklistService } from '../services/blacklist'
import { MachineService } from '../services/machine'
import { MachineLockService } from '../services/lock'
import { BanService } from '../services/ban'
import { MaintenanceService } from '../services/maintenance'
import { MonitorService } from '../services/monitor'
import { Logger } from '../utils/logger'

export function registerStartCommand(
    ctx: Context,
    doService: DigitalOceanService,
    zbproxyService: ZBProxyService,
    blacklistService: BlacklistService,
    machineService: MachineService,
    lockService: MachineLockService,
    banService: BanService,
    maintenanceService: MaintenanceService,
    monitorService: MonitorService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:start')

    ctx.command('orproxy.start [machine:string]', '启动机器并分配新 IP')
        .alias('start')
        .userFields(['authority'])
        .option('force', '-f 强制执行（跳过维护模式检查）')
        .action(async ({ session, options }, machine) => {
            if (!session) return

            // ============ 阶段一：用户信息提取和权限检查 ============
            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'
            const userAuthority = session.user?.authority || 0

            logger.info(`用户 ${userId} (${platform}) 请求启动机器: ${machine || '自动选择'}`)

            // 检查权限（至少2级）
            if (userAuthority < 2) {
                logger.warn(`权限不足: ${userId} (authority: ${userAuthority})`)
                return '权限不足（需要2级权限）'
            }

            // 并发执行权限检查和封禁检查
            const [banInfo] = await Promise.all([
                banService.isUserBanned(userId, platform)
            ])

            // 检查封禁状态
            if (banInfo) {
                logger.warn(`用户被封禁: ${userId}, 原因: ${banInfo.reason}`)
                return `您已被封禁\n原因: ${banInfo.reason}\n解封时间: ${banInfo.banned_until.toLocaleString('zh-CN')}`
            }

            // 检查2级用户的同时运行限制
            if (userAuthority === 2) {
                const locks = await ctx.database.get('orproxy_machine_locks', {
                    user_id: userId,
                    adapter_type: platform
                })

                if (locks.length > 0) {
                    return `您已有机器在运行\n请先停止机器 "${locks[0].machine_name}" 再启动新机器`
                }
            }

            // 自动选择机器（如果未指定）
            if (!machine) {
                const availableMachines = machineService.listMachines()
                const allStatuses = await Promise.all(
                    availableMachines.map(m => machineService.getMachineStatus(m.machine_name, false))
                )

                // 找到第一台空闲的机器
                for (let i = 0; i < allStatuses.length; i++) {
                    const status = allStatuses[i]
                    if (status && !status.current_ip && !status.is_locked) {
                        machine = availableMachines[i].machine_name
                        await session.send(`自动选择机器: ${machine}`)
                        break
                    }
                }

                if (!machine) {
                    return '没有可用的空闲机器'
                }
            }

            // 检查机器配置
            const machineConfig = machineService.getMachine(machine)
            if (!machineConfig) {
                return session.text('commands.orproxy.start.machine-not-found', [machine])
            }

            // 检查维护模式
            const maintenanceInfo = maintenanceService.isInMaintenance(machine)
            if (maintenanceInfo.inMaintenance) {
                if (!maintenanceService.canBypassMaintenance(userAuthority) && !options?.force) {
                    logger.warn(`机器处于维护模式: ${machine}`)
                    return `服务器 "${machine}" 正在维护\n${maintenanceInfo.reason || '系统维护中'}`
                }
            }

            // ============ 阶段二：机器状态检查与IP创建（并发） ============
            await session.send(`正在启动服务器 "${machine}"，检查状态并创建IP...\n预计需要 1-2 分钟`)

            let newIP: string
            let machineAlreadyRunning = false

            try {
                // 并发执行：任务A - 机器状态检查，任务B - 创建Reserved IP
                const [reservedIP, createdIPInfo] = await Promise.all([
                    doService.getReservedIP(machineConfig.droplet_id, machineConfig.account_name),
                    doService.createIP(machineConfig.region, machineConfig.account_name)
                ])

                newIP = createdIPInfo.ip

                // 检查机器是否已在运行（有Reserved IP且不在黑名单）
                if (reservedIP && !blacklistService.isBlacklisted(reservedIP)) {
                    machineAlreadyRunning = true

                    // 检查是否被其他用户占用
                    const lockInfo = await lockService.getLockInfo(machine)
                    if (lockInfo && (lockInfo.userId !== userId || lockInfo.platform !== platform)) {
                        // 被其他用户占用，删除新创建的IP
                        await doService.deleteIP(newIP, machineConfig.account_name)
                        return `服务器 "${machine}" 已被用户 ${lockInfo.userId} 占用`
                    }

                    // 同一用户重复启动，删除新创建的IP
                    await doService.deleteIP(newIP, machineConfig.account_name)
                    return `服务器 "${machine}" 已在运行\nIP: ${reservedIP}\n如需更换 IP，请先执行停止命令`
                }

                logger.info(`新IP创建成功: ${newIP}`)

            } catch (error: any) {
                logger.error('并发任务失败:', error)
                return `启动失败: ${error?.message || 'Unknown error'}`
            }

            // ============ 阶段三：IP黑名单检查与自动替换 ============
            let ipReplaceAttempts = 0
            const maxIPReplaceAttempts = 3

            while (blacklistService.isBlacklisted(newIP) && ipReplaceAttempts < maxIPReplaceAttempts) {
                ipReplaceAttempts++
                logger.warn(`检测到黑名单IP: ${newIP}，自动替换中... (${ipReplaceAttempts}/${maxIPReplaceAttempts})`)
                await session.send(`检测到黑名单IP，正在自动替换... (${ipReplaceAttempts}/${maxIPReplaceAttempts})`)

                // 删除黑名单IP
                await doService.deleteIP(newIP, machineConfig.account_name)

                // 创建新IP
                const newIPInfo = await doService.createIP(machineConfig.region, machineConfig.account_name)
                newIP = newIPInfo.ip
                logger.info(`新IP已替换: ${newIP}`)
            }

            // 如果替换失败
            if (blacklistService.isBlacklisted(newIP)) {
                await doService.deleteIP(newIP, machineConfig.account_name)
                return `IP替换失败（已尝试 ${maxIPReplaceAttempts} 次），所有IP均在黑名单中`
            }

            // ============ 阶段四：执行后续配置（支持智能IP切换） ============
            // 获取锁
            const lockAcquired = await lockService.acquire(machine, userId, platform)
            if (!lockAcquired) {
                await doService.deleteIP(newIP, machineConfig.account_name)
                return '无法获取机器锁，请稍后重试'
            }

            let currentIP = newIP
            let ipSwitchCount = 0
            const maxIPSwitches = 1  // 最多切换1次（即最多尝试2个IP）

            while (ipSwitchCount <= maxIPSwitches) {
                try {
                    // 步骤1：等待服务器就绪（5-10秒随机）
                    const waitTime = 5000 + Math.random() * 5000
                    logger.info(`等待服务器就绪: ${waitTime}ms`)
                    await new Promise(resolve => setTimeout(resolve, waitTime))

                    // 步骤2：分配IP到Droplet
                    await session.send('正在分配IP（DigitalOcean 异步操作，需要约20秒）...')
                    await doService.assignIP(currentIP, machineConfig.droplet_id, machineConfig.account_name)
                    await session.send('IP分配请求已提交')

                    // 获取主IP（用于访问ZBProxy API）
                    const mainIP = await doService.getDropletMainIP(machineConfig.droplet_id, machineConfig.account_name)
                    if (!mainIP) {
                        throw new Error('无法获取服务器主IP')
                    }
                    logger.info(`服务器主IP: ${mainIP}, Reserved IP: ${currentIP}`)

                    // 步骤3：配置Linux路由（快速失败，减少重试）
                    await session.send('正在配置网络路由...')
                    try {
                        await zbproxyService.configureLinuxIP(
                            mainIP,  // 使用主IP访问API
                            machineConfig.zbproxy_port,
                            currentIP,  // 配置Reserved IP
                            3  // 只重试3次，加快失败速度
                        )
                    } catch (linuxIPError: any) {
                        // Linux路由配置失败，触发IP切换
                        if (ipSwitchCount < maxIPSwitches) {
                            ipSwitchCount++
                            logger.warn(`网络配置失败，触发IP切换 (${ipSwitchCount}/${maxIPSwitches})`)
                            await session.send(`配置失败，正在更换IP重试... (${ipSwitchCount}/${maxIPSwitches})`)

                            // 清理当前IP
                            try {
                                await doService.unassignIP(currentIP, machineConfig.account_name)
                                await doService.deleteIP(currentIP, machineConfig.account_name)
                            } catch (cleanupError) {
                                logger.warn('清理IP失败（继续）:', cleanupError)
                            }

                            // 创建新IP并更新锁
                            const newIPInfo = await doService.createIP(machineConfig.region, machineConfig.account_name)
                            currentIP = newIPInfo.ip
                            logger.info(`✓ 已切换到新IP: ${currentIP}`)
                            await session.send(`新IP: ${currentIP}，重新配置...`)

                            continue  // 重新开始配置流程
                        } else {
                            throw new Error(`网络配置失败（已尝试 ${maxIPSwitches + 1} 个IP）`)
                        }
                    }

                    // 步骤3.5：快速验证 Reserved IP（assignIP 已等待15秒）
                    await session.send('验证IP分配...')
                    logger.info(`快速验证 Reserved IP: ${currentIP}`)

                    const assignedIP = await doService.getReservedIP(machineConfig.droplet_id, machineConfig.account_name)

                    if (assignedIP !== currentIP) {
                        // 只重试1次，等待5秒
                        logger.warn(`IP验证未通过（首次）: 期望 ${currentIP}, 实际 ${assignedIP || '无'}，等待5秒后重试...`)
                        await new Promise(resolve => setTimeout(resolve, 5000))

                        const assignedIP2 = await doService.getReservedIP(machineConfig.droplet_id, machineConfig.account_name)

                        if (assignedIP2 !== currentIP) {
                            throw new Error(`IP分配验证失败：期望 ${currentIP}，实际 ${assignedIP2 || '无'}`)
                        }
                    }

                    logger.info(`✓ Reserved IP 分配验证成功: ${currentIP}`)
                    await session.send(`IP分配成功`)

                    // 步骤4：重启ZBProxy（使用 Reserved IP，智能重试，最多8次）
                    await session.send('正在重启代理服务...')
                    logger.info(`使用 Reserved IP 重启 ZBProxy: ${currentIP}`)
                    await zbproxyService.restartWithRetry(
                        currentIP,  // 使用 Reserved IP（因为路由已配置）
                        machineConfig.zbproxy_port,
                        8
                    )

                    // 配置成功，跳出循环
                    break

                } catch (error: any) {
                    logger.error('配置流程失败:', error)

                    // 清理资源（容错）
                    try {
                        await doService.unassignIP(currentIP, machineConfig.account_name)
                    } catch (e) {
                        logger.warn('清理：解绑IP失败', e)
                    }

                    try {
                        await doService.deleteIP(currentIP, machineConfig.account_name)
                    } catch (e) {
                        logger.warn('清理：删除IP失败', e)
                    }

                    try {
                        await lockService.release(machine)
                    } catch (e) {
                        logger.warn('清理：释放锁失败', e)
                    }

                    return `启动失败: ${error?.message || 'Unknown error'}`
                }
            }

            // ============ 阶段五：特殊配置与监控启动 ============
            // 权限10用户的自定义服务器配置
            if (userAuthority === 10) {
                try {
                    logger.info(`应用权限10用户的自定义配置: ${userId}`)

                    const { CustomServerService } = require('../services/custom-server')
                    const customServerService = new CustomServerService(ctx)

                    const customConfig = await customServerService.getConfig(userId, platform, machineConfig.machine_name)

                    // 检查配置是否完整且有效
                    if (customConfig && customConfig.server_address && customConfig.server_address.trim() !== '') {
                        await session.send('应用自定义服务器配置...')

                        logger.info(`准备应用自定义配置: ${customConfig.server_address}:${customConfig.server_port}`)

                        // 更新 Minecraft 服务器配置
                        await zbproxyService.updateMinecraftServer(
                            currentIP,
                            machineConfig.zbproxy_port,
                            customConfig.server_address,
                            customConfig.server_port
                        )

                        logger.info(`✓ 已更新 ZBProxy 配置`)

                        // 重启 ZBProxy 使配置生效（ZBProxy 不会热重载配置）
                        await session.send('重启服务以应用配置...')
                        await zbproxyService.restartWithRetry(currentIP, machineConfig.zbproxy_port, 5)

                        logger.info(`✓ 自定义配置已生效: ${customConfig.server_address}:${customConfig.server_port}`)
                    } else {
                        logger.info('未找到有效的自定义配置，跳过')
                    }
                } catch (error: any) {
                    logger.error('应用自定义配置失败:', error)
                    // 不中断启动流程，只记录错误
                }
            }

            // 启动MOTD监控（如果配置了MC服务器）
            if (machineConfig.mc_server_port && machineConfig.enable_monitoring !== false) {
                try {
                    logger.info(`启动MOTD监控: ${machine}`)
                    // 监控服务会自动检测所有机器
                } catch (error) {
                    logger.warn('MOTD监控启动失败:', error)
                }
            }

            // ============ 阶段六：结果通知 ============
            const successMsg = `服务器 "${machine}" 已就绪\nIP: ${currentIP}`

            // 私信发送IP信息
            let privateMsgSent = false

            try {
                if (platform === 'discord') {
                    // Discord: 尝试ephemeral消息
                    await session.send(successMsg)
                    privateMsgSent = true
                } else if (platform === 'kook') {
                    // Kook: 私信发送
                    await session.bot.sendPrivateMessage(userId, successMsg)
                    privateMsgSent = true
                    await session.send('操作成功，IP信息已私信发送')
                } else {
                    // 其他平台：尝试私信
                    try {
                        await session.bot.sendPrivateMessage(userId, successMsg)
                        privateMsgSent = true
                        await session.send('操作成功，IP信息已私信发送')
                    } catch (dmError) {
                        // 私信失败，回退到群组消息
                        await session.send(successMsg)
                        privateMsgSent = true
                    }
                }
            } catch (error) {
                logger.error('私信发送失败:', error)
                privateMsgSent = false
            }

            // 私信完全失败处理（安全机制）
            if (!privateMsgSent) {
                logger.warn('无法发送私信，自动停止机器')

                // 立即停止机器
                try {
                    await zbproxyService.stop(currentIP, machineConfig.zbproxy_port)
                } catch (e) {
                    logger.error('停止ZBProxy失败:', e)
                }

                // 删除IP
                try {
                    await doService.unassignIP(currentIP, machineConfig.account_name)
                    await doService.deleteIP(currentIP, machineConfig.account_name)
                } catch (e) {
                    logger.error('删除IP失败:', e)
                }

                // 释放锁
                await lockService.release(machine)

                return `无法发送私信，已自动停止机器\n请添加机器人为好友后重新启动`
            }

            logger.info(`机器启动成功: ${machine}, IP: ${currentIP}`)
            return  // 消息已发送
        })
}

