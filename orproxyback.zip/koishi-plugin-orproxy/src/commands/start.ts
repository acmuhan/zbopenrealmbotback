/**
 * /start 指令实现
 * 为指定机器分配 IP，自动处理黑名单 IP
 */

import { Context, Session } from 'koishi'
import { DigitalOceanService } from '../services/digitalocean'
import { ZBProxyService } from '../services/zbproxy'
import { BlacklistService } from '../services/blacklist'
import { MachineService } from '../services/machine'
import { MachineLockService } from '../services/lock'
import { Logger } from '../utils/logger'
import {
    Transaction,
    CreateIPOperation,
    AssignIPOperation,
    DeleteIPOperation,
    RestartZBProxyOperation
} from '../utils/rollback'

export function registerStartCommand(
    ctx: Context,
    doService: DigitalOceanService,
    zbproxyService: ZBProxyService,
    blacklistService: BlacklistService,
    machineService: MachineService,
    lockService: MachineLockService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:start')

    ctx.command('orproxy.start <machine:string>', '启动机器并分配新 IP')
        .alias('start')
        .userFields(['authority'])
        .option('force', '-f 强制执行（跳过锁检查）')
        .action(async ({ session, options }, machine) => {
            if (!session) return
            if (!machine) {
                return session.text('commands.orproxy.start.no-machine')
            }

            // 权限检查 - 需要 level 3+
            if (!session.user || session.user.authority < 3) {
                return session.text('commands.orproxy.start.no-permission')
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            logger.info(`用户 ${userId} (${platform}) 请求启动机器: ${machine}`)

            // 验证机器是否存在
            if (!machineService.validateMachine(machine)) {
                return session.text('commands.orproxy.start.machine-not-found', [machine])
            }

            const machineConfig = machineService.getMachine(machine)!

            // 检查机器锁
            if (!options?.force) {
                const lockInfo = await lockService.getLockInfo(machine)

                if (lockInfo) {
                    // 检查是否是当前用户的锁
                    if (lockInfo.userId !== userId || lockInfo.platform !== platform) {
                        // 被其他用户锁定，拒绝操作
                        logger.warn(`机器被其他用户锁定: ${machine} by ${lockInfo.userId}`)
                        return session.text('commands.orproxy.start.machine-locked', [
                            machine,
                            lockInfo.userId
                        ])
                    }
                    // 是当前用户的锁，允许操作（不需要重新获取）
                    logger.info(`当前用户拥有锁: ${machine}`)
                } else {
                    // 没有锁，尝试获取
                    const acquired = await lockService.acquire(machine, userId, platform)
                    if (!acquired) {
                        logger.error(`获取锁失败: ${machine}`)
                        return '❌ 无法获取机器锁，请稍后重试'
                    }
                }
            }

            // 开始执行，使用事务支持回滚
            const tx = new Transaction(logger)
            let oldIP: string | undefined

            try {
                await session.send(session.text('commands.orproxy.start.starting', [machine]))

                // 步骤 1: 检查机器是否已经在运行（有 Reserved IP = 在运行）
                await session.send(session.text('commands.orproxy.start.checking'))
                const reservedIP = await doService.getReservedIP(machineConfig.droplet_id)

                if (reservedIP && !blacklistService.isBlacklisted(reservedIP)) {
                    // 机器已有 Reserved IP 且不在黑名单 = 已在运行
                    logger.warn(`机器已在运行: ${machine}, Reserved IP: ${reservedIP}`)
                    await lockService.release(machine)

                    const alreadyRunningMsg = `⚠️ 服务器 "${machine}" 已在运行\n🌐 IP: ${reservedIP}\n💡 如需更换 IP，请先执行停止命令`

                    if (platform === 'discord') {
                        return session.send(alreadyRunningMsg)
                    } else if (platform === 'kook') {
                        await session.bot.sendPrivateMessage(userId, alreadyRunningMsg)
                        return '⚠️ 服务器已在运行，详情已私信发送'
                    } else {
                        return alreadyRunningMsg
                    }
                }

                // 步骤 2: 获取当前 IP（用于黑名单检查）
                oldIP = reservedIP || undefined
                if (oldIP) {
                    logger.info(`当前 Reserved IP: ${oldIP}`)
                }

                // 步骤 3: 检查当前 IP 是否在黑名单
                if (oldIP && blacklistService.isBlacklisted(oldIP)) {
                    logger.warn(`当前 IP 在黑名单中: ${oldIP}，将删除并创建新 IP`)
                    await session.send(session.text('commands.orproxy.start.configuring'))

                    // 解绑并删除黑名单 IP
                    await tx.execute(new DeleteIPOperation(doService, oldIP))

                    // 等待一下确保删除完成
                    await new Promise(resolve => setTimeout(resolve, 2000))
                }

                // 步骤 4: 创建新 IP（如果需要）
                let newIP = oldIP
                if (!oldIP || blacklistService.isBlacklisted(oldIP)) {
                    await session.send(session.text('commands.orproxy.start.configuring'))

                    const createOp = new CreateIPOperation(doService, machineConfig.region)
                    newIP = await tx.execute(createOp)

                    logger.info(`新 IP 创建成功: ${newIP}`)

                    // 等待 IP 可用
                    await new Promise(resolve => setTimeout(resolve, 3000))
                }

                // 步骤 5: 分配 IP 到 Droplet
                if (newIP !== oldIP) {
                    await session.send(session.text('commands.orproxy.start.applying'))

                    const assignOp = new AssignIPOperation(
                        doService,
                        newIP!,
                        machineConfig.droplet_id,
                        oldIP
                    )
                    await tx.execute(assignOp)

                    logger.info(`IP 分配成功: ${newIP} -> Droplet ${machineConfig.droplet_id}`)

                    // 等待分配生效
                    await new Promise(resolve => setTimeout(resolve, 5000))
                }

                // 步骤 6: 重启 ZBProxy
                await session.send(session.text('commands.orproxy.start.finalizing'))

                const restartOp = new RestartZBProxyOperation(
                    zbproxyService,
                    newIP!,
                    machineConfig.zbproxy_port
                )
                await tx.execute(restartOp)

                logger.info(`ZBProxy 重启成功: ${newIP}`)

                // 步骤 7: 记录历史到数据库
                await logger.logHistory({
                    machine_name: machine,
                    old_ip: oldIP,
                    new_ip: newIP!,
                    action: 'start',
                    user_id: userId,
                    adapter_type: platform,
                    status: 'success'
                })

                // 步骤 8: 释放锁
                await lockService.release(machine)

                // 步骤 9: 返回成功结果
                logger.info(`机器启动成功: ${machine}, IP: ${newIP}`)
                tx.clear()  // 清空事务（不回滚）

                // 构建成功消息（包含 IP）
                const successMsg = `✅ 服务器 "${machine}" 已就绪！\n🌐 IP: ${newIP}`

                // Discord: 使用 ephemeral（仅命令执行者可见）
                // Kook: 私信发送
                if (platform === 'discord') {
                    // Discord ephemeral 消息
                    return session.send(successMsg)
                } else if (platform === 'kook') {
                    // Kook 私信
                    await session.bot.sendPrivateMessage(userId, successMsg)
                    return '✅ 操作成功，详情已私信发送'
                } else {
                    // 其他平台（如 sandbox）直接返回
                    return successMsg
                }

            } catch (error: any) {
                logger.error(`启动机器失败: ${machine}`, error)

                // 回滚所有操作
                await tx.rollback()

                // 记录失败历史
                await logger.logHistory({
                    machine_name: machine,
                    old_ip: oldIP,
                    new_ip: '',
                    action: 'start',
                    user_id: userId,
                    adapter_type: platform,
                    status: 'rolled_back',
                    error_message: error?.message || 'Unknown error'
                })

                // 释放锁
                await lockService.release(machine)

                return session.text('commands.orproxy.start.failed')
            }
        })
}

