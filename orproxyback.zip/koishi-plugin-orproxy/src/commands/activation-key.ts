import { Context } from 'koishi'
import { Logger } from '../utils/logger'
import { ActivationKeyService } from '../services/activation-key'

/**
 * 注册卡密管理相关的管理员命令
 */
export function registerActivationKeyCommands(
    ctx: Context,
    activationKeyService: ActivationKeyService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:key')

    // 生成卡密命令
    ctx.command('orproxy.genkey <level:number> <days:number> [count:number]', '生成权限卡密（99级权限）')
        .alias('genkey')
        .userFields(['authority'])
        .option('note', '-n <note:string> 备注信息')
        .action(async ({ session, options }, level, days, count = 1) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            const userId = session.userId || 'unknown'

            // 参数验证
            if (!level || !days) {
                return session.text('commands.orproxy.genkey.usage')
            }

            if (level !== 2 && level !== 10) {
                return session.text('commands.orproxy.genkey.invalid-level')
            }

            if (days <= 0) {
                return session.text('commands.orproxy.genkey.invalid-days')
            }

            if (count <= 0 || count > 100) {
                return session.text('commands.orproxy.genkey.invalid-count')
            }

            try {
                await session.send(`正在生成 ${count} 个卡密，请稍候...`)

                const keys = await activationKeyService.createKeys(
                    level,
                    days,
                    count,
                    options?.note,
                    userId
                )

                // 格式化输出
                let message = session.text('commands.orproxy.genkey.success', [count]) + '\n'
                message += '━'.repeat(50) + '\n'

                for (let i = 0; i < keys.length; i++) {
                    const key = keys[i]
                    message += `\n卡密${i + 1}: ${key.key_code}\n`
                    message += `权限: ${key.permission_level}级 | 时长: ${key.duration_days}天\n`
                    if (key.note) {
                        message += `备注: ${key.note}\n`
                    }
                    message += '━'.repeat(50)
                    if (i < keys.length - 1) message += '\n'
                }

                return message
            } catch (error: any) {
                logger.error('生成卡密失败', error)
                return `生成失败: ${error?.message || '未知错误'}`
            }
        })

    // 查看卡密列表命令
    ctx.command('orproxy.keylist [status:string]', '查看卡密列表（99级权限）')
        .alias('keylist')
        .userFields(['authority'])
        .action(async ({ session }, status) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            // 验证状态参数
            const validStatuses = ['all', 'unused', 'used']
            const filterStatus = status && validStatuses.includes(status) ? status as 'all' | 'unused' | 'used' : 'unused'

            try {
                const keys = await activationKeyService.listKeys(filterStatus)

                if (keys.length === 0) {
                    return session.text('commands.orproxy.keylist.empty')
                }

                // 格式化输出
                const statusText = filterStatus === 'all' ? '全部' :
                    filterStatus === 'unused' ? '未使用' : '已使用'

                let message = `${statusText}卡密列表（共 ${keys.length} 个）\n`
                message += '━'.repeat(50) + '\n'

                // 限制显示数量（每页20个）
                const displayKeys = keys.slice(0, 20)

                for (let i = 0; i < displayKeys.length; i++) {
                    const key = displayKeys[i]
                    message += `\n${key.key_code}\n`
                    message += `权限: ${key.permission_level}级 | 时长: ${key.duration_days}天\n`
                    message += `状态: ${key.status === 'unused' ? '未使用' : '已使用'}\n`

                    const createdAt = new Date(key.created_at).toLocaleString('zh-CN')
                    message += `生成: ${createdAt}`

                    if (key.note) {
                        message += ` | 备注: ${key.note}`
                    }

                    if (key.status === 'used' && key.used_by) {
                        const usedAt = key.used_at ? new Date(key.used_at).toLocaleString('zh-CN') : '未知'
                        message += `\n使用者: ${key.used_by} (${key.used_platform})\n`
                        message += `使用时间: ${usedAt}`
                    }

                    message += '\n' + '━'.repeat(50)
                    if (i < displayKeys.length - 1) message += '\n'
                }

                if (keys.length > 20) {
                    message += `\n\n只显示前 20 个，总共 ${keys.length} 个`
                }

                return message
            } catch (error: any) {
                logger.error('查询卡密列表失败', error)
                return `查询失败: ${error?.message || '未知错误'}`
            }
        })

    // 删除卡密命令
    ctx.command('orproxy.delkey <keyCode:string>', '删除卡密（99级权限）')
        .alias('delkey')
        .userFields(['authority'])
        .action(async ({ session }, keyCode) => {
            if (!session || !session.user || session.user.authority < 99) {
                return '权限不足（需要99级权限）'
            }

            if (!keyCode) {
                return '请指定要删除的卡密'
            }

            try {
                await activationKeyService.deleteKey(keyCode)
                return session.text('commands.orproxy.delkey.success')
            } catch (error: any) {
                logger.error('删除卡密失败', error)

                if (error.message.includes('不存在')) {
                    return session.text('commands.orproxy.delkey.not-found')
                } else if (error.message.includes('已使用')) {
                    return session.text('commands.orproxy.delkey.already-used')
                }

                return `删除失败: ${error?.message || '未知错误'}`
            }
        })
}

