/**
 * 自定义服务器配置命令
 * 权限要求：10级
 */

import { Context } from 'koishi'
import { CustomServerService } from '../services/custom-server'
import { Logger } from '../utils/logger'

export function registerCustomServerCommands(
    ctx: Context,
    customServerService: CustomServerService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:customserver')

    // ==================== 设置自定义服务器 ====================
    ctx.command('orproxy.customserver.set <machine:string> <serverAddress:string> [port:number] [description:text]', '配置自定义服务器')
        .userFields(['authority'])
        .action(async ({ session }, machine, serverAddress, port = 25565, description = '') => {
            if (!session || !session.user || session.user.authority < 10) {
                return '权限不足（需要10级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            try {
                await customServerService.setConfig(
                    userId,
                    platform,
                    machine,
                    serverAddress,
                    port,
                    description
                )

                logger.info(`用户 ${userId} 设置自定义服务器: ${machine} -> ${serverAddress}:${port}`)
                return `自定义服务器配置成功\n机器: ${machine}\n服务器: ${serverAddress}:${port}\n${description ? `描述: ${description}` : ''}`
            } catch (error: any) {
                logger.error('设置自定义服务器失败:', error)
                return `设置失败: ${error?.message || 'Unknown error'}`
            }
        })

    // ==================== 查看自定义服务器 ====================
    ctx.command('orproxy.customserver.get <machine:string>', '查看指定机器的自定义服务器配置')
        .userFields(['authority'])
        .action(async ({ session }, machine) => {
            if (!session || !session.user || session.user.authority < 10) {
                return '权限不足（需要10级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            try {
                const config = await customServerService.getConfig(userId, platform, machine)

                if (!config) {
                    return `机器 "${machine}" 没有自定义服务器配置`
                }

                return `自定义服务器配置：\n机器: ${config.machine_name}\n服务器: ${config.server_address}:${config.server_port}\n${config.description ? `描述: ${config.description}` : ''}\n创建时间: ${config.created_at.toLocaleString('zh-CN')}\n更新时间: ${config.updated_at.toLocaleString('zh-CN')}`
            } catch (error: any) {
                logger.error('查看自定义服务器失败:', error)
                return `查询失败: ${error?.message || 'Unknown error'}`
            }
        })

    // ==================== 列出所有自定义服务器 ====================
    ctx.command('orproxy.customserver.list', '列出自己所有的自定义服务器配置')
        .userFields(['authority'])
        .action(async ({ session }) => {
            if (!session || !session.user || session.user.authority < 10) {
                return '权限不足（需要10级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            try {
                const configs = await customServerService.listConfigs(userId, platform)

                if (configs.length === 0) {
                    return '您还没有配置任何自定义服务器'
                }

                const lines: string[] = ['您的自定义服务器配置：', '─'.repeat(50)]

                for (const config of configs) {
                    lines.push(`[${config.machine_name}]`)
                    lines.push(`  服务器: ${config.server_address}:${config.server_port}`)
                    if (config.description) {
                        lines.push(`  描述: ${config.description}`)
                    }
                    lines.push(`  更新时间: ${config.updated_at.toLocaleString('zh-CN')}`)
                    lines.push('')
                }

                lines.push(`共 ${configs.length} 个配置`)

                return lines.join('\n')
            } catch (error: any) {
                logger.error('列出自定义服务器失败:', error)
                return `查询失败: ${error?.message || 'Unknown error'}`
            }
        })

    // ==================== 删除自定义服务器配置 ====================
    ctx.command('orproxy.customserver.delete <machine:string>', '删除指定机器的自定义服务器配置')
        .userFields(['authority'])
        .action(async ({ session }, machine) => {
            if (!session || !session.user || session.user.authority < 10) {
                return '权限不足（需要10级权限）'
            }

            const userId = session.userId || 'unknown'
            const platform = session.platform || 'unknown'

            try {
                const success = await customServerService.deleteConfig(userId, platform, machine)

                if (success) {
                    logger.info(`用户 ${userId} 删除自定义服务器配置: ${machine}`)
                    return `已删除机器 "${machine}" 的自定义服务器配置`
                } else {
                    return `删除失败`
                }
            } catch (error: any) {
                logger.error('删除自定义服务器失败:', error)
                return `删除失败: ${error?.message || 'Unknown error'}`
            }
        })

    logger.info('自定义服务器指令已注册')
}

