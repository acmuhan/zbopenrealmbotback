/**
 * /list 指令实现
 * 列出所有机器的状态（仅查询IP和锁状态，快速响应）
 */

import { Context } from 'koishi'
import { MachineService } from '../services/machine'
import { Logger } from '../utils/logger'
import { MachineStatus } from '../models/database'

export function registerListCommand(
    ctx: Context,
    machineService: MachineService
) {
    const logger = new Logger(ctx, 'orproxy:cmd:list')

    ctx.command('orproxy.list', '查看所有服务器状态')
        .alias('list')
        .action(async ({ session }) => {
            if (!session) return
            logger.info(`用户 ${session.userId} (${session.platform}) 查询机器列表`)

            try {
                // 获取所有机器配置
                const machines = machineService.listMachines()

                if (machines.length === 0) {
                    return session.text('commands.orproxy.list.no-machines')
                }

                await session.send(session.text('commands.orproxy.list.loading'))

                // 并发查询所有机器状态（快速版本，仅查询IP和锁状态）
                const statuses = await getAllMachineStatusFast(
                    machineService,
                    logger
                )

                if (statuses.length === 0) {
                    return session.text('commands.orproxy.list.no-status')
                }

                // 格式化输出
                const lines: string[] = []
                lines.push(session.text('commands.orproxy.list.header'))
                lines.push('━'.repeat(50))

                for (const status of statuses) {
                    // 机器名称
                    lines.push(`[${status.machine_name}]`)

                    // 状态显示
                    if (status.current_ip) {
                        // 有IP = 被占用
                        lines.push(`   状态: ${session.text('commands.orproxy.list.occupied')}`)
                        if (status.is_locked && status.locked_by) {
                            lines.push(`   占用者: ${status.locked_by}`)
                        }
                    } else {
                        // 无IP = 在线待命
                        lines.push(`   状态: ${session.text('commands.orproxy.list.online-idle')}`)
                    }

                    lines.push('─'.repeat(50))
                }

                lines.push(`\n${session.text('commands.orproxy.list.total', [statuses.length])}`)

                return lines.join('\n')

            } catch (error: any) {
                logger.error('查询机器列表失败:', error)
                return session.text('commands.orproxy.list.failed')
            }
        })
}

/**
 * 并发查询所有机器状态（快速版本，仅查询IP和锁状态）
 */
async function getAllMachineStatusFast(
    machineService: MachineService,
    logger: Logger
): Promise<MachineStatus[]> {
    const machines = machineService.listMachines()

    // 并发查询所有机器状态（不查询zbproxy和minecraft）
    const statusPromises = machines.map(async (machine) => {
        try {
            // 使用快速模式，不查询详细信息
            const status = await machineService.getMachineStatus(machine.machine_name, false)

            // 如果查询失败，返回默认状态
            if (!status) {
                return {
                    machine_name: machine.machine_name,
                    is_locked: false
                }
            }

            return status
        } catch (error) {
            logger.error(`查询机器状态失败: ${machine.machine_name}`, error)
            return {
                machine_name: machine.machine_name,
                is_locked: false
            }
        }
    })

    const statuses = await Promise.all(statusPromises)
    return statuses
}

