# koishi-plugin-orproxy

[![npm](https://img.shields.io/npm/v/koishi-plugin-orproxy?style=flat-square)](https://www.npmjs.com/package/koishi-plugin-orproxy)

一个用于管理 DigitalOcean Reserved IP 和 ZBProxy 的 Koishi 插件，帮助您自动化 IP 切换以绕过服务器黑名单。

## 功能特性

- ✅ **自动 IP 管理** - 自动创建、分配和删除 DigitalOcean Reserved IP
- ✅ **黑名单管理** - 自动记录和清理过期的黑名单 IP（30天）
- ✅ **并发控制** - 防止多个用户同时操作同一台机器
- ✅ **事务回滚** - 操作失败时自动回滚所有变更
- ✅ **多平台支持** - 支持 Discord 和 Kook 平台
- ✅ **多语言支持** - 中文和英文界面
- ✅ **权限管理** - 基于 Koishi 内置权限系统
- ✅ **历史记录** - 完整的操作历史记录到数据库

## 安装

```bash
npm install koishi-plugin-orproxy
```

或在 Koishi 控制台的插件市场中搜索 `orproxy` 并安装。

## 前置要求

1. **DigitalOcean 账号** - 需要有效的 API Token
2. **Droplet 实例** - 已创建的 Droplet 实例
3. **ZBProxy 服务** - 在 Droplet 上运行的 ZBProxy API
4. **MySQL 数据库** - 用于存储历史记录和锁信息

## 配置

### 1. 配置 koishi.yml

```yaml
plugins:
  # 数据库配置
  database-mysql:
    host: localhost
    port: 3306
    user: root
    password: your_password
    database: koishi
  
  # Discord 适配器
  adapter-discord:
    token: your_discord_bot_token
  
  # Kook 适配器
  adapter-kook:
    token: your_kook_bot_token
  
  # orproxy 插件
  orproxy:
    machineConfigPath: ./config/machines.json
    blacklistPath: ./config/blackip.json
    digapiConfigPath: ./digapi/config/accounts.json
    defaultTimeout: 60000
    autoCleanBlacklist: true
    cleanInterval: 3600000
```

### 2. 配置机器信息 (config/machines.json)

```json
{
  "machines": [
    {
      "machine_name": "hyp-openrealm-us4",
      "droplet_id": 123456789,
      "account_name": "production",
      "region": "nyc3",
      "zbproxy_port": 8000
    },
    {
      "machine_name": "hyp-openrealm-sg",
      "droplet_id": 987654321,
      "account_name": "production",
      "region": "sgp1",
      "zbproxy_port": 8000
    }
  ]
}
```

### 3. 配置 DigitalOcean API (digapi/config/accounts.json)

```json
{
  "accounts": {
    "production": {
      "token": "your_digitalocean_api_token"
    }
  }
}
```

## 使用指南

### 指令列表

| 指令 | 权限 | 说明 |
|------|------|------|
| `orproxy.start <machine>` | 管理员 | 启动机器并分配新 IP |
| `orproxy.stop <machine>` | 管理员 | 停止机器并拉黑当前 IP |
| `orproxy.list` | 所有用户 | 列出所有机器状态 |

### 使用示例

#### 启动机器

```
orproxy.start hyp-openrealm-us4
```

插件会自动：
1. 检查当前 IP 是否在黑名单中
2. 如果在黑名单，删除并创建新 IP
3. 将 IP 分配到 Droplet
4. 重启 ZBProxy 服务

#### 停止机器

```
orproxy.stop hyp-openrealm-us4
```

插件会自动：
1. 停止 ZBProxy 服务
2. 将当前 IP 加入黑名单（30天过期）
3. 解绑 IP

#### 查看机器列表

```
orproxy.list
```

显示所有机器的：
- 当前 IP 地址
- ZBProxy 运行状态
- 锁定状态
- Droplet 信息

## 工作流程

### /start 指令流程

```
用户发送指令
  ↓
验证权限和机器配置
  ↓
获取机器锁（防并发）
  ↓
获取当前 IP
  ↓
检查 IP 是否在黑名单？
  ├─ 是 → 删除旧 IP
  └─ 否 → 保持当前 IP
  ↓
创建新 IP（如需要）
  ↓
分配 IP 到 Droplet
  ↓
重启 ZBProxy
  ↓
记录历史 + 释放锁
  ↓
返回成功结果
```

### /stop 指令流程

```
用户发送指令
  ↓
验证权限和机器配置
  ↓
获取机器锁
  ↓
获取当前 IP
  ↓
停止 ZBProxy
  ↓
添加 IP 到黑名单
  ↓
解绑 IP
  ↓
记录历史 + 释放锁
  ↓
返回成功结果
```

## 错误处理

插件使用事务机制，任何步骤失败都会自动回滚：

- **创建 IP 失败** - 无需回滚
- **分配 IP 失败** - 删除新创建的 IP
- **ZBProxy 重启失败** - 解绑新 IP，恢复旧 IP
- **网络错误** - 回滚所有操作

## 安全特性

1. **权限控制** - `/start` 和 `/stop` 需要管理员权限（level 3+）
2. **机器锁** - 同一时间只有一个用户可以操作一台机器
3. **超时保护** - 机器锁 5 分钟自动超时
4. **操作记录** - 所有操作都记录到数据库，包含用户ID和平台

## 高级功能

### 强制执行

使用 `-f` 选项跳过锁检查（谨慎使用）：

```
orproxy.start hyp-openrealm-us4 -f
```

### 黑名单管理

- 自动清理：每小时自动清理过期的黑名单记录
- 过期时间：默认 30 天
- 文件位置：`config/blackip.json`

### 数据库表

**orproxy_ip_history** - IP 切换历史
- 记录每次 IP 切换操作
- 包含用户、时间、状态信息

**orproxy_machine_locks** - 机器锁
- 记录当前被锁定的机器
- 自动清理超时锁

## 故障排查

### 插件无法启动

1. 检查 MySQL 数据库连接
2. 检查 DigitalOcean API Token
3. 检查 machines.json 配置格式

### IP 创建失败

1. 检查 DigitalOcean 账户余额
2. 检查区域是否支持 Reserved IP
3. 检查 API 速率限制

### ZBProxy 重启失败

1. 检查 ZBProxy API 是否可访问
2. 检查 Droplet 是否在运行
3. 检查防火墙设置

## 开发

```bash
# 克隆项目
git clone https://github.com/your-repo/koishi-plugin-orproxy.git

# 安装依赖
cd koishi-plugin-orproxy
npm install

# 构建
npm run build

# 开发模式（自动重新编译）
npm run dev
```

## 许可证

MIT License

## 支持

如有问题或建议，请提交 Issue 或 Pull Request。

---

**相关链接**

- [Koishi 官方文档](https://koishi.chat/)
- [DigitalOcean API 文档](https://docs.digitalocean.com/reference/api/)
- [ZBProxy 项目](https://github.com/layou233/zbproxy)

