# orproxy 插件部署指南

本文档提供 koishi-plugin-orproxy 的详细部署步骤。

## 前置准备

### 1. 安装 Koishi

```bash
# 如果还没有安装 Koishi
npm install -g koishi
```

### 2. 准备 MySQL 数据库

确保你有一个可访问的 MySQL 数据库实例。

### 3. 准备 DigitalOcean 账号

- 获取 DigitalOcean API Token
- 创建至少一个 Droplet 实例
- 确保 Droplet 上运行着 ZBProxy API

## 快速开始

### 步骤 1: 安装插件

在你的 Koishi 项目目录中：

```bash
cd path/to/your/koishi/project
npm install koishi-plugin-orproxy
```

或者，如果你要使用本地开发版本：

```bash
# 在插件目录中
cd koishi-plugin-orproxy
npm run build
  

# 在 Koishi 项目目录中
npm link koishi-plugin-orproxy
```

### 步骤 2: 配置数据库插件

编辑 `koishi.yml`：

```yaml
plugins:
  database-mysql:
    host: localhost
    port: 3306
    user: root
    password: your_mysql_password
    database: koishi
```

### 步骤 3: 配置适配器

#### Discord

```yaml
plugins:
  adapter-discord:
    token: your_discord_bot_token
```

获取 Discord Bot Token：
1. 访问 [Discord Developer Portal](https://discord.com/developers/applications)
2. 创建新应用程序
3. 在 Bot 标签页创建 Bot
4. 复制 Token

#### Kook

```yaml
plugins:
  adapter-kook:
    token: your_kook_bot_token
```

获取 Kook Bot Token：
1. 访问 [Kook 开发者中心](https://developer.kookapp.cn/)
2. 创建机器人应用
3. 获取 Token

### 步骤 4: 配置 DigitalOcean API

创建 `digapi/config/accounts.json`：

```json
{
  "accounts": {
    "production": {
      "token": "your_digitalocean_api_token"
    }
  }
}
```

获取 DigitalOcean API Token：
1. 访问 [DigitalOcean API Tokens](https://cloud.digitalocean.com/account/api/tokens)
2. 点击 "Generate New Token"
3. 设置读写权限
4. 复制 Token

### 步骤 5: 配置机器信息

创建 `config/machines.json`：

```json
{
  "machines": [
    {
      "machine_name": "us-server",
      "droplet_id": 123456789,
      "account_name": "production",
      "region": "nyc3",
      "zbproxy_port": 8000
    }
  ]
}
```

获取 Droplet ID：
```bash
# 使用 DigitalOcean API
curl -X GET \
  -H "Authorization: Bearer YOUR_TOKEN" \
  "https://api.digitalocean.com/v2/droplets"
```

### 步骤 6: 配置插件

在 `koishi.yml` 中添加：

```yaml
plugins:
  orproxy:
    machineConfigPath: ./config/machines.json
    blacklistPath: ./config/blackip.json
    digapiConfigPath: ./digapi/config/accounts.json
    defaultTimeout: 60000
    autoCleanBlacklist: true
    cleanInterval: 3600000
```

### 步骤 7: 初始化数据库表

启动 Koishi 后，插件会自动创建数据库表：
- `orproxy_ip_history` - IP 切换历史
- `orproxy_machine_locks` - 机器锁

### 步骤 8: 设置权限

在 Koishi 控制台中，为管理员用户设置权限等级：

```
# 在任意聊天平台发送（需要控制台权限）
user.authority @用户 3
```

## 测试部署

### 1. 测试 /list 指令

```
orproxy.list
```

应该显示所有配置的机器状态。

### 2. 测试 /start 指令

```
orproxy.start us-server
```

观察输出，确保：
- 成功创建或分配 IP
- ZBProxy 重启成功
- 返回成功消息

### 3. 测试 /stop 指令

```
orproxy.stop us-server
```

确保：
- IP 被添加到黑名单
- IP 被解绑
- ZBProxy 停止

## 故障排查

### 数据库连接失败

**症状**: 插件启动时报错 "数据库连接失败"

**解决方案**:
1. 检查 MySQL 是否运行
2. 验证 `koishi.yml` 中的数据库配置
3. 确保数据库用户有足够权限

### DigitalOcean API 调用失败

**症状**: /start 或 /stop 指令返回 API 错误

**解决方案**:
1. 验证 API Token 是否有效
2. 检查账户是否有足够余额
3. 确认 Droplet ID 正确
4. 检查 API 速率限制

### ZBProxy 连接失败

**症状**: 指令执行时报告 "ZBProxy API 不可达"

**解决方案**:
1. 确认 Droplet 正在运行
2. 检查 ZBProxy API 服务是否启动
3. 验证防火墙规则允许端口访问
4. 确认 zbproxy_port 配置正确

### 机器被锁定

**症状**: 指令返回 "机器正在被其他用户使用"

**解决方案**:
1. 等待 5 分钟（锁自动超时）
2. 或使用强制选项：`orproxy.start us-server -f`

### 黑名单 IP 问题

**症状**: IP 一直被识别为黑名单

**解决方案**:
1. 检查 `config/blackip.json` 文件
2. 确认 expire_time 是否已过期
3. 手动编辑文件删除过期记录
4. 等待自动清理（每小时）

## 生产环境建议

### 1. 安全配置

- 使用环境变量存储敏感信息
- 限制数据库用户权限
- 使用 HTTPS 访问 ZBProxy API
- 定期轮换 API Token

### 2. 备份策略

```bash
# 备份数据库
mysqldump -u root -p koishi > koishi_backup.sql

# 备份配置文件
tar -czf config_backup.tar.gz config/ digapi/config/
```

### 3. 监控和日志

- 启用 Koishi 日志记录
- 监控数据库表大小
- 设置告警（API 失败、锁超时等）

### 4. 性能优化

- 定期清理历史记录：
```sql
DELETE FROM orproxy_ip_history 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
```

- 为常用查询添加索引：
```sql
CREATE INDEX idx_machine_name ON orproxy_ip_history(machine_name);
CREATE INDEX idx_created_at ON orproxy_ip_history(created_at);
```

### 5. 高可用部署

- 使用主从 MySQL 数据库
- 部署多个 Koishi 实例（共享数据库）
- 配置负载均衡

## 更新和维护

### 更新插件

```bash
npm update koishi-plugin-orproxy
# 或
npm install koishi-plugin-orproxy@latest
```

### 查看日志

Koishi 日志位置：
- 控制台输出
- `data/logs/` 目录（如果配置）

### 清理黑名单

手动清理过期记录：
```bash
# 编辑 blackip.json，删除过期条目
# 或者重启插件，自动清理
```

## 常见问题

**Q: 插件支持多少台机器？**
A: 理论上无限制，取决于数据库性能和网络延迟。

**Q: 可以同时操作多台机器吗？**
A: 可以，但每台机器同时只能被一个用户操作。

**Q: IP 切换需要多长时间？**
A: 通常 30-60 秒，包括创建、分配和重启服务。

**Q: 黑名单可以手动管理吗？**
A: 可以，直接编辑 `config/blackip.json` 文件。

**Q: 支持其他聊天平台吗？**
A: 理论上支持所有 Koishi 适配器，但需要安装相应插件。

## 技术支持

- GitHub Issues: [项目地址]
- Koishi 官方文档: https://koishi.chat/
- DigitalOcean 文档: https://docs.digitalocean.com/

---

**最后更新**: 2025-10-21

