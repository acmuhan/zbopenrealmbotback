/**
 * 用户封禁服务
 * 管理用户的封禁状态（滥用自动停机等）
 */
import { Context } from 'koishi';
import { UserBan } from '../models/database';
export declare class BanService {
    private ctx;
    private logger;
    constructor(ctx: Context);
    /**
     * 检查用户是否被封禁
     */
    isUserBanned(userId: string, platform: string): Promise<UserBan | null>;
    /**
     * 封禁用户
     */
    banUser(userId: string, platform: string, reason: string, durationHours: number, bannedBy: string): Promise<void>;
    /**
     * 解封用户
     */
    unbanUser(userId: string, platform: string): Promise<void>;
    /**
     * 清理过期的封禁记录
     */
    cleanExpiredBans(): Promise<void>;
    /**
     * 获取所有封禁列表
     */
    getBanList(): Promise<UserBan[]>;
}
//# sourceMappingURL=ban.d.ts.map