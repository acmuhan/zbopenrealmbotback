/**
 * 机器锁管理服务
 * 防止多个用户同时操作同一台机器
 */
import { Context } from 'koishi';
export interface LockInfo {
    userId: string;
    platform: string;
    timestamp: number;
}
export declare class MachineLockService {
    private ctx;
    private locks;
    private logger;
    private lockTimeout;
    constructor(ctx: Context);
    /**
     * 尝试获取机器锁
     */
    acquire(machineName: string, userId: string, platform: string): Promise<boolean>;
    /**
     * 释放机器锁
     */
    release(machineName: string): Promise<void>;
    /**
     * 检查机器是否被锁定
     */
    isLocked(machineName: string): Promise<boolean>;
    /**
     * 获取锁信息
     */
    getLockInfo(machineName: string): Promise<LockInfo | null>;
    /**
     * 清理超时锁
     */
    private cleanTimeoutLocks;
    /**
     * 强制释放所有锁（谨慎使用）
     */
    releaseAll(): Promise<void>;
    /**
     * 获取所有锁信息
     */
    getAllLocks(): Promise<Map<string, LockInfo>>;
}
//# sourceMappingURL=lock.d.ts.map