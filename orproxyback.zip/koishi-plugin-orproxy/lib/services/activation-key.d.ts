import { Context } from 'koishi';
import { ActivationKey } from '../models/database';
/**
 * 卡密管理服务
 */
export declare class ActivationKeyService {
    private ctx;
    private logger;
    constructor(ctx: Context);
    /**
     * 生成唯一的卡密代码
     * 格式: XXXX-XXXX-XXXX (12位字符 + 2个连字符)
     * 排除易混淆字符: 0O, 1Il, Z2, 5S, 8B
     */
    private generateKeyCode;
    /**
     * 生成唯一卡密（检查重复）
     * @param maxRetries 最大重试次数
     */
    generateKey(maxRetries?: number): Promise<string>;
    /**
     * 批量创建卡密
     * @param level 权限等级（2或10）
     * @param days 有效天数
     * @param count 生成数量
     * @param note 备注
     * @param createdBy 生成者用户ID
     */
    createKeys(level: number, days: number, count: number, note: string | undefined, createdBy: string): Promise<ActivationKey[]>;
    /**
     * 兑换卡密
     * @param keyCode 卡密代码
     * @param userId 用户ID
     * @param platform 平台
     */
    redeemKey(keyCode: string, userId: string, platform: string): Promise<{
        key: ActivationKey;
        permissionLevel: number;
        expiresAt: Date;
        isNewGrant: boolean;
    }>;
    /**
     * 查询卡密列表
     * @param status 状态筛选（'all' | 'unused' | 'used'）
     */
    listKeys(status?: 'all' | 'unused' | 'used'): Promise<ActivationKey[]>;
    /**
     * 删除卡密（仅限未使用的）
     * @param keyCode 卡密代码
     */
    deleteKey(keyCode: string): Promise<void>;
    /**
     * 验证卡密是否有效
     * @param keyCode 卡密代码
     */
    validateKey(keyCode: string): Promise<boolean>;
}
//# sourceMappingURL=activation-key.d.ts.map