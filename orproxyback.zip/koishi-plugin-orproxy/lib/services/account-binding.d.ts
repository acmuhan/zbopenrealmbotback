/**
 * 跨平台账户绑定服务
 */
import { Context } from 'koishi';
export declare class AccountBindingService {
    private ctx;
    private logger;
    constructor(ctx: Context);
    /**
     * 获取用户的统一标识（包括所有绑定的账户）
     */
    getUnifiedUserId(userId: string, platform: string): Promise<string>;
    /**
     * 检查用户当前运行的机器数量（跨平台）
     */
    getUserRunningMachineCount(userId: string, platform: string): Promise<number>;
}
//# sourceMappingURL=account-binding.d.ts.map