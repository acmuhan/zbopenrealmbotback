/**
 * 自定义服务器配置服务
 */
import { Context } from 'koishi';
import { CustomServerConfig } from '../models/database';
export declare class CustomServerService {
    private ctx;
    private logger;
    constructor(ctx: Context);
    /**
     * 设置自定义服务器配置
     */
    setConfig(userId: string, platform: string, machineName: string, serverAddress: string, serverPort?: number, description?: string): Promise<void>;
    /**
     * 获取自定义服务器配置
     */
    getConfig(userId: string, platform: string, machineName: string): Promise<CustomServerConfig | null>;
    /**
     * 列出用户所有自定义服务器配置
     */
    listConfigs(userId: string, platform: string): Promise<CustomServerConfig[]>;
    /**
     * 删除自定义服务器配置
     */
    deleteConfig(userId: string, platform: string, machineName: string): Promise<boolean>;
}
//# sourceMappingURL=custom-server.d.ts.map