import { Context } from 'koishi';
import { UserPermission } from '../models/database';
/**
 * 权限管理服务
 */
export declare class PermissionService {
    private ctx;
    private logger;
    constructor(ctx: Context);
    /**
     * 授予用户权限
     * @param userId 用户ID
     * @param platform 平台
     * @param level 权限等级
     * @param days 有效天数
     * @param keyCode 使用的卡密（可选）
     */
    grantPermission(userId: string, platform: string, level: number, days: number, keyCode?: string): Promise<UserPermission>;
    /**
     * 获取用户权限信息
     * @param userId 用户ID
     * @param platform 平台
     */
    getUserPermission(userId: string, platform: string): Promise<UserPermission | null>;
    /**
     * 检查用户权限是否过期
     * @param userId 用户ID
     * @param platform 平台
     * @returns true 如果已过期并已降级
     */
    checkExpired(userId: string, platform: string): Promise<boolean>;
    /**
     * 清理所有过期权限（定时任务）
     */
    cleanExpiredPermissions(): Promise<number>;
    /**
     * 延长权限时长
     * @param userId 用户ID
     * @param platform 平台
     * @param days 延长天数
     */
    extendPermission(userId: string, platform: string, days: number): Promise<UserPermission>;
    /**
     * 升级权限等级
     * @param userId 用户ID
     * @param platform 平台
     * @param newLevel 新权限等级
     * @param days 有效天数
     */
    upgradePermission(userId: string, platform: string, newLevel: number, days: number): Promise<UserPermission>;
    /**
     * 同步 Koishi 用户权限等级
     * @param userId 用户ID
     * @param platform 平台
     * @param level 权限等级
     */
    private syncUserAuthority;
}
//# sourceMappingURL=permission.d.ts.map