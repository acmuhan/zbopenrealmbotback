/**
 * Minecraft 服务器监控服务
 * 自动监控玩家数量，无人时自动停机
 */
import { Context } from 'koishi';
import { MinecraftService } from './minecraft';
import { MachineService } from './machine';
import { MachineLockService } from './lock';
export interface MonitorConfig {
    enabled: boolean;
    checkInterval: number;
    autoStopMinutes: number;
    maxFailures: number;
}
interface MonitorState {
    emptyStartTime: number | null;
    failureCount: number;
    lastCheckTime: number;
}
export declare class MonitorService {
    private ctx;
    private config;
    private minecraftService;
    private machineService;
    private lockService;
    private logger;
    private monitorStates;
    private monitorInterval;
    constructor(ctx: Context, config: MonitorConfig, minecraftService: MinecraftService, machineService: MachineService, lockService: MachineLockService);
    /**
     * 启动监控
     */
    start(): void;
    /**
     * 停止监控
     */
    stop(): void;
    /**
     * 检查所有机器
     */
    private checkAllMachines;
    /**
     * 检查单个机器
     */
    private checkMachine;
    /**
     * 自动停机
     */
    private autoStopMachine;
    /**
     * 获取监控状态
     */
    getMonitorState(machineName: string): MonitorState | null;
    /**
     * 获取所有监控状态
     */
    getAllMonitorStates(): Map<string, MonitorState>;
}
export {};
//# sourceMappingURL=monitor.d.ts.map