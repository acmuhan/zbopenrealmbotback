/**
 * 维护模式服务
 * 管理机器的维护状态
 */
import { Context } from 'koishi';
import { MachineService } from './machine';
export declare class MaintenanceService {
    private ctx;
    private machineService;
    private logger;
    constructor(ctx: Context, machineService: MachineService);
    /**
     * 检查机器是否处于维护模式
     */
    isInMaintenance(machineName: string): {
        inMaintenance: boolean;
        reason?: string;
    };
    /**
     * 设置维护模式
     */
    setMaintenance(machineName: string, enabled: boolean, reason?: string): void;
    /**
     * 检查用户是否可以绕过维护模式
     */
    canBypassMaintenance(userAuthority: number): boolean;
}
//# sourceMappingURL=maintenance.d.ts.map