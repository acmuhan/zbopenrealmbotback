/**
 * 机器管理服务
 * 管理 Droplet 机器配置和状态
 */
import { Context } from 'koishi';
import { MachineConfig, MachineStatus } from '../models/database';
import { DigitalOceanService } from './digitalocean';
import { ZBProxyService } from './zbproxy';
export declare class MachineService {
    private ctx;
    private doService;
    private zbproxyService;
    private machines;
    private logger;
    private filePath;
    constructor(ctx: Context, configPath: string, doService: DigitalOceanService, zbproxyService: ZBProxyService);
    /**
     * 从文件加载机器配置
     */
    load(): void;
    /**
     * 保存机器配置到文件
     */
    save(): void;
    /**
     * 获取机器配置
     */
    getMachine(machineName: string): MachineConfig | undefined;
    /**
     * 列出所有机器
     */
    listMachines(): MachineConfig[];
    /**
     * 验证机器名称是否存在
     */
    validateMachine(machineName: string): boolean;
    /**
     * 添加机器配置
     */
    addMachine(machine: MachineConfig): void;
    /**
     * 删除机器配置
     */
    removeMachine(machineName: string): boolean;
    /**
     * 更新机器配置
     */
    updateMachine(machineName: string, updates: Partial<MachineConfig>): boolean;
    /**
     * 获取机器状态（快速版本，仅查询 IP 和锁状态）
     */
    getMachineStatus(machineName: string, includeDetails?: boolean): Promise<MachineStatus | null>;
    /**
     * 批量获取所有机器状态
     */
    getAllMachineStatus(): Promise<MachineStatus[]>;
    /**
     * 根据 Droplet ID 查找机器
     */
    findByDropletId(dropletId: number): MachineConfig | undefined;
    /**
     * 获取机器数量
     */
    getCount(): number;
}
//# sourceMappingURL=machine.d.ts.map