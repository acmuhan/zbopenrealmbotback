/**
 * ZBProxy 服务
 * 通过 HTTP API 控制 ZBProxy 进程
 */
import { Context } from 'koishi';
export declare class ZBProxyService {
    private ctx;
    private logger;
    private defaultTimeout;
    constructor(ctx: Context, timeout?: number);
    /**
     * 创建 axios 客户端
     */
    private createClient;
    /**
     * 启动 ZBProxy
     */
    start(ip: string, port: number): Promise<void>;
    /**
     * 停止 ZBProxy
     */
    stop(ip: string, port: number): Promise<void>;
    /**
     * 重启 ZBProxy
     */
    restart(ip: string, port: number): Promise<void>;
    /**
     * 获取 ZBProxy 状态
     */
    getStatus(ip: string, port: number): Promise<{
        status: 'running' | 'stopped' | 'unknown';
    }>;
    /**
     * 获取 ZBProxy 配置
     */
    getConfig(ip: string, port: number): Promise<any>;
    /**
     * 更新 ZBProxy 配置
     */
    updateConfig(ip: string, port: number, config: any): Promise<void>;
    /**
     * 更新自定义 Minecraft 服务器配置
     * 通过添加新的出站配置来更新目标服务器
     */
    updateMinecraftServer(ip: string, port: number, serverAddress: string, serverPort: number, outboundName?: string): Promise<void>;
    /**
     * 检查 ZBProxy API 是否可达（快速检查）
     */
    isReachable(ip: string, port: number): Promise<boolean>;
    /**
     * 配置 Linux IP 路由（dolinuxip）
     * @param ip 服务器IP
     * @param port API端口
     * @param reservedIP Reserved IP地址
     * @param maxRetries 最大重试次数
     */
    configureLinuxIP(ip: string, port: number, reservedIP: string, maxRetries?: number): Promise<void>;
    /**
     * 智能停止 ZBProxy（带重试）
     * @param ip 服务器IP
     * @param port API端口
     * @param maxRetries 最大重试次数
     */
    stopWithRetry(ip: string, port: number, maxRetries?: number): Promise<void>;
    /**
     * 智能重启 ZBProxy（带自适应重试）
     * @param ip 服务器IP
     * @param port API端口
     * @param maxRetries 最大重试次数
     */
    restartWithRetry(ip: string, port: number, maxRetries?: number): Promise<void>;
}
//# sourceMappingURL=zbproxy.d.ts.map