/**
 * Minecraft 服务器查询服务
 * 通过 Server List Ping 协议查询服务器状态
 */
import { Context } from 'koishi';
export interface MinecraftServerStatus {
    online: boolean;
    players?: {
        online: number;
        max: number;
    };
    version?: {
        name: string;
        protocol: number;
    };
    description?: string;
    favicon?: string;
}
export declare class MinecraftService {
    private ctx;
    private logger;
    constructor(ctx: Context);
    /**
     * 查询 Minecraft 服务器状态
     * @param host 服务器地址
     * @param port 服务器端口（默认25565）
     * @param timeout 超时时间（毫秒）
     */
    queryServer(host: string, port?: number, timeout?: number): Promise<MinecraftServerStatus>;
    /**
     * 安全查询（带重试）
     */
    queryServerSafe(host: string, port?: number, maxRetries?: number): Promise<MinecraftServerStatus>;
    /**
     * 创建握手数据包
     */
    private createHandshakePacket;
    /**
     * 创建请求数据包
     */
    private createRequestPacket;
    /**
     * 写入 VarInt
     */
    private writeVarInt;
    /**
     * 读取 VarInt
     */
    private readVarInt;
}
//# sourceMappingURL=minecraft.d.ts.map