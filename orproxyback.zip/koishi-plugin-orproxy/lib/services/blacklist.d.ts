/**
 * 黑名单管理服务
 * 管理被拉黑的 IP 地址，支持自动过期清理
 */
import { Context } from 'koishi';
import { BlacklistEntry } from '../models/database';
export declare class BlacklistService {
    private ctx;
    private autoClean;
    private cleanInterval;
    private blacklist;
    private logger;
    private filePath;
    private cleanTimer?;
    constructor(ctx: Context, configPath: string, autoClean?: boolean, cleanInterval?: number);
    /**
     * 从文件加载黑名单
     */
    load(): void;
    /**
     * 保存黑名单到文件
     */
    save(): void;
    /**
     * 添加 IP 到黑名单
     */
    add(ip: string, machineName: string, userId: string, adapterType: string, reason?: string, expireDays?: number): Promise<void>;
    /**
     * 从黑名单移除 IP
     */
    remove(ip: string): Promise<boolean>;
    /**
     * 检查 IP 是否在黑名单中（且未过期）
     */
    isBlacklisted(ip: string): boolean;
    /**
     * 获取黑名单条目详情
     */
    getEntry(ip: string): BlacklistEntry | undefined;
    /**
     * 获取所有黑名单（包括过期的）
     */
    getAll(): BlacklistEntry[];
    /**
     * 获取有效的黑名单（未过期）
     */
    getActive(): BlacklistEntry[];
    /**
     * 获取过期的黑名单
     */
    getExpired(): BlacklistEntry[];
    /**
     * 清理过期的黑名单记录
     */
    cleanExpired(): number;
    /**
     * 启动自动清理定时器
     */
    private startAutoClean;
    /**
     * 停止自动清理
     */
    stopAutoClean(): void;
    /**
     * 获取统计信息
     */
    getStats(): {
        total: number;
        active: number;
        expired: number;
    };
    /**
     * 销毁服务
     */
    dispose(): void;
}
//# sourceMappingURL=blacklist.d.ts.map