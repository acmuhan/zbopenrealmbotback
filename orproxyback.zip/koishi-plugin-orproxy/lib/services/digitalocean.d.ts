/**
 * DigitalOcean 服务
 * 封装 digapi SDK，提供 Reserved IP 操作
 */
import { Context } from 'koishi';
export declare class DigitalOceanService {
    private ctx;
    private sdk;
    private logger;
    constructor(ctx: Context, configPath: string);
    /**
     * 创建 Reserved IP
     */
    createIP(region: string, accountName?: string): Promise<{
        ip: string;
        data: any;
    }>;
    /**
     * 删除 Reserved IP（容错：如果不存在则跳过）
     */
    deleteIP(ip: string, accountName?: string): Promise<void>;
    /**
     * 分配 Reserved IP 到 Droplet（异步操作，需后续验证）
     */
    assignIP(ip: string, dropletId: number, accountName?: string): Promise<void>;
    /**
     * 解绑 Reserved IP（容错：如果未分配则跳过）
     */
    unassignIP(ip: string, accountName?: string): Promise<void>;
    /**
     * 获取 Droplet 的 Reserved IP（只返回浮动IP，不返回主IP）
     * 返回 null 表示机器没有 Reserved IP（未启动状态）
     */
    getReservedIP(dropletId: number, accountName?: string): Promise<string | null>;
    /**
     * 获取 Droplet 当前的 IP（优先 Reserved IP，其次主 IP）
     */
    getDropletIP(dropletId: number, accountName?: string): Promise<string | null>;
    /**
     * 获取 Droplet 的主 IP（公网 IP，不包括 Reserved IP）
     */
    getDropletMainIP(dropletId: number, accountName?: string): Promise<string | null>;
    /**
     * 获取 Droplet 信息
     */
    getDroplet(dropletId: number, accountName?: string): Promise<any>;
    /**
     * 列出所有 Reserved IPs
     */
    listReservedIPs(): Promise<any[]>;
    /**
     * 使用指定账号
     */
    useAccount(accountName: string): any;
}
//# sourceMappingURL=digitalocean.d.ts.map