import { Context } from 'koishi';
import { PermissionService } from '../services/permission';
/**
 * 权限检查中间件
 * 在每个命令执行前自动检查用户权限是否过期
 */
export declare function registerPermissionCheckMiddleware(ctx: Context, permissionService: PermissionService): void;
//# sourceMappingURL=permission-check.d.ts.map