/**
 * 数据库模型定义
 * 符合 Koishi ORM 规范
 */
/**
 * IP 切换历史记录
 */
export interface IPHistory {
    id: number;
    machine_name: string;
    old_ip?: string;
    new_ip: string;
    action: 'start' | 'stop' | 'switch';
    user_id: string;
    adapter_type: string;
    status: 'success' | 'failed' | 'rolled_back';
    error_message?: string;
    created_at: Date;
}
/**
 * 机器锁记录（防止并发操作）
 */
export interface MachineLock {
    machine_name: string;
    user_id: string;
    adapter_type: string;
    locked_at: Date;
}
/**
 * 黑名单 IP 条目
 */
export interface BlacklistEntry {
    ip_address: string;
    machine_name: string;
    user_id: string;
    adapter_type: string;
    reason: string;
    blacklist_time: string;
    expire_time: string;
}
/**
 * 机器配置信息
 */
export interface MachineConfig {
    machine_name: string;
    droplet_id: number;
    account_name: string;
    region: string;
    zbproxy_port: number;
    mc_server_port?: number;
    mc_server_ip?: string;
    enable_monitoring?: boolean;
    maintenance_mode?: boolean;
    maintenance_reason?: string;
}
/**
 * 机器状态信息
 */
export interface MachineStatus {
    machine_name: string;
    current_ip?: string;
    zbproxy_status?: 'running' | 'stopped' | 'unknown';
    is_locked: boolean;
    locked_by?: string;
    last_update?: Date;
    mc_online?: boolean;
    mc_players_online?: number;
    mc_players_max?: number;
}
/**
 * 用户封禁记录
 */
export interface UserBan {
    id: number;
    user_id: string;
    platform: string;
    reason: string;
    banned_at: Date;
    banned_until: Date;
    banned_by: string;
}
/**
 * 用户自定义服务器配置
 */
export interface CustomServerConfig {
    id: number;
    user_id: string;
    platform: string;
    machine_name: string;
    server_address: string;
    server_port: number;
    description: string;
    created_at: Date;
    updated_at: Date;
}
/**
 * 激活卡密记录
 */
export interface ActivationKey {
    id: number;
    key_code: string;
    permission_level: number;
    duration_days: number;
    status: 'unused' | 'used';
    note?: string;
    created_at: Date;
    created_by: string;
    used_at?: Date;
    used_by?: string;
    used_platform?: string;
}
/**
 * 用户权限记录
 */
export interface UserPermission {
    id: number;
    user_id: string;
    platform: string;
    permission_level: number;
    granted_at: Date;
    expires_at: Date;
    last_key_used?: string;
}
/**
 * Koishi 数据库表扩展声明
 */
declare module 'koishi' {
    interface Tables {
        orproxy_ip_history: IPHistory;
        orproxy_machine_locks: MachineLock;
        orproxy_user_bans: UserBan;
        orproxy_custom_servers: CustomServerConfig;
        orproxy_activation_keys: ActivationKey;
        orproxy_user_permissions: UserPermission;
    }
}
//# sourceMappingURL=database.d.ts.map