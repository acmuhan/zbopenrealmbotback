/**
 * Koishi Plugin: orproxy
 * 管理 DigitalOcean Reserved IP 和 ZBProxy
 */
import { Context, Schema } from 'koishi';
export declare const name = "orproxy";
export declare const inject: string[];
export declare const locales: {
    'zh-CN': any;
    'en-US': any;
};
/**
 * 插件配置接口
 */
export interface Config {
    machineConfigPath: string;
    blacklistPath: string;
    digapiConfigPath: string;
    defaultTimeout: number;
    autoCleanBlacklist: boolean;
    cleanInterval: number;
    enableMonitoring: boolean;
    monitorCheckInterval: number;
    monitorAutoStopMinutes: number;
    monitorMaxFailures: number;
}
/**
 * 插件配置 Schema
 */
export declare const Config: Schema<Config>;
/**
 * 插件主函数
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map