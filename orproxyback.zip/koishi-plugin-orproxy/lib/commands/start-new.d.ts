/**
 * /start 指令实现（完整版）
 * 包含：封禁检查、维护模式、并发执行、智能重试、IP切换、MOTD监控、私信发送
 */
import { Context } from 'koishi';
import { DigitalOceanService } from '../services/digitalocean';
import { ZBProxyService } from '../services/zbproxy';
import { BlacklistService } from '../services/blacklist';
import { MachineService } from '../services/machine';
import { MachineLockService } from '../services/lock';
import { BanService } from '../services/ban';
import { MaintenanceService } from '../services/maintenance';
import { MonitorService } from '../services/monitor';
export declare function registerStartCommand(ctx: Context, doService: DigitalOceanService, zbproxyService: ZBProxyService, blacklistService: BlacklistService, machineService: MachineService, lockService: MachineLockService, banService: BanService, maintenanceService: MaintenanceService, monitorService: MonitorService): void;
//# sourceMappingURL=start-new.d.ts.map