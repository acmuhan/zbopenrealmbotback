import { Context } from 'koishi';
import { AccountBindingService } from '../services/account-binding';
/**
 * 注册账号绑定相关命令
 */
export declare function registerBindCommands(ctx: Context, bindingService: AccountBindingService): void;
//# sourceMappingURL=bind.d.ts.map