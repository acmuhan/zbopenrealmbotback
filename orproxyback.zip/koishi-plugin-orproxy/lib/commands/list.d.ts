/**
 * /list 指令实现
 * 列出所有机器的状态（仅查询IP和锁状态，快速响应）
 */
import { Context } from 'koishi';
import { MachineService } from '../services/machine';
export declare function registerListCommand(ctx: Context, machineService: MachineService): void;
//# sourceMappingURL=list.d.ts.map