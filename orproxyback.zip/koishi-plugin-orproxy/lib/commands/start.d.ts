/**
 * /start 指令实现
 * 为指定机器分配 IP，自动处理黑名单 IP
 */
import { Context } from 'koishi';
import { DigitalOceanService } from '../services/digitalocean';
import { ZBProxyService } from '../services/zbproxy';
import { BlacklistService } from '../services/blacklist';
import { MachineService } from '../services/machine';
import { MachineLockService } from '../services/lock';
export declare function registerStartCommand(ctx: Context, doService: DigitalOceanService, zbproxyService: ZBProxyService, blacklistService: BlacklistService, machineService: MachineService, lockService: MachineLockService): void;
//# sourceMappingURL=start.d.ts.map