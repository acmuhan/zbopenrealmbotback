/**
 * 管理员指令集
 * 权限要求：
 * - 99级：超级管理员（所有权限）
 * - 100级：系统管理员（所有权限 + 紧急操作）
 */
import { Context } from 'koishi';
import { MaintenanceService } from '../services/maintenance';
import { BanService } from '../services/ban';
import { MachineLockService } from '../services/lock';
import { MachineService } from '../services/machine';
import { DigitalOceanService } from '../services/digitalocean';
import { ZBProxyService } from '../services/zbproxy';
import { BlacklistService } from '../services/blacklist';
export declare function registerAdminCommands(ctx: Context, maintenanceService: MaintenanceService, banService: BanService, lockService: MachineLockService, machineService: MachineService, doService: DigitalOceanService, zbproxyService: ZBProxyService, blacklistService: BlacklistService): void;
//# sourceMappingURL=admin.d.ts.map