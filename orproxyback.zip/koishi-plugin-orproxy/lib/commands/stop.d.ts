/**
 * /stop 指令实现
 * 停止机器，解绑 IP 并加入黑名单
 */
import { Context } from 'koishi';
import { DigitalOceanService } from '../services/digitalocean';
import { ZBProxyService } from '../services/zbproxy';
import { BlacklistService } from '../services/blacklist';
import { MachineService } from '../services/machine';
import { MachineLockService } from '../services/lock';
export declare function registerStopCommand(ctx: Context, doService: DigitalOceanService, zbproxyService: ZBProxyService, blacklistService: BlacklistService, machineService: MachineService, lockService: MachineLockService): void;
//# sourceMappingURL=stop.d.ts.map