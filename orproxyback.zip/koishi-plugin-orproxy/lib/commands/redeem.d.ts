import { Context } from 'koishi';
import { ActivationKeyService } from '../services/activation-key';
import { PermissionService } from '../services/permission';
/**
 * 注册卡密兑换相关的用户命令
 */
export declare function registerRedeemCommands(ctx: Context, activationKeyService: ActivationKeyService, permissionService: PermissionService): void;
//# sourceMappingURL=redeem.d.ts.map