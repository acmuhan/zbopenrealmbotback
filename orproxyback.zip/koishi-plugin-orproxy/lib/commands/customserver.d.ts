/**
 * 自定义服务器配置命令
 * 权限要求：10级
 */
import { Context } from 'koishi';
import { CustomServerService } from '../services/custom-server';
export declare function registerCustomServerCommands(ctx: Context, customServerService: CustomServerService): void;
//# sourceMappingURL=customserver.d.ts.map