import { Context } from 'koishi';
import { ActivationKeyService } from '../services/activation-key';
/**
 * 注册卡密管理相关的管理员命令
 */
export declare function registerActivationKeyCommands(ctx: Context, activationKeyService: ActivationKeyService): void;
//# sourceMappingURL=activation-key.d.ts.map