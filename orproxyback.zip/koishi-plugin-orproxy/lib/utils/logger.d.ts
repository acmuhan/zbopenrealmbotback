/**
 * 日志工具封装
 */
import { Context } from 'koishi';
export declare class Logger {
    private ctx;
    private namespace;
    constructor(ctx: Context, namespace?: string);
    info(message: string, ...args: any[]): void;
    warn(message: string, ...args: any[]): void;
    error(message: string, ...args: any[]): void;
    debug(message: string, ...args: any[]): void;
    /**
     * 记录操作历史到数据库
     */
    logHistory(data: {
        machine_name: string;
        old_ip?: string;
        new_ip: string;
        action: 'start' | 'stop' | 'switch';
        user_id: string;
        adapter_type: string;
        status: 'success' | 'failed' | 'rolled_back';
        error_message?: string;
    }): Promise<void>;
}
//# sourceMappingURL=logger.d.ts.map