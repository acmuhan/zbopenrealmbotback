/**
 * 事务回滚框架
 * 支持操作失败时自动回滚所有已执行的操作
 */
import { Logger } from './logger';
/**
 * 操作接口
 */
export interface Operation<T = any> {
    /**
     * 操作名称
     */
    name: string;
    /**
     * 执行操作
     */
    execute(): Promise<T>;
    /**
     * 回滚操作
     */
    rollback(): Promise<void>;
}
/**
 * 事务类
 */
export declare class Transaction {
    private logger;
    private operations;
    private results;
    constructor(logger: Logger);
    /**
     * 执行操作并记录
     */
    execute<T>(operation: Operation<T>): Promise<T>;
    /**
     * 获取操作结果
     */
    getResult<T>(operationName: string): T | undefined;
    /**
     * 回滚所有已执行的操作
     */
    rollback(): Promise<void>;
    /**
     * 清空事务（不回滚）
     */
    clear(): void;
}
/**
 * 创建 Reserved IP 操作
 */
export declare class CreateIPOperation implements Operation<string> {
    private doService;
    private region;
    name: string;
    private createdIP?;
    constructor(doService: any, region: string);
    execute(): Promise<string>;
    rollback(): Promise<void>;
}
/**
 * 分配 IP 操作
 */
export declare class AssignIPOperation implements Operation<void> {
    private doService;
    private ip;
    private dropletId;
    private oldIP?;
    name: string;
    constructor(doService: any, ip: string, dropletId: number, oldIP?: string | undefined);
    execute(): Promise<void>;
    rollback(): Promise<void>;
}
/**
 * 删除 IP 操作
 */
export declare class DeleteIPOperation implements Operation<void> {
    private doService;
    private ip;
    name: string;
    constructor(doService: any, ip: string);
    execute(): Promise<void>;
    rollback(): Promise<void>;
}
/**
 * 重启 ZBProxy 操作
 */
export declare class RestartZBProxyOperation implements Operation<void> {
    private zbproxyService;
    private ip;
    private port;
    name: string;
    constructor(zbproxyService: any, ip: string, port: number);
    execute(): Promise<void>;
    rollback(): Promise<void>;
}
/**
 * 停止 ZBProxy 操作
 */
export declare class StopZBProxyOperation implements Operation<void> {
    private zbproxyService;
    private ip;
    private port;
    name: string;
    constructor(zbproxyService: any, ip: string, port: number);
    execute(): Promise<void>;
    rollback(): Promise<void>;
}
/**
 * 添加黑名单操作
 */
export declare class AddBlacklistOperation implements Operation<void> {
    private blacklistService;
    private ip;
    private machineName;
    private userId;
    private adapterType;
    private reason;
    name: string;
    constructor(blacklistService: any, ip: string, machineName: string, userId: string, adapterType: string, reason: string);
    execute(): Promise<void>;
    rollback(): Promise<void>;
}
//# sourceMappingURL=rollback.d.ts.map